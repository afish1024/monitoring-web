import CanvasRender from "./CanvasRenderer";
import { DisplayObject } from "./DisplayObject";
import Stage from "./Stage";
/**
 * 导出系统，可以导出为图片、导出并下载图片、导出json文件
 */
export declare class ExportSystem {
    render: CanvasRender;
    stage: Stage;
    constructor(stage: Stage);
    /**
     * 将指定DisplayObject对象转成Base64图片编码
     *
     * stage.toDataURL([node1, node2]);
     *
     * 返回示例: data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNby...
     *
     * @param postProcessing 后期效果处理
     * @returns
     */
    toDataURL(objects: DisplayObject | Array<DisplayObject>): string;
    /**
     * 将指定对象转成Image对象
     * @param objects
     * @returns
     */
    toImage(objects: DisplayObject | Array<DisplayObject>): HTMLImageElement;
    /**
     * 导出图片
     */
    saveAsLocalImage(objects?: Array<DisplayObject>, fileName?: string): void;
    /**
     * 导出成图片，并在浏览器新标签页打开
     */
    saveImageInfo(objects?: Array<DisplayObject>): void;
    /**
     * 下载为json文件
     * @param fileName
     * @param imgToBase64 是否将图片内容转成Base64后内嵌入json中
     */
    download(fileName: string, imgToBase64?: boolean): void;
    _exportPaint(objects: Array<DisplayObject>): void;
    saveDataAsFile(data: any, filename: string): void;
}
