import { PopupMenu } from '@jtopo/core';
import Editor from './Editor';
export declare let popupMenuHtml: string;
export declare function initPopoMenu(editor: Editor): PopupMenu;
