/**
 * 注册自定义的类（自定义的类需要序列化时）
 */
export declare function regClass(name: any, clazz: any, serializers: Array<string>): void;
export declare function getClass(name: string): any;
