export declare function zoomLayer(layer: any, x: any, y: any, cx: any, cy: any): void;
export declare function autoBound(obj: any): void;
