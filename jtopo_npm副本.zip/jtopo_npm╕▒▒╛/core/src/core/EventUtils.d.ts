export declare function copyKeyboardEvent(event: KeyboardEvent): KeyboardEvent;
export declare function copyMouseEvent(type: any, event: any): {};
export declare class InputEvent {
    type: string;
    constructor(type: string);
}
export declare class TopoEvent {
    type: string;
    data: any;
    constructor(type: string);
}
