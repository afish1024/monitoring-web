const Rx = Kx;
(function(n, x) {
  const t = Kx, e = n();
  for (; []; )
    try {
      if (-parseInt(t(416)) / 1 + parseInt(t(406)) / 2 + -parseInt(t(411)) / 3 + -parseInt(t(415)) / 4 + -parseInt(t(408)) / 5 + parseInt(t(413)) / 6 + parseInt(t(410)) / 7 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Qx, 591840);
function vi(n, x, t) {
  return n[0] = x[0] + t[0], n[1] = x[1] + t[1], n;
}
function Qx() {
  const n = ["len", "3348205sHpass", "negate", "21364385YjTLng", "1109898bFxKJF", "projection", "741186PgqRoT", "normalize", "2186940JemOow", "1041852FbrtDw", "88896LzdCXw"];
  return Qx = function() {
    return n;
  }, Qx();
}
function M1(n, x, t) {
  return n[0] = x[0] * t, n[1] = x[1] * t, n;
}
function Pi(n, x, t) {
  return n[0] = x[0] * t, n[1] = x[1] * t, n;
}
function ki(n, x) {
  return n[0] = -x[0], n[1] = -x[1], n;
}
function Si(n, x) {
  let t = Math.sqrt(x[0] * x[0] + x[1] * x[1]);
  return t == 0 ? (n[0] = 0, n[0] = 0, n) : (n[0] = x[0] / t, n[1] = x[1] / t, n);
}
function Oi(n) {
  return Math.sqrt(n[0] * n[0] + n[1] * n[1]);
}
function T1(n, x) {
  return n[0] * x[0] + n[1] * x[1];
}
function Kx(n, x) {
  const t = Qx();
  return Kx = function(e, s) {
    return e = e - 406, t[e];
  }, Kx(n, x);
}
function Li(n, x, t) {
  let e = T1(x, t);
  return M1(n, t, e), n;
}
class F {
}
F.multiplyC = M1, F.scale = Pi, F[Rx(407)] = Oi, F[Rx(409)] = ki, F.add = vi, F[Rx(414)] = Si, F.dot = T1, F[Rx(412)] = Li;
const W = te;
function $x() {
  const n = ["103766YLnDHH", "corosshair", "6528828TRHoPB", "190qMOvQF", "edit", "mid1", "selectObject", "1298601qcqRrZ", "3QdiWhK", "350360xgTEUs", "5FjLfXJ", "927904ycOOCA", "11473jVMCCs", "normal", "modeChange", "ctrlPoint1", "begin", "groupdragend", "move", "12bHhEdy", "view", "试用版_2.2.2", "right", "assert", "center", "zoom", "resize", "3125868MmJesu", "select", "fold2", "groupdrag", "nearest", "end", "vertical", "ctrlPoint2", "s-resize", "down", "left", "w-resize", "mid", "drag", "ctrlPoint", "fullWindow", "fold1", "7pkdawe"];
  return $x = function() {
    return n;
  }, $x();
}
(function(n, x) {
  const t = te, e = n();
  for (; []; )
    try {
      if (parseInt(t(257)) / 1 * (parseInt(t(249)) / 2) + -parseInt(t(268)) / 3 * (-parseInt(t(258)) / 4) + -parseInt(t(259)) / 5 * (parseInt(t(231)) / 6) + parseInt(t(248)) / 7 * (-parseInt(t(260)) / 8) + -parseInt(t(256)) / 9 + parseInt(t(252)) / 10 * (parseInt(t(261)) / 11) + parseInt(t(251)) / 12 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})($x, 288640);
const y0 = { DefaultFont: "10px sans-serif" }, A1 = { PointClosestEpsilon: 0.01 }, rx = 2 * Math.PI, Qs = W(270), D0 = { drag: W(244), edit: W(253), normal: W(262), select: W(232), view: W(269) }, Ci = { move: W(267), corosshair: W(250), s_resize: W(239), n_resize: "n-resize", w_resize: W(242), e_resize: "e-resize" }, Nt = { horizontal: "horizontal", vertical: W(237) }, L = { lt: "lt", ct: "ct", rt: "rt", lm: "lm", center: W(273), rm: "rm", lb: "lb", cb: "cb", rb: "rb", nearest: W(235), begin: W(265), end: W(236), ctrlPoint: W(245), ctrlPoint1: W(264), ctrlPoint2: W(238), fold1: W(247), fold2: W(233), mid: W(243), mid1: W(254), mid2: "mid2", up: "up", down: W(240), left: W(241), right: W(271) }, Ei = { lt: L.rb, ct: L.cb, rt: L.lb, rm: L.lm, rb: L.lt, cb: L.ct, lb: L.rt, lm: L.rm }, Bx = { HandlerLayerCanvas: 99, FullWindowDom: 1e3, Link: 1, Node: 2, EditorNewLink: 3, IntersectPoint: 999, NodeCtrlBox: 1e3, LinkCtrlBox: 1001 }, Ks = !![];
function J0(n, ...x) {
  const t = W;
  Ks != ![] && console[t(272)](n != null, x);
}
function Mi(n, x, ...t) {
  Ks != ![] && console.assert(n == x, t);
}
function j1(n, ...x) {
  const t = W;
  Ks != ![] && console[t(272)](n, x);
}
const z1 = 0, z0 = 1, j0 = { zoom: W(229), resize: W(230), zoomAfter: "zoomAfter", fullWindow: W(246), modeChange: W(263), groupdrag: W(234), groupdragend: W(266), selectObject: W(255) };
function te(n, x) {
  const t = $x();
  return te = function(e, s) {
    return e = e - 229, t[e];
  }, te(n, x);
}
function b(n) {
  return (x, t) => {
    x[t] = n;
  };
}
const i0 = xe;
(function(n, x) {
  const t = xe, e = n();
  for (; []; )
    try {
      if (parseInt(t(257)) / 1 + parseInt(t(253)) / 2 * (-parseInt(t(263)) / 3) + -parseInt(t(260)) / 4 + -parseInt(t(286)) / 5 + -parseInt(t(252)) / 6 * (-parseInt(t(285)) / 7) + parseInt(t(279)) / 8 + -parseInt(t(256)) / 9 * (-parseInt(t(274)) / 10) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(ee, 662580);
function xe(n, x) {
  const t = ee();
  return xe = function(e, s) {
    return e = e - 251, t[e];
  }, xe(n, x);
}
function ee() {
  const n = ["points.length < 2", "middle", "forward", "7555352rJMuzX", "distance", "normalize", "distancePoint", "createPoints", "toPojo", "867811FnAhDZ", "2825305hZuQWa", "isLikePoint", "getDistanceSum", "18vyMcvA", "178emgdYU", "interpolate", "rotate", "18YUzfZt", "21272IfdudQ", "log", "getAngle", "1914328zXJRmQ", "push", "length", "42357YyqrxS", "number", "concat", "assert error betweenPoints", "looksSame", "abs", "atan2", "PointClosestEpsilon", "offsetWithAngle", "calculatePointOnMultiPointLine", "cos", "8126020bvSxZt", "sin"];
  return ee = function() {
    return n;
  }, ee();
}
class M {
  constructor(x = 0, t = 0) {
    this.x = x, this.y = t;
  }
  [i0(284)]() {
    return { x: this.x, y: this.y };
  }
  static [i0(287)](x) {
    return x instanceof M ? !![] : Object.keys(x).length == 2 && x.x != null && x.y != null;
  }
  static [i0(267)](x, t, e) {
    const s = i0;
    if (x === t)
      return !![];
    let i = Math[s(268)](t.x - x.x), r = Math[s(268)](t.y - x.y);
    return e == null && (e = 0.01), i < e && r < e;
  }
  static [i0(277)](x, t) {
    return { x: (t.x + x.x) / 2, y: (t.y + x.y) / 2 };
  }
  static [i0(259)](x, t) {
    return Math[i0(269)](t.y - x.y, t.x - x.x);
  }
  static [i0(255)](x, t, e, s, i) {
    const r = i0;
    return { x: (x - e) * Math[r(273)](i) - (t - s) * Math[r(275)](i) + e, y: (x - e) * Math[r(275)](i) + (t - s) * Math[r(273)](i) + s };
  }
  static rotatePoint(x, t, e) {
    const s = i0;
    return { x: (x.x - t.x) * Math[s(273)](e) - (x.y - t.y) * Math[s(275)](e) + t.x, y: (x.x - t.x) * Math[s(275)](e) + (x.y - t.y) * Math[s(273)](e) + t.y };
  }
  static [i0(280)](x, t, e, s) {
    let i = e - x, r = s - t;
    return Math.sqrt(i * i + r * r);
  }
  static [i0(282)](x, t) {
    let e = t.x - x.x, s = t.y - x.y;
    return Math.sqrt(e * e + s * s);
  }
  static mergeClosestPoints(x, t = A1[i0(270)]) {
    const e = i0;
    let s = [x[0]];
    for (let i = 1; i < x[e(262)] - 1; i++) {
      let r = s[s[e(262)] - 1], o = x[i], a = x[i + 1];
      if (o.x === a.x && o.y === a.y)
        continue;
      let c = F[e(281)]([], [o.x - r.x, o.y - r.y]), l = F[e(281)]([], [a.x - o.x, a.y - o.y]);
      Math.abs(c[0] - l[0]) < t && Math.abs(c[1] - l[1]) < t || s[e(261)](o);
    }
    return s[e(261)](x[x[e(262)] - 1]), s;
  }
  static [i0(278)](x, t, e) {
    const s = i0;
    let i = Math[s(269)](t.y - x.y, t.x - x.x);
    return { x: x.x + e * Math[s(273)](i), y: x.y + e * Math.sin(i) };
  }
  static [i0(271)](x, t, e) {
    const s = i0;
    return typeof e == s(264) && (e = { x: Math[s(273)](t) * e, y: Math.sin(t) * e }), { x: x.x + e.x, y: x.y + e.y };
  }
  static [i0(283)](x, t, e = 1, s = ![]) {
    const i = s ? [x] : [], r = s ? e - 1 : e;
    let o = x;
    for (var a = 0; a < r; a++) {
      const c = { x: o.x + t[0], y: o.y + t[1] };
      i.push(c), o = c;
    }
    return i;
  }
  static createPointsBidirectional(x, t, e) {
    const s = i0;
    if (e == 0)
      return [];
    const i = [-t[0], -t[1]];
    if (e % 2 == 0) {
      const a = [t[0] / 2, t[1] / 2], c = { x: x.x - a[0], y: x.y - a[1] }, l = { x: x.x + a[0], y: x.y + a[1] }, f = M[s(283)](c, i, e / 2, !![]), u = M[s(283)](l, t, e / 2, !![]);
      return f[s(265)](u);
    }
    const r = M[s(283)](x, i, (e - 1) / 2 + 1, !![]), o = M[s(283)](x, t, (e - 1) / 2, ![]);
    return r[s(265)](o);
  }
  static interpolate(x, t, e) {
    let s = (1 - e) * x.x, i = (1 - e) * x.y, r = e * t.x, o = e * t.y;
    return { x: s + r, y: i + o };
  }
  static [i0(251)](x) {
    const t = i0;
    let e = x[t(262)];
    if (e < 2)
      throw new Error(t(276));
    let s = x[0], i = x[e - 1];
    if (x[t(262)] == 2)
      return M[t(282)](s, i);
    let r = 0;
    for (var o = 1; o < e; o++)
      r += M[t(282)](x[o - 1], x[o]);
    return r;
  }
  static [i0(272)](x, t) {
    const e = i0;
    let s = x.length;
    if (x.length < 2)
      throw new Error(e(276));
    let i = x[0], r = x[x[e(262)] - 1];
    if (x[e(262)] == 2)
      return M[e(254)](i, r, t);
    if (t < 0)
      return M.interpolate(x[0], x[1], t);
    if (t > 1)
      return M[e(254)](x[x.length - 2], x[x[e(262)] - 1], t);
    let o = M[e(251)](x), a = o * t, c = 0;
    for (var l = 1; l < s; l++) {
      let f = M[e(282)](x[l - 1], x[l]);
      if (a >= c && a <= c + f) {
        let u = a - c, y = u / f;
        return M[e(254)](x[l - 1], x[l], y);
      }
      c += f;
    }
    throw console[e(258)](x, t), new Error(e(266));
  }
}
const V = ox;
function ox(n, x) {
  const t = ne();
  return ox = function(e, s) {
    return e = e - 329, t[e];
  }, ox(n, x);
}
(function(n, x) {
  const t = ox, e = n();
  for (; []; )
    try {
      if (parseInt(t(329)) / 1 * (-parseInt(t(364)) / 2) + parseInt(t(359)) / 3 * (-parseInt(t(347)) / 4) + -parseInt(t(340)) / 5 + parseInt(t(335)) / 6 * (parseInt(t(343)) / 7) + parseInt(t(348)) / 8 + parseInt(t(346)) / 9 * (parseInt(t(349)) / 10) + parseInt(t(334)) / 11 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(ne, 678685);
function ne() {
  const n = ["compact", "362075JEXCxY", "length", "rotateTarget", "7ZjcfvM", "freeCount", "atan2", "81PENtTO", "168YyJPPW", "1596576THtsPv", "1249070XhZceT", "matrixSize", "sort", "identity", "rotate", "find", "getTranslation", "slice", "buffer", "transform", "92844lkUptm", "usedList", "sin", "push", "splice", "50dpBbSh", "copy", "getRotation", "cos", "Failed to expand buffer", "allocate", "vec", "getScale", "expand", "getMatrix", "compactThreshold", "point", "translate", "pop", "multiply", "invert", "translateTo", "freeList", "218AVrduw", "allocationCount", "scale", "free", "indexOf", "7973713ZOLEjP", "46488LUhtIL", "index", "setAbsolutePosition", "byteLength"];
  return ne = function() {
    return n;
  }, ne();
}
class _s {
  constructor(x) {
    const t = ox;
    this.m = x && x[t(356)]() || [1, 0, 0, 1, 0, 0];
  }
  [V(365)]() {
    return new _s(this.m);
  }
  [V(352)]() {
    this.m = [1, 0, 0, 1, 0, 0];
  }
  [V(358)](x, t, e, s, i, r) {
    this.m[0] = x, this.m[1] = t, this.m[2] = e, this.m[3] = s, this.m[4] = i, this.m[5] = r;
  }
  [V(375)](x) {
    let t = this.m;
    return { x: t[0] * x.x + t[2] * x.y + t[4], y: t[3] * x.y + t[1] * x.x + t[5] };
  }
  [V(370)](x, t) {
    let e = this.m;
    return x[0] = e[0] * t[0] + e[2] * t[1], x[1] = e[3] * t[1] + e[1] * t[0], x;
  }
  points(x) {
    const t = V;
    let e = [];
    for (var s = 0; s < x[t(341)]; s++) {
      let i = x[s];
      e.push(this[t(375)](i));
    }
    return e;
  }
  translate(x, t) {
    return this.m[4] += this.m[0] * x + this.m[2] * t, this.m[5] += this.m[1] * x + this.m[3] * t, this;
  }
  [V(380)](x, t) {
    return this.m[4] = x, this.m[5] = t, this;
  }
  [V(331)](x, t) {
    return this.m[0] *= x, this.m[1] *= x, this.m[2] *= t, this.m[3] *= t, this;
  }
  [V(371)]() {
    return { x: this.m[0], y: this.m[3] };
  }
  [V(353)](x) {
    const t = V;
    let e = Math[t(367)](x), s = Math[t(361)](x), i = this.m[0] * e + this.m[2] * s, r = this.m[1] * e + this.m[3] * s, o = this.m[0] * -s + this.m[2] * e, a = this.m[1] * -s + this.m[3] * e;
    return this.m[0] = i, this.m[1] = r, this.m[2] = o, this.m[3] = a, this;
  }
  [V(342)](x, t, e) {
    this[V(376)](t, e), this.rotate(x), this.translate(-t, -e);
  }
  [V(355)]() {
    return { x: this.m[4], y: this.m[5] };
  }
  [V(366)]() {
    const x = V;
    let t = this[x(365)]();
    t[x(380)](0, 0);
    let e = t[x(375)]({ x: 0, y: 0 });
    return Math[x(345)](e.y, e.x);
  }
  [V(378)](x) {
    let t = this.m[0] * x.m[0] + this.m[2] * x.m[1], e = this.m[1] * x.m[0] + this.m[3] * x.m[1], s = this.m[0] * x.m[2] + this.m[2] * x.m[3], i = this.m[1] * x.m[2] + this.m[3] * x.m[3], r = this.m[0] * x.m[4] + this.m[2] * x.m[5] + this.m[4], o = this.m[1] * x.m[4] + this.m[3] * x.m[5] + this.m[5];
    return this.m[0] = t, this.m[1] = e, this.m[2] = s, this.m[3] = i, this.m[4] = r, this.m[5] = o, this;
  }
  [V(379)]() {
    let x = 1 / (this.m[0] * this.m[3] - this.m[1] * this.m[2]), t = this.m[3] * x, e = -this.m[1] * x, s = -this.m[2] * x, i = this.m[0] * x, r = x * (this.m[2] * this.m[5] - this.m[3] * this.m[4]), o = x * (this.m[1] * this.m[4] - this.m[0] * this.m[5]);
    return this.m[0] = t, this.m[1] = e, this.m[2] = s, this.m[3] = i, this.m[4] = r, this.m[5] = o, this;
  }
  [V(373)]() {
    return this.m;
  }
  [V(337)](x, t) {
    const e = V;
    let s = this.m[0], i = this.m[1], r = this.m[2], o = this.m[3], a = this.m[4], c = this.m[5], l = (s * (t - c) - i * (x - a)) / (s * o - i * r), f = (x - a - r * l) / s;
    return this[e(376)](f, l);
  }
}
class Pa {
  constructor(x, t, e) {
    const s = V;
    this[s(357)] = new ArrayBuffer(x), this[s(350)] = t, this[s(381)] = [0], this[s(360)] = [], this[s(374)] = e, this[s(330)] = 0, this[s(344)] = 0;
  }
  [V(369)]() {
    const x = V;
    if (this[x(381)].length === 0 && !this[x(372)]())
      throw new Error(x(368));
    const t = this[x(381)][x(377)](), e = new Float32Array(this.buffer, t, this[x(350)]);
    return this[x(360)].push({ index: t, matrix: e }), this[x(330)]++, this[x(330)] - this[x(344)] > this[x(374)] && this[x(339)](), e;
  }
  [V(332)](x) {
    const t = V, e = x.byteOffset, s = this.usedList[t(354)]((i) => i.index === e);
    s && (this.usedList[t(363)](this[t(360)][t(333)](s), 1), this[t(381)][t(362)](e), this[t(344)]++, this[t(330)] - this[t(344)] > this[t(374)] && this[t(339)]());
  }
  [V(339)]() {
    const x = V;
    this[x(360)][x(351)]((s, i) => s.index - i[x(336)]), this[x(381)] = [];
    let t = 0;
    for (const s of this.usedList)
      s[x(336)] - t > 0 && this[x(381)].push(t), t = s[x(336)] + s.matrix[x(338)];
    this.buffer[x(338)] - t > 0 && this[x(381)][x(362)](t), this.allocationCount = this[x(360)].length, this[x(344)] = this[x(381)][x(341)];
  }
  expand() {
    const x = V, t = new ArrayBuffer(this.buffer[x(338)] * 2);
    if (!t)
      return ![];
    const e = new Uint8Array(t), s = new Uint8Array(this[x(357)]);
    e.set(s), this[x(357)] = t;
    const i = this[x(381)][this[x(381)][x(341)] - 1];
    for (let r = this[x(357)][x(338)] - this.matrixSize; r >= i; r -= this[x(350)])
      this.freeList.push(r);
    return !![];
  }
}
const K = ax;
function ax(n, x) {
  const t = se();
  return ax = function(e, s) {
    return e = e - 271, t[e];
  }, ax(n, x);
}
(function(n, x) {
  const t = ax, e = n();
  for (; []; )
    try {
      if (parseInt(t(279)) / 1 * (-parseInt(t(277)) / 2) + parseInt(t(291)) / 3 + -parseInt(t(300)) / 4 + parseInt(t(273)) / 5 + -parseInt(t(271)) / 6 + -parseInt(t(281)) / 7 + parseInt(t(294)) / 8 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(se, 975885);
class q {
  constructor(x = 0, t = 0, e = 0, s = 0) {
    const i = ax;
    this.x = 0, this.y = 0, this.width = 0, this[i(298)] = 0, this.x = x, this.y = t, this[i(287)] = e, this[i(298)] = s;
  }
  [K(283)](x = 0, t = 0, e = 0, s = 0) {
    const i = K;
    this.x = x, this.y = t, this[i(287)] = e, this[i(298)] = s;
  }
  [K(286)]() {
    return this;
  }
  [K(275)]() {
    const x = K;
    return new q(this.x, this.y, this[x(287)], this[x(298)]);
  }
  toString() {
    const x = K;
    return x(278) + this.x + x(295) + this.y + x(290) + this[x(287)] + x(288) + this[x(298)] + "]";
  }
  equals(x) {
    const t = K;
    return x.x == this.x && x.y == this.y && x[t(287)] == this.width && x[t(298)] == this[t(298)];
  }
  [K(280)](x) {
    const t = K;
    return x.x > this.x && x[t(276)]() < this[t(276)]() && x.y > this.y && x.getBottom() < this[t(303)]() ? !![] : ![];
  }
  [K(272)](x, t) {
    const e = K;
    return x >= this.x && x <= this.x + this[e(287)] && t >= this.y && t <= this.y + this.height;
  }
  [K(282)](x) {
    const t = K;
    return x.x > this.getRight() || x.y > this[t(303)]() ? ![] : x[t(276)]() < this.x || x[t(303)]() < this.y ? ![] : !![];
  }
  [K(276)]() {
    return this.x + this.width;
  }
  getBottom() {
    const x = K;
    return this.y + this[x(298)];
  }
  [K(285)]() {
    return this.x === 0 && this.y === 0 && this.width === 0 && this.height === 0;
  }
  [K(296)]() {
    this[K(283)](0, 0, 0, 0);
  }
  [K(292)]() {
    const x = K;
    return { x: this.x + this[x(287)] / 2, y: this.y + this.height / 2 };
  }
  static [K(284)](x, t) {
    const e = K;
    let s = Math.min(x.x, t.x), i = Math[e(297)](x.y, t.y), r = Math[e(299)](x[e(276)](), t[e(276)]()), o = Math[e(299)](x[e(303)](), t[e(303)]());
    return x.setTo(s, i, r - s, o - i), x;
  }
  static normal(x, t) {
    const e = K;
    let s = t.x - x.x, i = t.y - x.y;
    return Math[e(301)](s) > Math[e(301)](i) ? [Math[e(293)](s), 0] : [0, Math.sign(i)];
  }
}
class Mt {
  constructor(x) {
    const t = K;
    this.points = x, this[t(289)] = Mt[t(302)](x);
  }
  [K(272)](x, t) {
    const e = K;
    return this[e(289)][e(272)](x, t) == ![] ? ![] : !![];
  }
  static [K(302)](x) {
    const t = K;
    let e = x[0], s = { x: e.x, y: e.y }, i = { x: e.x, y: e.y }, r = { x: e.x, y: e.y }, o = { x: e.x, y: e.y };
    for (let a = 1; a < x[t(274)]; a++) {
      let c = x[a];
      c.x < s.x && (s.x = c.x), c.x > i.x && (i.x = c.x), c.y < r.y && (r.y = c.y), c.y > o.y && (o.y = c.y);
    }
    return new q(s.x, r.y, i.x - s.x, o.y - r.y);
  }
}
function se() {
  const n = ["1negujp", "containsRect", "6351933rJYcYR", "isIntersectRect", "setTo", "union", "isEmpty", "getRect", "width", " height:", "aabb", " width:", "2181057tArtYc", "getCenter", "sign", "28923552zjcABa", " y:", "setToEmpty", "min", "height", "max", "6925516ScaNOu", "abs", "toAABB", "getBottom", "1752534pVPMRG", "contains", "893510GqXOYS", "length", "clone", "getRight", "1228786WdLCsc", "[x: "];
  return se = function() {
    return n;
  }, se();
}
(function(n, x) {
  for (var t = Ms, e = n(); []; )
    try {
      var s = parseInt(t(108)) / 1 * (-parseInt(t(112)) / 2) + -parseInt(t(104)) / 3 + parseInt(t(107)) / 4 * (parseInt(t(103)) / 5) + -parseInt(t(106)) / 6 + -parseInt(t(109)) / 7 * (parseInt(t(105)) / 8) + parseInt(t(110)) / 9 + parseInt(t(111)) / 10;
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(ie, 380030);
function Ms(n, x) {
  var t = ie();
  return Ms = function(e, s) {
    e = e - 103;
    var i = t[e];
    return i;
  }, Ms(n, x);
}
function ie() {
  var n = ["5Sdsuuv", "888984GtIxfx", "6536vGrqzG", "3152520ZQlVTH", "96248EoMwPv", "5SBcqwy", "1442GnctXY", "870021PzFylh", "14479690bnZZuD", "79448rTDsPx"];
  return ie = function() {
    return n;
  }, ie();
}
function re() {
  var n = ["9900CEeJDY", "35RWKQoP", "10cjCIcl", "202914PFiIQL", "728OcvjoE", "253ixders", "132924bHoXnU", "600057WBpjQl", "42mFzLrG", "1955432BpYwts", "281724BjcqVh", "2733oYUSap"];
  return re = function() {
    return n;
  }, re();
}
(function(n, x) {
  for (var t = Ts, e = n(); []; )
    try {
      var s = parseInt(t(435)) / 1 * (parseInt(t(432)) / 2) + parseInt(t(430)) / 3 + -parseInt(t(428)) / 4 * (-parseInt(t(436)) / 5) + -parseInt(t(427)) / 6 * (-parseInt(t(437)) / 7) + parseInt(t(433)) / 8 + -parseInt(t(431)) / 9 * (parseInt(t(426)) / 10) + parseInt(t(429)) / 11 * (-parseInt(t(434)) / 12);
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(re, 268941);
function Ts(n, x) {
  var t = re();
  return Ts = function(e, s) {
    e = e - 426;
    var i = t[e];
    return i;
  }, Ts(n, x);
}
function oe() {
  const n = ["push", "1116132OKnBps", "removeEventListener", "hasListener", "29EqwzyP", "call", "listeners", "256949waxqDT", "length", "1272723KCcfKC", "8838ScVjqq", "1816960dosZnJ", "41510pXYQSS", "1221280NwVnWH", "addEventListener"];
  return oe = function() {
    return n;
  }, oe();
}
const bt = ae;
(function(n, x) {
  const t = ae, e = n();
  for (; []; )
    try {
      if (-parseInt(t(188)) / 1 * (-parseInt(t(179)) / 2) + parseInt(t(193)) / 3 + -parseInt(t(182)) / 4 + -parseInt(t(181)) / 5 + -parseInt(t(185)) / 6 + -parseInt(t(191)) / 7 + parseInt(t(180)) / 8 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(oe, 243161);
function ae(n, x) {
  const t = oe();
  return ae = function(e, s) {
    return e = e - 179, t[e];
  }, ae(n, x);
}
class K0 {
  constructor() {
    this.listeners = {};
  }
  [bt(187)](x) {
    return x in this[bt(190)];
  }
  [bt(183)](x, t) {
    const e = bt;
    !(x in this.listeners) && (this[e(190)][x] = []), this[e(190)][x][e(184)](t);
  }
  removeEventListener(x, t) {
    const e = bt;
    if (!(x in this[e(190)]))
      return;
    let s = this[e(190)][x];
    for (var i = 0, r = s[e(192)]; i < r; i++)
      if (s[i] === t)
        return s.splice(i, 1), this[e(186)](x, t);
  }
  dispatchEvent(x) {
    const t = bt;
    if (!(x.type in this.listeners))
      return;
    let e = this[t(190)][x.type];
    for (var s = 0, i = e[t(192)]; s < i; s++)
      e[s][t(189)](this, x);
  }
  on(x, t) {
    return this[bt(183)](x, t);
  }
}
function ce() {
  const n = ["union", "615104kTCiUm", "getMinMax", "width", "indexOf", "388EEpxrN", "push", "50618JRvDEu", "length", "531MIzrcm", "getPointsRect", "removeAt", "rotate", "min", "remove", "getPointsNormalization", "1303786ALmiED", "20FENeZz", "max", "rotateNormaledPoints", "15740jxSLva", "42624CVDcTC", "hasChild", "MIN_SAFE_INTEGER", "setTo", "slice", "3reLunz", "map", "1008414uNiRVz", "forEach", "MAX_SAFE_INTEGER", "notContains", "height", "137621gBECsL"];
  return ce = function() {
    return n;
  }, ce();
}
const p0 = le;
(function(n, x) {
  const t = le, e = n();
  for (; []; )
    try {
      if (-parseInt(t(528)) / 1 + -parseInt(t(502)) / 2 * (parseInt(t(521)) / 3) + parseInt(t(500)) / 4 * (-parseInt(t(515)) / 5) + parseInt(t(523)) / 6 + -parseInt(t(530)) / 7 + -parseInt(t(516)) / 8 * (-parseInt(t(504)) / 9) + -parseInt(t(512)) / 10 * (-parseInt(t(511)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(ce, 163315);
function le(n, x) {
  const t = ce();
  return le = function(e, s) {
    return e = e - 500, t[e];
  }, le(n, x);
}
class Z {
  static [p0(517)](x, t) {
    return x[p0(533)](t) != -1;
  }
  static [p0(526)](x, t) {
    return x[p0(533)](t) == -1;
  }
  static addAll(x, t) {
    const e = p0;
    for (var s = 0; s < t[e(503)]; s++)
      x[e(501)](t[s]);
    return x;
  }
  static [p0(506)](x, t) {
    return x.splice(t, 1);
  }
  static [p0(509)](x, t) {
    let s = x[p0(533)](t);
    return s == -1 ? -1 : (x.splice(s, 1), s);
  }
  static [p0(505)](x) {
    const t = p0;
    let e = Number.MAX_SAFE_INTEGER, s = Number[t(525)], i = Number.MIN_SAFE_INTEGER, r = Number[t(518)];
    return x[t(524)](function(o) {
      o.x < e && (e = o.x), o.y < s && (s = o.y), o.x > i && (i = o.x), o.y > r && (r = o.y);
    }), new q(e, s, i - e, r - s);
  }
  static getRectsNormalization(x, t) {
    const e = p0;
    let s = new q();
    s[e(519)](x[0].x, x[0].y, x[0].width, x[0][e(527)]);
    for (let l = 1; l < x[e(503)]; l++)
      q[e(529)](s, x[l]);
    let i = s[e(532)], r = s[e(527)], o = s.x, a = s.y;
    return x[e(522)]((l) => {
      const f = e;
      let u = l[f(532)] / i, y = l[f(527)] / r, m = (l.x - o) / i, p = (l.y - a) / r, k = u * t[f(532)], w = y * t.height, O = t.x + m * t[f(532)], S = t.y + p * t[f(527)];
      return new q(O, S, k, w);
    });
  }
  static [p0(531)](x) {
    const t = p0;
    let e = { x: x[0].x, y: x[0].y }, s = { x: x[0].x, y: x[0].y };
    for (let i = 1; i < x[t(503)]; i++) {
      let r = x[i];
      e.x = Math[t(508)](e.x, r.x), e.y = Math[t(508)](e.y, r.y), s.x = Math[t(513)](s.x, r.x), s.y = Math.max(s.y, r.y);
    }
    return { min: e, max: s };
  }
  static [p0(510)](x, t = -0.5, e = -0.5, s = !![]) {
    const i = p0;
    let r = Z[i(531)](x), o = r[i(508)], a = r[i(513)], c = a.x - o.x, l = a.y - o.y;
    if (c == l || s == ![])
      return x[i(522)]((m) => ({ x: (m.x - o.x) / c + t, y: (m.y - o.y) / l + e }));
    if (c > l) {
      let y = (c - l) * 0.5;
      return l = c, x[i(522)]((p) => ({ x: (p.x - o.x) / c + t, y: (p.y + y - o.y) / l + e }));
    }
    let f = (l - c) * 0.5;
    return c = l, x[i(522)]((y) => ({ x: (y.x + f - o.x) / c + t, y: (y.y - o.y) / l + e }));
  }
  static [p0(514)](x, t, e = 0, s = 0) {
    const i = p0;
    if (t == 0 || t % 6.283185307179586 == 0)
      return x[i(520)]();
    let r = x[i(522)]((o) => M[i(507)](o.x, o.y, e, s, t));
    return Z[i(510)](r);
  }
}
function he() {
  const n = ["2200WrrzUB", "addToCallbackList", "get", "3795JHRnRI", "加载失败: ", "callbackCache", "onerror", "next", "295368XdhgmS", "开始加载: ", "7290GSzjvZ", "log", "length", "7pDlBpm", "warn", "17118PNFEJs", "253254zoanDw", "hasLoaded", "1006150yRCMia", "4Havqre", "delete", "src", "all", "343419PigNTJ", "set", "clear", "loaded", "map", "imageCache", "push", "clearCache", "加载完成: ", "1925178zLuaBX", "onload", "lastResource"];
  return he = function() {
    return n;
  }, he();
}
const Ot = mt;
(function(n, x) {
  const t = mt, e = n();
  for (; []; )
    try {
      if (parseInt(t(151)) / 1 + parseInt(t(143)) / 2 + -parseInt(t(158)) / 3 * (parseInt(t(154)) / 4) + parseInt(t(153)) / 5 + parseInt(t(167)) / 6 * (parseInt(t(148)) / 7) + -parseInt(t(135)) / 8 * (parseInt(t(150)) / 9) + parseInt(t(145)) / 10 * (parseInt(t(138)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(he, 537013);
class Ti extends K0 {
  constructor() {
    const x = mt;
    super(), this.imageCache = /* @__PURE__ */ new Map(), this[x(140)] = /* @__PURE__ */ new Map();
  }
  whenAllImagesLoaded(x, t) {
    const e = mt, s = this.imageCache;
    function i(o) {
      return new Promise((a, c) => {
        const l = mt;
        let f = new Image();
        f[l(156)] = o, t && console[l(146)](l(144), o), f[l(168)] = function() {
          const u = l;
          t && console[u(146)](u(166), o), s[u(159)](o, f), a(f);
        }, f[l(141)] = function() {
          const u = l;
          t && console[u(149)](u(139), o), c(o);
        };
      });
    }
    let r = x[e(162)](i);
    return Promise[e(157)](r);
  }
  [Ot(165)]() {
    const x = Ot;
    this[x(163)][x(160)](), this[x(140)][x(160)]();
  }
  onload(x, t) {
    const e = Ot;
    let s = this[e(140)][e(137)](x);
    if (s != null) {
      for (let i = 0; i < s[e(147)]; i++) {
        let r = s[i];
        r.canceled || (r(t), r[e(142)] && r[e(142)](t));
      }
      this[e(140)][e(155)](x), this.imageCache.set(x, t), this[e(152)] = !![], this.dispatchEvent({ type: e(161), resource: t });
    }
  }
  [Ot(136)](x, t) {
    const e = Ot;
    if (t == null)
      return;
    let s = this[e(140)][e(137)](x);
    s == null && (s = [], this.callbackCache[e(159)](x, s)), s[e(164)](t);
  }
  loadImage(x, t) {
    const e = Ot;
    let s = this;
    s[e(169)] = x, this.addToCallbackList(x, t);
    let i = this[e(163)].get(x);
    if (i != null) {
      this[e(168)](x, i);
      return;
    }
    setTimeout(function() {
      const r = e;
      let o = new Image();
      o[r(156)] = x, o.onload = function() {
        s[r(168)](x, o);
      }, o[r(141)] = function() {
        s[r(168)](x, o);
      };
    }, 1);
  }
}
function mt(n, x) {
  const t = he();
  return mt = function(e, s) {
    return e = e - 135, t[e];
  }, mt(n, x);
}
const V0 = new Ti();
(function(n, x) {
  const t = ue, e = n();
  for (; []; )
    try {
      if (parseInt(t(248)) / 1 * (parseInt(t(247)) / 2) + -parseInt(t(234)) / 3 + parseInt(t(243)) / 4 * (parseInt(t(238)) / 5) + -parseInt(t(235)) / 6 + parseInt(t(246)) / 7 + parseInt(t(242)) / 8 + -parseInt(t(240)) / 9 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(fe, 509767);
function fe() {
  const n = ["677068miyNRv", "4TGWRSo", "229486tQLyjm", "233676zcJbVD", "385770TNJAHc", "concat", "prototype", "2271485SelZpM", "className", "10014678BlzqoO", "serializers", "6037624eTJREG", "4IOiDTb", "defineProperties", "length"];
  return fe = function() {
    return n;
  }, fe();
}
function ue(n, x) {
  const t = fe();
  return ue = function(e, s) {
    return e = e - 234, t[e];
  }, ue(n, x);
}
function Ai(n, x, t) {
  return typeof n == "function" ? o1(n.name, n, x) : o1(n, x, t);
}
function o1(n, x, t) {
  const e = ue;
  if (y0[n] != null)
    throw new Error("class already reg, name:" + n);
  const s = x[e(237)];
  t != null && t[e(245)] > 0 && (s[e(241)] = s.serializers[e(236)](t)), Object[e(244)](s, { className: { writable: !![] } }), s[e(239)] = n, Object[e(244)](s, { className: { writable: ![] } }), y0[n] = x;
}
function $s(n) {
  let x = y0[n];
  if (x == null)
    throw new Error("class not exist name:" + n);
  return x;
}
const Hx = de;
function de(n, x) {
  const t = pe();
  return de = function(e, s) {
    return e = e - 404, t[e];
  }, de(n, x);
}
(function(n, x) {
  const t = de, e = n();
  for (; []; )
    try {
      if (-parseInt(t(415)) / 1 + -parseInt(t(413)) / 2 + -parseInt(t(404)) / 3 + -parseInt(t(410)) / 4 * (parseInt(t(406)) / 5) + -parseInt(t(407)) / 6 + parseInt(t(412)) / 7 + parseInt(t(409)) / 8 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(pe, 353832);
let Ut = 0, B0 = {};
B0.next = function() {
  return ++Ut;
}, B0[Hx(411)] = function() {
  return --Ut;
}, B0[Hx(414)] = function() {
  return Ut;
}, B0[Hx(408)] = function(n) {
  Ut = n;
}, B0[Hx(405)] = function(n) {
  n != null && n > Ut && B0.resetTo(n + 1);
};
function pe() {
  const n = ["compare", "5945gqAroR", "2287044ebyziq", "resetTo", "13220824jYEqHU", "40xNHfOj", "back", "1523459uPTiVg", "126694PosFmz", "getMax", "583924BqQJwh", "1428219SYqAJL"];
  return pe = function() {
    return n;
  }, pe();
}
const _ = cx;
(function(n, x) {
  const t = cx, e = n();
  for (; []; )
    try {
      if (-parseInt(t(323)) / 1 + parseInt(t(342)) / 2 * (parseInt(t(324)) / 3) + -parseInt(t(347)) / 4 + -parseInt(t(340)) / 5 + -parseInt(t(321)) / 6 + parseInt(t(288)) / 7 + parseInt(t(302)) / 8 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(be, 619253);
function be() {
  const n = ["pointToSize", "begin", "className", "ArrowShape", "Circle", "lineTo", "4603152ZoUHhm", "arc", "179192pfanSC", "191202gToEAx", "lineCap", "Shape", "end", "getOwnPropertyDescriptor", "Damond", "length", "circlePoints", "fromPoints", "Triangle", "Line", "rotateNormaledPoints", "ArcShape", "CircleShape", "defineProperty", "beginPath", "1933375ZxnYYb", "forEach", "2kzlDSB", "circle", "ellipse", "BezierCurve", "outerGrid", "1768616GiqbLi", "prototype", "nearest", "Arc", "anticlockwise", "dirty", "points", "Rect", "direction", "Arrow", "scale", "moveTo", "distancePoint", "map", "5909666dhHXoU", "parallelogram", "pointCount", "closePath", "step", "EllipseShape", "Rotate", "center is zero vector", "atan2", "rotate", "Polygon", "bezierCurveTo", "sin", "draw", "11891952saybFj", "RectShape", "getPointsNormalization", "LineShape", "polygon", "center", "rect", "CurveShape", "BezierCurveShape", "push", "cos", "isClosed", "tip"];
  return be = function() {
    return n;
  }, be();
}
var ji = Object[_(338)], zi = Object[_(328)], G0 = (n, x, t, e) => {
  for (var s = e > 1 ? void 0 : e ? zi(x, t) : x, i = n.length - 1, r; i >= 0; i--)
    (r = n[i]) && (s = (e ? r(x, t, s) : r(s)) || s);
  return e && s && ji(x, t, s), s;
};
function cx(n, x) {
  const t = be();
  return cx = function(e, s) {
    return e = e - 280, t[e];
  }, cx(n, x);
}
const L0 = class {
  constructor(n) {
    const x = _;
    this[x(313)] = !![], this[x(280)] = n;
  }
  toPojo() {
    const n = _;
    let x = { className: this[n(317)] };
    return x[n(280)] = this.points, x[n(313)] = this[n(313)], x;
  }
  clone() {
    const n = _;
    return new L0(this[n(280)].slice());
  }
  static fromPojo(n) {
    const x = _;
    let t = $s(n[x(317)]), e = new t(n.points);
    return e[x(313)] = n[x(313)], e;
  }
  static [_(332)](n, x = !![]) {
    let e = Z[_(304)](n, -0.5, -0.5, x);
    return new L0(e);
  }
  [_(301)](n, x, t) {
    const e = _;
    x = x || this[e(280)];
    let s = x[0];
    n.moveTo(s.x, s.y);
    for (let r = 1; r < x.length - 1; r++) {
      if (x[r].x === s.x && x[r].y === s.y) {
        s = x[r];
        continue;
      }
      n.lineTo(x[r].x, x[r].y), s = x[r];
    }
    let i = x[x[e(330)] - 1];
    n[e(320)](i.x, i.y), this[e(313)] && n.closePath();
  }
  [_(297)](n) {
    const x = _;
    return this[x(280)] = Z[x(335)](this[x(280)], n), this[x(352)] = !![], this;
  }
  [_(284)](n, x) {
    const t = _;
    return this[t(280)][t(341)]((e) => {
      e.x *= n, e.y *= x;
    }), this[t(280)] = Z[t(304)](this[t(280)]), this[t(352)] = !![], this;
  }
  static Scale(n, x) {
    return function(t) {
      return t.x *= n, t.y *= x, t;
    };
  }
  static [_(294)](n) {
    return function(x) {
      const t = cx;
      let e = Math.atan2(x.y, x.x), s = e + n, i = M.distance(x.x, x.y, 0, 0);
      return x.x = i * Math[t(312)](s), x.y = i * Math[t(300)](s), x;
    };
  }
  skew(n, x) {
    const t = _;
    return this[t(280)][t(341)]((e) => {
      let s = e.x, i = e.y;
      e.x = s + i * x, e.y = i + s * n;
    }), this.points = Z.getPointsNormalization(this[t(280)]), this[t(352)] = !![], this;
  }
  static [_(315)](n, x, t, e = ![]) {
    const s = _;
    return e == !![] && x != t && (x > t ? x = t : t = x), n[s(287)]((r) => ({ x: r.x * x, y: r.y * t }));
  }
  static polygon(n = 3, x = 0) {
    const t = _;
    let e = [], s = 2 * Math.PI / n;
    for (var i = 0; i < n; i++) {
      let o = Math[t(312)](x + i * s), a = Math[t(300)](x + i * s);
      e[t(311)]({ x: o, y: a });
    }
    return L0[t(332)](e);
  }
  static [_(289)](n = 0.2) {
    const x = _;
    let t = [{ x: n, y: 0 }, { x: 1, y: 0 }, { x: 1 - n, y: 1 }, { x: 0, y: 1 }];
    return L0[x(332)](t);
  }
  static [_(312)](n) {
    const x = _;
    n[x(316)] = n.begin | 0, n[x(327)] = n[x(327)] | rx;
    let t = [];
    if (n[x(290)] == null) {
      n[x(292)] = n.step | 0.2;
      for (let e = n[x(316)]; e <= n[x(327)]; e += n[x(292)]) {
        let s = e;
        t[x(311)]({ x: s, y: Math[x(312)](s) });
      }
    } else {
      n.step = (n[x(327)] - n[x(316)]) / n.pointCount;
      for (let e = 0; e < n[x(290)]; e++) {
        let s = (e + 1) * n[x(292)];
        t.push({ x: s, y: Math[x(312)](s) });
      }
    }
    return L0[x(332)](t);
  }
  static [_(343)](n) {
    let t = L0[_(331)](n);
    return L0.fromPoints(t);
  }
  static circlePoints(n) {
    const x = _;
    n[x(316)] = n[x(316)] || 0, n[x(327)] = n[x(327)] || rx;
    let t = [];
    if (n[x(290)] == null) {
      n[x(292)] = n[x(292)] | 0.2;
      for (let e = n[x(316)]; e <= n[x(327)]; e += n[x(292)]) {
        let s = e;
        t[x(311)]({ x: Math[x(300)](s), y: Math[x(312)](s) });
      }
    } else {
      let e = (n.end - n[x(316)]) / n[x(290)];
      for (let s = 0; s < n[x(290)]; s++) {
        let i = s * e;
        t[x(311)]({ x: Math[x(300)](i), y: Math.cos(i) });
      }
    }
    return t;
  }
  static fn(n) {
    const x = _;
    let t = n();
    return L0[x(332)](t);
  }
  static [_(346)](n, x) {
    const t = _;
    let e = [], s = 1 / (x - 1), i = 1 / (n - 1);
    for (let r = 0; r < n; r++)
      for (let o = 0; o < x; o++) {
        let a = { y: r * i - 0.5, x: o * s - 0.5 };
        e[t(311)](a);
      }
    return L0[t(332)](e);
  }
  static innerGrid(n, x) {
    const t = _;
    let e = [], s = 1 / x, i = 1 / n, r = s * 0.5, o = i * 0.5;
    for (let a = 0; a < n; a++)
      for (let c = 0; c < x; c++) {
        let l = { y: r + a * i - 0.5, x: o + c * s - 0.5 };
        e[t(311)](l);
      }
    return L0[t(332)](e);
  }
};
let R = L0;
R[_(329)] = (() => {
  let n = [{ x: -0.5, y: 0 }, { x: 0, y: -0.5 }, { x: 0.5, y: 0 }, { x: 0, y: 0.5 }];
  return new L0(n);
})(), R[_(333)] = (() => {
  let n = [{ x: -0.5, y: -0.5 }, { x: 0.5, y: 0 }, { x: -0.5, y: 0.5 }];
  return new L0(n);
})(), R[_(314)] = (() => {
  const n = _;
  let x = [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: 0.8 }, { x: 0.8, y: 0.8 }, { x: 0.5, y: 1 }, { x: 0.2, y: 0.8 }, { x: 0, y: 0.8 }, { x: 0, y: 0 }];
  return L0[n(332)](x);
})(), G0([b(_(326))], R[_(348)], "className", 2), G0([b(![])], R[_(348)], _(352), 2), R[_(298)] = R[_(306)];
class tx extends R {
  constructor(x = [{ x: -0.5, y: -0.5 }, { x: 0.5, y: 0 }, { x: -0.5, y: 0.5 }, { x: -0.5, y: 0 }]) {
    super(x);
  }
  [_(301)](x, t, e) {
    const s = _;
    t = t || this.points, x.moveTo(t[0].x, t[0].y), x[s(320)](t[1].x, t[1].y), x[s(320)](t[2].x, t[2].y), x[s(325)] = "square", x.moveTo(t[3].x, t[3].y), x.lineTo(t[1].x - 0.05, t[1].y);
  }
}
G0([b(_(318))], tx[_(348)], _(317), 2), G0([b(![])], tx[_(348)], "isClosed", 2), y0[_(318)] = tx, R[_(283)] = new tx(), R[_(318)] = R[_(283)];
class Xx extends R {
  constructor(x = [{ x: -0.5, y: -0.5 }, { x: 0.5, y: -0.5 }, { x: 0.5, y: 0.5 }, { x: -0.5, y: 0.5 }]) {
    super(x);
  }
  [_(301)](x, t, e) {
    x[_(308)](-0.5, -0.5, 1, 1);
  }
}
G0([b("RectShape")], Xx[_(348)], _(317), 2), y0[_(303)] = Xx, R[_(281)] = new Xx(), R[_(303)] = R.Rect;
class As extends R {
  constructor(x = [{ x: 0, y: 0 }]) {
    super(x);
  }
  [_(301)](x, t, e) {
    const s = _;
    let i = this[s(280)][0];
    x[s(322)](i.x, i.y, 0.5, 0, rx);
  }
}
G0([b(_(337))], As[_(348)], _(317), 2), R[_(319)] = new As();
class js extends R {
  constructor(x = [{ x: 0, y: 0 }, { x: -0.5, y: 0 }, { x: 0.25, y: 0 }]) {
    super(x);
  }
  draw(x, t, e) {
    const s = _;
    let i = this[s(280)][0], r = this.points[1], o = this.points[2], a = M[s(286)](i, r), c = M[s(286)](i, o);
    x[s(344)](i.x, i.y, a, c, 0, 0, rx);
  }
}
G0([b(_(293))], js[_(348)], _(317), 2), R.Ellipse = new js();
class zs extends R {
  constructor(x = []) {
    super(x), this.isClosed = ![];
  }
}
G0([b(_(305))], zs[_(348)], "className", 2), R[_(334)] = new zs();
class Ds extends R {
  constructor(x = []) {
    super(x), this.isClosed = ![];
  }
  [_(301)](x, t, e) {
    const s = _;
    let i = t[0], r = t[1], o = t[2];
    x[s(285)](i.x, i.y), x.quadraticCurveTo(r.x, r.y, o.x, o.y), this[s(313)] && x[s(291)]();
  }
}
G0([b(_(309))], Ds.prototype, _(317), 2), R.Curve = new Ds();
class Bs extends R {
  constructor(x = []) {
    super(x), this.isClosed = ![];
  }
  [_(301)](x, t, e) {
    const s = _;
    let i = t[0], r = t[1], o = t[3], a = t[4];
    x[s(339)](), x[s(285)](i.x, i.y), x[s(299)](r.x, r.y, o.x, o.y, a.x, a.y), this.isClosed && x.closePath();
  }
}
G0([b(_(310))], Bs[_(348)], _(317), 2), R[_(345)] = new Bs();
class Ns extends R {
  constructor(x = []) {
    const t = _;
    super(x), this[t(313)] = ![];
  }
  [_(301)](x, t, e) {
    const s = _;
    let i = t[0], r = t[t[s(330)] - 1];
    if (e && e[s(282)] == s(351)) {
      let o = Math[s(296)](i.y - r.y, i.x - r.x);
      x[s(322)](0, 0, 0.5, o, o + Math.PI, !![]);
    } else {
      let o = Math[s(296)](i.y - r.y, i.x - r.x);
      x[s(322)](0, 0, 0.5, o, o + Math.PI, ![]);
    }
    this[s(313)] && x[s(291)]();
  }
}
G0([b(_(336))], Ns[_(348)], _(317), 2), R[_(350)] = new Ns();
const Di = R[_(346)](3, 3).points, Bi = [L.lt, L.ct, L.rt, L.lm, L[_(307)], L.rm, L.lb, L.cb, L.rb], lt = {};
Bi[_(341)]((n, x) => {
  lt[n] = Di[x];
}), lt[L[_(349)]] = function() {
  return this[_(349)];
};
function t1(n) {
  const x = _;
  if (n == x(307))
    throw new Error(x(295));
  let t = lt[n];
  return F.normalize([], [t.x, t.y]);
}
function D1(n) {
  let x = lt[n];
  return Math.atan2(x.y, x.x);
}
(function(n, x) {
  const t = et, e = n();
  for (; []; )
    try {
      if (-parseInt(t(350)) / 1 + -parseInt(t(370)) / 2 * (-parseInt(t(387)) / 3) + -parseInt(t(346)) / 4 * (-parseInt(t(345)) / 5) + parseInt(t(349)) / 6 * (parseInt(t(381)) / 7) + parseInt(t(371)) / 8 + -parseInt(t(358)) / 9 + parseInt(t(380)) / 10 * (-parseInt(t(372)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(ge, 105102);
function ws(n, x) {
  const t = et;
  let e = {}, s = {}, i = {}, r = {}, o = n.Roots || [0], a = n.DisplayObjects, c = n[t(379)], l = n[t(365)];
  n[t(376)][t(344)](function(w, O) {
    const S = t;
    r[O] = w[S(355)];
  }), c[t(344)](function(w, O) {
    let S = w0.fromPojo(w);
    s[O] = S;
  }), l[t(344)](function(w, O) {
    let j = R[t(377)](w);
    i[O] = j;
  });
  let u = [];
  function y(w, O) {
    const S = t;
    let j;
    if (x && (j = x[w.id]), j == null && (j = ys(w.className)), O < o.length && u[S(354)](j), Ni(w, j), w[S(367)] != null) {
      let z = r[w.image];
      j[S(360)] = z;
    }
    if (w[S(385)] != null) {
      let z = s[w[S(385)]];
      j[S(385)] = z;
    }
    if (w[S(364)] != null) {
      let z = i[w[S(364)]];
      j[S(347)](z);
    }
    return e[O] = j, j;
  }
  let m = a[t(384)](y);
  m[t(344)]((w) => {
    w[t(382)]();
  }), a.forEach((w, O) => {
    const S = t;
    let j = m[O];
    if (w[S(351)] != null) {
      let z = e[w[S(351)]];
      J0(z), z[S(374)](j);
    }
  });
  let p = a.filter((w) => w[t(356)]), k = m[t(368)]((w) => w[t(356)]);
  return p[t(344)](function(w, O) {
    let S = k[O];
    Hi(S, w, e), Ri(S, w, e);
  }), u;
}
function Ni(n, x) {
  const t = et;
  let e = x[t(363)], s = Object[t(378)](x);
  return e[t(344)]((i) => {
    const r = t;
    if (n[r(352)](i)) {
      let o = Object[r(366)](x, i);
      if (o == null && (o = Object[r(366)](s, i)), o != null && o.writable == ![])
        return;
      let a = n[i];
      a != null && a[r(361)] != null && (a = ys(a[r(361)], a)), x[i] = a;
    } else
      s[r(352)](i) && (x[i] = s[i]);
  }), x.id == null && (x.id = B0[t(386)]()), x;
}
function a1(n, x) {
  const t = et;
  let e = n[t(348)], s = ys(n[t(361)], n);
  if (s.isDisplayObjectId() && (s[t(348)] = x[e], s[t(348)] == null))
    throw new Error(t(383) + e);
  return J0(s, n), s;
}
function Ri(n, x, t) {
  const e = et, s = a1(x[e(373)], t);
  n.setBegin(s);
  const i = a1(x[e(369)], t);
  n.setEnd(i);
}
function ge() {
  const n = ["558112OvNQVe", "24002FecigP", "begin", "addChild", "assign", "Resources", "fromPojo", "getPrototypeOf", "Styles", "1280TieAhL", "40957wdMAyf", "removeAllChild", "找不到link的端点对象，序列化时有错误:", "map", "style", "next", "124473sjPxeX", "forEach", "3320tJjwpR", "364SbTFhq", "setShape", "target", "162kpndBC", "30123NxnMGk", "parent", "hasOwnProperty", "endArrow", "push", "src", "isLink", "label", "729891iMJYPa", "unkown class name: ", "imageSrc", "className", "beginArrow", "serializers", "shape", "Shapes", "getOwnPropertyDescriptor", "image", "filter", "end", "10sBLZcX"];
  return ge = function() {
    return n;
  }, ge();
}
function Hi(n, x, t) {
  const e = et;
  if (x[e(357)] != null) {
    let s = t[x[e(357)]];
    n[e(357)] = s;
  }
  if (x.beginArrow != null) {
    let s = t[x[e(362)]];
    n.beginArrow = s;
  }
  if (x.endArrow != null) {
    let s = t[x.endArrow];
    n[e(353)] = s;
  }
}
function et(n, x) {
  const t = ge();
  return et = function(e, s) {
    return e = e - 344, t[e];
  }, et(n, x);
}
function ys(n, x) {
  const t = et;
  let e;
  try {
    let s = $s(n);
    e = new s(), x && Object[t(375)](e, x);
  } catch {
    throw new Error(t(359) + n);
  }
  return e;
}
const f0 = ye;
(function(n, x) {
  const t = ye, e = n();
  for (; []; )
    try {
      if (-parseInt(t(189)) / 1 + -parseInt(t(202)) / 2 * (-parseInt(t(196)) / 3) + -parseInt(t(213)) / 4 + parseInt(t(215)) / 5 * (-parseInt(t(198)) / 6) + -parseInt(t(214)) / 7 + -parseInt(t(193)) / 8 * (parseInt(t(185)) / 9) + parseInt(t(199)) / 10 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(_e, 301492);
function _e() {
  const n = ["assign", "dirty", "DisplayObjects", "stringify", "forEach", "449064aPUJgc", "3092719GUZFeq", "15rYYLrN", "_restoreBackground", "Layer", "componentToObjects", "toPojo", "4338QsWptr", "numberFixed", "stage", "objectsToComponent", "241992UOpwGY", "copyToPojo", "Styles", "pojoToObjects", "8032wSyjjS", "setNumberFixed", "parse", "345531cuPskr", "toJson", "498000AsdYvH", "14849640EBTBDJ", "getState", "CustomStyle", "6xcfcaD", "toIdMap", "restore", "translateWith", "fillByJson", "className"];
  return _e = function() {
    return n;
  }, _e();
}
function ye(n, x) {
  const t = _e();
  return ye = function(e, s) {
    return e = e - 182, t[e];
  }, ye(n, x);
}
let Fi = /* @__PURE__ */ new Map();
const Rs = class {
  constructor() {
  }
  [f0(194)](n) {
    const x = f0;
    Rs[x(186)] = n;
  }
  [f0(184)](n, x = ![]) {
    return vs(n, x);
  }
  [f0(197)](n, x = ![]) {
    const t = f0;
    n instanceof D && (n = [n]);
    let e = this[t(184)](n, x);
    return JSON[t(211)](e);
  }
  [f0(192)](n, x) {
    return ws(n, x);
  }
  [f0(190)](n) {
    const x = f0;
    let t = vs(n);
    return t[x(210)][x(212)]((e) => {
      e.id = void 0;
    }), t;
  }
  static getEmptyInstance(n) {
    let x = Fi.get(n);
    return x == null && (x = ys(n)), x;
  }
  static getProtoDefaultProperties(n) {
    let x = n.serializers, t = Object.getPrototypeOf(n), e = {};
    for (var s = 0; s < x.length; s++) {
      let i = x[s], r = t[i], o = n[i];
      o === r && (e[i] = o);
    }
    return e;
  }
  [f0(183)](n) {
    const x = f0;
    let t = JSON.parse(n);
    return t[x(210)].forEach((i) => {
      delete i.id;
    }), ws(t);
  }
  [f0(188)](n) {
    const x = f0;
    let t = this.copyToPojo(n);
    return JSON[x(211)](t);
  }
  [f0(200)](n) {
    const x = f0;
    let t = vs([n]), e = Rs.getProtoDefaultProperties(n);
    return Object[x(208)](e, t), e;
  }
  [f0(206)](n, x) {
    const t = f0;
    let e = JSON[t(195)](x);
    n[t(187)].styleSystem.fromPojo(e[t(201)]);
    let s = e.DisplayObjects, i = s[0];
    if (i[t(207)] == t(182)) {
      const r = e[t(191)][i.style];
      n[t(216)](r), n.id = i.id;
    }
    return s[t(212)]((r) => B0.compare(r.id)), this.restore(n, e), n[t(209)] = !![], n[t(205)](0, 0), this;
  }
  [f0(204)](n, x) {
    const t = f0;
    if (n[t(209)] = !![], x != null) {
      let e = n[t(203)]();
      ws(x, e);
    }
    return x;
  }
};
let Tt = Rs;
Tt[f0(186)] = 6;
const X = me;
(function(n, x) {
  const t = me, e = n();
  for (; []; )
    try {
      if (parseInt(t(347)) / 1 + -parseInt(t(336)) / 2 + -parseInt(t(316)) / 3 * (-parseInt(t(315)) / 4) + -parseInt(t(328)) / 5 * (parseInt(t(346)) / 6) + parseInt(t(326)) / 7 + parseInt(t(329)) / 8 + -parseInt(t(352)) / 9 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Ie, 976866);
var Wi = Object.defineProperty, Yi = Object[X(325)], Xi = (n, x, t, e) => {
  const s = X;
  for (var i = e > 1 ? void 0 : e ? Yi(x, t) : x, r = n[s(353)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && Wi(x, t, i), i;
};
function me(n, x) {
  const t = Ie();
  return me = function(e, s) {
    return e = e - 313, t[e];
  }, me(n, x);
}
class nt {
  [X(313)]() {
    return this.target instanceof D;
  }
  [X(331)]() {
    const x = X;
    return this instanceof N0 || this instanceof ht || this instanceof vt ? this.target[x(351)] : ![];
  }
  isDisplayObjectId() {
    const x = X;
    return this instanceof N0 || this instanceof ht || this instanceof vt ? this[x(349)] != null && typeof this[x(349)] == "number" : ![];
  }
  [X(322)]() {
    const x = X;
    let t = this[x(333)], e = Object[x(319)]({ className: t }, this);
    return this[x(349)] == null && delete e[x(349)], e;
  }
}
Xi([b(X(337))], nt[X(344)], X(333), 2);
class ht extends nt {
  constructor(x, t, e = 0) {
    super(), this.target = x, this.t = t, this.segIndex = e;
  }
}
ht[X(344)][X(333)] = X(354);
function Ie() {
  const n = ["isNode", "20790990xIfTBP", "length", "EndpointSegment", "isDisplayObjectTarget", "nearest", "999728MYfEiM", "15mTHmVO", "normalize", "atan2", "assign", "isLikePoint", "unkow segIndex:", "toPojo", "isAutoFoldLink", "EndpointNearest", "getOwnPropertyDescriptor", "8231804SRHXMf", "getAngle", "31090zKuPKt", "7613496fbEcmV", "center", "isNodeTarget", "target is null", "className", "getPositionNormal", "log", "3849192ZzFskf", "Endpoint", "error arguments", "normal", "EndpointFunction", "segIndex", "points", "EndpointFixedName", "prototype", "ShapeNode", "114zCEXaB", "1952395MFpNlE", "name", "target", "function"];
  return Ie = function() {
    return n;
  }, Ie();
}
class N0 extends nt {
  constructor(x, t) {
    const e = X;
    super(), this.target = x, this[e(348)] = t;
  }
  [X(327)]() {
    return D1(this[X(348)]) + Math.PI;
  }
  getVec() {
    const x = X;
    return this[x(349)][x(351)] ? t1(this[x(348)]) : [0, 0];
  }
}
N0[X(344)][X(333)] = X(343);
class vt extends nt {
  constructor(x) {
    const t = X;
    super(), this[t(349)] = x;
  }
  [X(327)](x) {
    const t = X;
    let e = 0;
    if (this[t(349)][t(351)]) {
      let s = this.target;
      e = Math[t(318)](x.y - s.y, x.x - s.x);
    }
    return e;
  }
}
vt.prototype[X(333)] = X(324);
class Z0 extends nt {
  constructor(x, t) {
    super(), this.x = x, this.y = t;
  }
}
Z0[X(344)][X(333)] = "EndpointFixedPoint";
class Nx extends nt {
  constructor(x) {
    super(), this.fn = x;
  }
}
Nx[X(344)][X(333)] = X(340);
function Hs(n, x) {
  const t = X;
  if (n == null)
    throw new Error(t(332));
  if (n instanceof nt)
    return n;
  if (x instanceof nt)
    return x;
  if (n instanceof D)
    return x == L[t(314)] ? new vt(n) : new N0(n, x || L[t(330)]);
  if (M[t(320)](n)) {
    let e = n;
    return new Z0(e.x, e.y);
  } else {
    if (typeof n == t(350))
      return new Nx(n);
    throw console[t(335)](n, x), new Error(t(338));
  }
}
const qi = { lm: [-1, 0], ct: [0, -1], rm: [1, 0], cb: [0, 1] };
function Fs(n) {
  const x = X;
  if (n == null)
    return;
  let t = n[x(349)];
  if (typeof t != x(350)) {
    if (n instanceof N0)
      return t[x(333)] == x(345) ? t[x(334)](n[x(348)]) : qi[n[x(348)]];
    if (n instanceof ht) {
      let e = n[x(341)], s = n.t;
      if (t[x(333)] == x(345)) {
        let i = t.positionToLocalPoint(L[x(330)]), r = t.getLocalPoint(s, e);
        return q[x(339)](i, r);
      } else if (t instanceof Node) {
        if (e == 0)
          return [0, -1];
        if (e == 1)
          return [1, 0];
        if (e == 2)
          return [0, 1];
        if (e == 3)
          return [-1, 0];
        throw new Error(x(321) + e);
      }
      if (t[x(323)]) {
        let i = t[x(342)][e], r = t[x(342)][e + 1], o = [r.x - i.x, r.y - i.y];
        return F[x(317)]([], o);
      }
    }
  }
}
const a0 = ve;
(function(n, x) {
  const t = ve, e = n();
  for (; []; )
    try {
      if (-parseInt(t(384)) / 1 * (parseInt(t(395)) / 2) + -parseInt(t(400)) / 3 + parseInt(t(426)) / 4 + -parseInt(t(420)) / 5 * (-parseInt(t(399)) / 6) + -parseInt(t(406)) / 7 * (-parseInt(t(424)) / 8) + -parseInt(t(401)) / 9 * (-parseInt(t(405)) / 10) + -parseInt(t(381)) / 11 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(we, 284105);
function we() {
  const n = ["632456Ncymrn", "<line x1='", "rgb(36,36,36)", "' y1='0' x2='", "rgb(255,255,255)", "createDarkGridImg", "rgb(220,220,220)", "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 ", "rgb(21,21,21)", "colorFilter", "atob", "canvas", "' height='", "2172929WjxClv", "</svg>", "src", "12EOAVSZ", "' x2='", "createLightGridImg", "createElement", "match", "charCodeAt", "data:image/svg+xml;charset=UTF-8,", "svgToImageUrl", "function", "<line x1='0' y1='", "data", "40928fPhCdd", "canvasColorFilter", "split", "length", "2228382HdvHoA", "101922ysaZco", "81mmscqU", 'url("', "height", "width", "21260TParht", "21yaivMU", "imageToBase64", ";stroke-width:1;'/>", "putImageData", "willReadFrequently", "' style='stroke:", ";stroke-width:0.5'/>", "getImageData", "' y2='", "getContext", "ctx", "drawImage", "onload", `'>
<rect x='0' y='0' width='`, "5smBpbV", "createGridImage", "bgGrid", "toDataURL", "566776NvVhss", "image/png"];
  return we = function() {
    return n;
  }, we();
}
const B1 = document[a0(387)](a0(379));
let Gi = B1;
Gi[a0(410)] = !![];
const q0 = class {
  static bgGrid(n, x, t, e, s = "rgb(36,36,36)", i = a0(376)) {
    const r = a0;
    let o = r(375) + n + " " + x + r(419) + n + r(380) + x + "' style='fill:" + s + ";stroke:" + i + r(408), a = x / t, c = n / e;
    for (let l = 1; l <= t; l++)
      o += r(393) + a * l + r(385) + n + r(414) + a * l + r(411) + i + r(412);
    for (let l = 1; l <= e; l++)
      o += r(369) + c * l + r(371) + c * l + r(414) + x + "' style='stroke:" + i + r(412);
    return o += r(382), o = o.replace(/\n/g, ""), o;
  }
  static [a0(421)](n = 100, x = 100, t = 5, e = 5, s = "rgb(36,36,36)", i = a0(376)) {
    const r = a0;
    let o = q0[r(422)](n, x, t, e, s, i);
    return r(402) + q0.svgToImageUrl(o) + '")';
  }
  static [a0(386)]() {
    const n = a0;
    return q0[n(421)](100, 100, 5, 5, n(372), n(374));
  }
  static [a0(373)]() {
    const n = a0;
    return q0[n(421)](100, 100, 5, 5, n(370), n(376));
  }
  static [a0(391)](n) {
    return a0(390) + n;
  }
  static canvasColorFilter(n, x) {
    const t = a0, e = n[t(415)]("2d"), s = e[t(413)](0, 0, n[t(404)], n[t(403)]);
    let i = (o, a, c, l) => [x[0] * o / 255, x[1] * a / 255, x[2] * c / 255];
    typeof x == t(392) && (i = x);
    for (var r = 0; r < s[t(394)].length; r += 4) {
      let o = i(s[t(394)][r], s.data[r + 1], s.data[r + 2], s[t(394)][r + 3]);
      s[t(394)][r] = o[0], s[t(394)][r + 1] = o[1], s[t(394)][r + 2] = o[2], o[t(398)] > 3 && o[3] != null && (s[t(394)][r + 3] = o[3]);
    }
    e[t(409)](s, 0, 0);
  }
  static [a0(377)](n, x) {
    const t = a0, e = q0.canvas, s = q0[t(416)];
    e.width = n[t(404)], e[t(403)] = n[t(403)], s[t(417)](n, 0, 0), q0[t(396)](e, x);
    const i = new Image();
    return i[t(383)] = e[t(423)](t(425)), i;
  }
  static [a0(407)](n) {
    const x = a0, t = q0.canvas, e = q0.ctx;
    return t.width = n[x(404)], t[x(403)] = n.height, e[x(417)](n, 0, 0), t[x(423)]();
  }
};
let ft = q0;
ft[a0(379)] = B1, ft[a0(416)] = q0.canvas.getContext("2d");
function ve(n, x) {
  const t = we();
  return ve = function(e, s) {
    return e = e - 369, t[e];
  }, ve(n, x);
}
(function(n, x) {
  const t = R0, e = n();
  for (; []; )
    try {
      if (-parseInt(t(217)) / 1 + -parseInt(t(239)) / 2 + -parseInt(t(223)) / 3 * (-parseInt(t(226)) / 4) + parseInt(t(218)) / 5 * (-parseInt(t(208)) / 6) + -parseInt(t(181)) / 7 * (parseInt(t(190)) / 8) + parseInt(t(211)) / 9 * (parseInt(t(222)) / 10) + parseInt(t(204)) / 11 * (parseInt(t(215)) / 12) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Pe, 319825);
function Ui(n, x = ![]) {
  const t = R0;
  let e = D[t(198)](n[0][t(205)]);
  for (let u = 1; u < n[t(178)]; u++) {
    let y = D[t(198)](n[u].children, (m) => m[t(191)]);
    e = e.concat(y);
  }
  let s = n.concat(e), i = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), a = [], c = [], l = /* @__PURE__ */ new Map(), f = [];
  return s[t(197)]((u, y) => {
    const m = t;
    let p = u[m(221)];
    if (r.get(p) == null) {
      let O = a[m(178)];
      r[m(212)](p, O), a.push(p[m(231)]());
    }
    let k = u[m(188)];
    if (k != null && l[k] == null) {
      let O = Ki(u, x);
      f[m(179)]({ type: "img", src: O }), l[k] = f[m(178)] - 1;
    }
    let w = u[m(225)];
    if (u[m(236)] && o[m(228)](w) == null) {
      let O = c[m(178)];
      o.set(w, O), c.push(w[m(231)]());
    }
    i.set(u, y);
  }), { objects: s, objIndexMap: i, styleIndexMap: r, styles: a, resourcesIndexMap: l, resources: f, shapeIndexMap: o, shapes: c };
}
function vs(n, x = ![]) {
  const t = R0, e = {};
  e[t(206)] = Qs;
  const s = Ui(n, x);
  let i = s[t(177)], r = s[t(184)], o = s[t(219)], a = s.shapeIndexMap, c = s[t(240)];
  return e[t(189)] = n[t(207)]((l, f) => f), e.Styles = s[t(196)], e[t(200)] = s[t(176)], e[t(237)] = s[t(238)], e.DisplayObjects = i.map(function(l) {
    return Zi(l, r, o, c, a);
  }), e;
}
function Zi(n, x, t, e, s) {
  const i = R0;
  let r = {};
  if (n.isLayer)
    r[i(233)] = !![];
  else if (n.isNode)
    r[i(236)] = !![];
  else if (n.isLink)
    r[i(210)] = !![];
  else
    throw console[i(193)](n), new Error(i(173));
  Ji(r, n);
  let o = x.get(n[i(229)]);
  if (o != null && (r[i(229)] = o), n[i(210)] == !![]) {
    let l = n.begin, f = n[i(203)];
    r[i(183)] = c1(n, l, "begin", x), r[i(203)] = c1(n, f, i(203), x), n[i(187)] != null && (r.label = x.get(n[i(187)])), n[i(194)] != null && (r[i(194)] = x.get(n[i(194)])), n[i(175)] != null && (r[i(175)] = x.get(n[i(175)]));
  }
  let a = t[i(228)](n[i(221)]);
  J0(a), r.style = a;
  let c = e[n[i(188)]];
  if (c != null && (r.image = c), n[i(236)]) {
    let l = s[i(228)](n.shape);
    J0(l), r[i(225)] = l;
  }
  return r;
}
function c1(n, x, t, e) {
  const s = R0;
  let i = x.toPojo();
  if (x[s(213)] instanceof D) {
    let r = e[s(228)](x[s(213)]);
    if (r == null) {
      let o = t == "begin" ? n[s(202)]() : n[s(232)]();
      i.className = Z0.prototype[s(186)], i.x = o.x, i.y = o.y, delete i[s(213)];
    } else
      i[s(213)] = r;
  } else if (x instanceof Nx) {
    let r = x.fn();
    i[s(186)] = Z0[s(214)].className, i.x = r.x, i.y = r.y, delete i.target;
  }
  return i;
}
function R0(n, x) {
  const t = Pe();
  return R0 = function(e, s) {
    return e = e - 173, t[e];
  }, R0(n, x);
}
function Ji(n, x) {
  const t = R0, e = x[t(224)];
  return N1(n, x, e);
}
function N1(n, x, t) {
  const e = R0;
  let s = Tt.getEmptyInstance(x[e(186)]);
  for (var i = 0; i < t[e(178)]; i++) {
    let r = t[i], o = x[r];
    if (r == e(186)) {
      n[r] = o;
      continue;
    }
    if (o !== s[r]) {
      if (Array[e(209)](o) && Array[e(209)](s[r])) {
        let a = s[r];
        if (!Qi(a, o))
          n[r] = o;
        else
          continue;
      }
      if (r == e(182) && o != null) {
        o = JSON[e(185)](JSON[e(180)](o)), n[r] = o;
        continue;
      }
      if (o == null) {
        n[r] = o;
        continue;
      }
      typeof o == e(216) && Tt[e(192)] != null && (o = Vi(o, Tt[e(192)])), o[e(231)] != null ? o = o[e(231)]() : M[e(230)](o) && (o = new M(o.x, o.y)), n[r] = o;
    }
  }
}
function Pe() {
  const n = ["data:image/", "style", "10Kdvlxd", "390VOjMgj", "serializers", "shape", "2236CjuDMB", "imageToBase64", "get", "parent", "isLikePoint", "toPojo", "getEndPoint", "isLayer", "toFixed", "isInteger", "isNode", "Resources", "resources", "962680GXmOsI", "resourcesIndexMap", "unkonw object type:", "Styles", "endArrow", "shapes", "objects", "length", "push", "stringify", "1418543okHezM", "userData", "begin", "objIndexMap", "parse", "className", "label", "imageSrc", "Roots", "8bgpFcs", "serializeable", "numberFixed", "log", "beginArrow", "toString", "styles", "forEach", "flatten", "startsWith", "Shapes", "indexOf", "getBeginPoint", "end", "1116566sKnjPt", "children", "version", "map", "978RPcjnR", "isArray", "isLink", "1452393RxQmFT", "set", "target", "prototype", "168hEOsql", "number", "90923kkaBUK", "17190ckXJaY", "styleIndexMap"];
  return Pe = function() {
    return n;
  }, Pe();
}
function Vi(n, x) {
  const t = R0;
  if (Number[t(235)](n))
    return n;
  let e = n[t(195)]();
  return e.length - e[t(201)](".") - 1 > x && (n = n[t(234)](x), n = parseFloat(n)), n;
}
function Qi(n, x) {
  const t = R0;
  if (n === x)
    return !![];
  if (n.length != x[t(178)])
    return ![];
  for (let e = 0; e < n[t(178)]; e++)
    if (n[e] != x[e])
      return ![];
  return !![];
}
function Ki(n, x = ![]) {
  const t = R0;
  let e = n[t(188)];
  return e == null ? null : x == ![] || e[t(199)](t(220)) ? e : ft[t(227)](n.image);
}
function ke(n, x) {
  const t = Se();
  return ke = function(e, s) {
    return e = e - 261, t[e];
  }, ke(n, x);
}
function Se() {
  const n = ["28818ZjTfJw", "actualBoundingBoxRight", "actualBoundingBoxLeft", "getContext", "9700857exeYia", "231zgWPso", "createElement", "actualBoundingBoxDescent", "measureText", "width", "measureTextArraySize", "227845TDiNmm", "length", "795536IlJEAL", "font", "319344RcKIzg", "9018618XLXJCv", "2512400NMLBgN", "measureTextSize", "114oOsiqG"];
  return Se = function() {
    return n;
  }, Se();
}
const Et = ke;
(function(n, x) {
  const t = ke, e = n();
  for (; []; )
    try {
      if (-parseInt(t(264)) / 1 + -parseInt(t(269)) / 2 * (-parseInt(t(274)) / 3) + parseInt(t(262)) / 4 + parseInt(t(280)) / 5 * (-parseInt(t(268)) / 6) + parseInt(t(265)) / 7 + parseInt(t(266)) / 8 + -parseInt(t(273)) / 9 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Se, 647773);
const $i = document[Et(275)]("canvas"), Zt = $i[Et(272)]("2d");
class Ws {
  constructor() {
  }
  static [Et(267)](x, t) {
    const e = Et;
    Zt[e(263)] = t;
    const s = Zt[e(277)](x), i = s.actualBoundingBoxAscent + s[e(276)];
    return { width: s[e(270)] + s[e(271)], height: i };
  }
  static [Et(279)](x, t) {
    const e = Et;
    Zt[e(263)] = t;
    let s = Zt[e(277)](x[0]);
    for (let o = 0; o < x[e(261)]; o++) {
      let a = Zt[e(277)](x[o]);
      a[e(278)] > s[e(278)] && (s = a);
    }
    const i = s.actualBoundingBoxAscent + s[e(276)];
    return { width: s[e(270)] + s[e(271)], height: i };
  }
}
const b0 = lx;
function Oe() {
  const n = ["10px", "4onAFuG", "italicWeight", "toogleItalic", "family", "setBold", "764610mLgVth", "231416Hpebph", "setWeight", "616638crRUgv", "split", "153523gJvByf", "3661866RcbImo", "28TFEiHR", "510288TJPRjd", "setFamily", "setItalic", "boldWeight", "italic", "parseFontDesc", "normal", "size", "bold", "length", "2116180KNeNhY", "toogleBold", "toStyleFont"];
  return Oe = function() {
    return n;
  }, Oe();
}
function lx(n, x) {
  const t = Oe();
  return lx = function(e, s) {
    return e = e - 246, t[e];
  }, lx(n, x);
}
(function(n, x) {
  const t = lx, e = n();
  for (; []; )
    try {
      if (parseInt(t(264)) / 1 * (-parseInt(t(254)) / 2) + parseInt(t(259)) / 3 + -parseInt(t(260)) / 4 + -parseInt(t(250)) / 5 + -parseInt(t(262)) / 6 * (-parseInt(t(266)) / 7) + -parseInt(t(267)) / 8 + parseInt(t(265)) / 9 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Oe, 220914);
class yt {
  constructor(x) {
    const t = lx;
    this[t(270)] = t(246), this[t(255)] = "normal", this[t(247)] = t(253), this[t(257)] = "sans-serif", x != null && this[t(272)](x);
  }
  [b0(272)](x) {
    const t = b0, e = x[t(263)](" ");
    e.length > 3 ? (this[t(270)] = e[0], this[t(255)] = e[1], this.size = e[2], this[t(257)] = e[3], (e[0] === t(271) || e[1] === "bold") && (this[t(270)] = e[1], this.italicWeight = e[0])) : (this[t(270)] = e[0], this[t(247)] = e[1], this[t(257)] = e[2]);
  }
  getFontWeight() {
    const x = b0;
    return this[x(270)] + " " + this[x(255)];
  }
  [b0(261)](x) {
    const t = b0, e = x[t(263)](" ");
    e[t(249)] > 1 ? (this[t(270)] = e[0], this[t(255)] = e[1], (this[t(270)] === t(271) || this[t(255)] === "bold") && (this[t(270)] = e[1], this[t(255)] = e[0])) : x === t(248) ? this[t(270)] = "bold" : x === "italic" ? this[t(255)] = t(271) : this[t(270)] = t(246);
  }
  [b0(268)](x) {
    const t = b0;
    x === null || x === "" || (this[t(257)] = x);
  }
  setSize(x) {
    const t = b0;
    x === null || x === "" || (this[t(247)] = x);
  }
  [b0(258)](x) {
    const t = b0;
    x === null || x === "" || (this[t(270)] = x);
  }
  [b0(269)](x) {
    x === null || x === "" || (this.italicWeight = x);
  }
  [b0(251)]() {
    const x = b0;
    this[x(270)] === x(248) ? this.boldWeight = x(246) : this.boldWeight = x(248);
  }
  [b0(256)]() {
    const x = b0;
    this[x(255)] === x(271) ? this[x(255)] = x(246) : this.italicWeight = "italic";
  }
  [b0(252)]() {
    const x = b0;
    return this[x(270)] + " " + this[x(255)] + " " + this.size + " " + this.family;
  }
}
const P = Ce;
(function(n, x) {
  const t = Ce, e = n();
  for (; []; )
    try {
      if (-parseInt(t(460)) / 1 * (parseInt(t(423)) / 2) + parseInt(t(431)) / 3 * (-parseInt(t(492)) / 4) + parseInt(t(425)) / 5 + -parseInt(t(472)) / 6 + parseInt(t(474)) / 7 + -parseInt(t(469)) / 8 + parseInt(t(445)) / 9 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Le, 307261);
var tr = Object[P(400)], xr = Object[P(380)], er = (n, x, t, e) => {
  const s = P;
  for (var i = e > 1 ? void 0 : e ? xr(x, t) : x, r = n[s(405)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && tr(x, t, i), i;
};
function Le() {
  const n = ["measureTextArraySize", "this.", "38hjYhbH", "backgroundRepeat", "1578065lIeybZ", "strokeStyle", "match", "startY", "shadowOffsetY", "createElement", "1707OqjBQQ", "shadowOffsetX", "style", "shadowBlur", "getGradient", "merge", "borderStyle", "split", "_changed", "radiusStart", "createRadialGradient", "replace", "backgroundPositionYRate", "stopX", "5184918dvyTvw", "value", "dirty", "Style", "borderWidth", "miterLimit", "fromPojo", "number", "backgroundWidth", "no-repeat", "setWeight", "backgroundPositionXName", "defineProperties", "119119119046106116111112111046099111109", "borderColor", "2525bGBDqs", "addColorStop", "fillStyle", ",miterLimit,lineDashOffset,textPosition,color", "substring", "endsWith", "font", "_backgroundSize", "top", "204600yCEkyr", "cacheImg", "center", "2933598RNNGUk", "startX", "527296pXNQzX", "lineWidth", "string", "10px sans-serif", " === state.", "lineDash", "zIndex", "yStop", "assign", "backgroundHeightRate", "fillStyle,strokeStyle,lineWidth,padding", "updatezIndex", " !== state.", "setSize", "background", "className", "backgroundImage", "width", "684KGDHIy", '){ this._changed.push("', "backgroundSize", "getFontWeight", "push", "repetition", "_backgroundImage", "_preState", "set", "setLineDash", "backgroundPositionXRate", "type", "indexOf", "lineDashOffset", '");}', "updatePreState", "backgroundColor", "fontFamily", "_backgroundImageObject", "padding", ",font,textAlign,lineCap,lineJoin,lineDash,shadowBlur,shadowColor,shadowOffsetX,lineHeight,textBaseline", `
    return this._changed;
`, "bottom", "calcGap", "_border", "prototype", ",textOffsetX,textOffsetY,filter,imageSmoothingEnabled,globalCompositeOperation", "startsWith", "toStyleFont", "height", "lineJoin", "right", "url(", "shadowColor", "rate", ",borderStyle,borderColor,borderRadius,backgroundColor,borderWidth,globalAlpha", "xStop", "getOwnPropertyDescriptor", "backgroundPositionX", "filter", "pattern", "initial", "measureText", "createPattern", "getChanged", "lineHeight", "backgroundPositionY", "loadImage", "image", "cache", "setStyles", "backgroundPositionYName", "backgroundWidthRate", "radiusEnd", "keys", "backgroundPosition", "family", "defineProperty", "getBackgroundRect", `
    if(this.dirty){
        return true;
    }
    let state = this._preState;

    let noChange = `, "applyTo", "setFamily", "length", "yStart", "globalCompositeOperation", "globalAlpha", "colors", "stopY", "fontSize", "isDirty", "_backgroundPosition", "lineCap", "xStart", "textBaseline", "backgroundHeight", "textAlign", "if(this.", "measureTextSize"];
  return Le = function() {
    return n;
  }, Le();
}
let l1 = document[P(430)]("my");
function Ps(n) {
  const x = P;
  return typeof n == x(452) ? n : typeof n == "string" && n[x(465)]("px") ? parseFloat(n[x(464)](0, n[x(405)] - 2)) : n;
}
const R1 = class {
  constructor(n) {
    const x = P;
    this[x(447)] = !![], this[x(499)] = {}, this._changed = [], n != null && Object[x(482)](this, n);
  }
  [P(412)]() {
    const n = P;
    return this[n(447)] ? !![] : this[n(447)];
  }
  [P(387)]() {
    return [];
  }
  [P(507)]() {
    const n = P;
    if (this[n(412)]()) {
      let x = this.getChanged();
      for (let t = 0; t < x[n(405)]; t++) {
        let e = x[t];
        this[n(499)][e] = this[e];
      }
      return !![];
    }
    return ![];
  }
  reset() {
    const n = P;
    let x = Object[n(397)](this);
    for (let t = 0; t < x[n(405)]; t++) {
      let e = x[t];
      this[e] = rr[e];
    }
  }
  toPojo() {
    const n = P;
    let x = {}, t = [n(499), n(447), n(439)], e = Object[n(397)](this).filter((s) => t.indexOf(s) == -1);
    return N1(x, this, e), delete x[n(510)], x;
  }
  [P(393)](n) {
    const x = P;
    n != null && Object[x(482)](this, n);
  }
  [P(436)](n, x) {
    const t = P;
    let e = Object[t(397)](n);
    for (let s = 0; s < e[t(405)]; s++) {
      let i = e[s], r = n[i];
      x != null && (i == t(491) ? (r = Ps(r), x[t(491)] = r) : i == t(521) && (r = Ps(r), x[t(521)] = r), i == "zIndex" && (r = Ps(r), x[t(480)] = r, x[t(485)]())), this[i] = r;
    }
  }
  [P(500)](n, x) {
    this[n] = x;
  }
  [P(401)](n, x, t) {
    const e = P;
    let s = this[e(449)] || 0, i = s, r = s, o = n, a = x;
    if (this[e(453)] != null ? o = this.backgroundWidth : this[e(395)] != null ? o = n * this[e(395)] : this[e(510)] != null && (o = this._backgroundImageObject.width), this.backgroundHeight != null ? a = this[e(417)] : this.backgroundHeightRate != null ? a = x * this.backgroundHeightRate : this[e(510)] != null && (a = this._backgroundImageObject[e(521)]), this.backgroundPositionXName != null) {
      let l = this[e(456)];
      l == "center" ? i += n * 0.5 - o * 0.5 : l == "left" || l == e(523) && (i += n - o);
    } else
      this[e(381)] != null ? i += this[e(381)] : this[e(502)] != null && (i += n * this[e(502)]);
    if (this[e(394)] != null) {
      let l = this[e(394)];
      l == "center" ? r += x * 0.5 - a * 0.5 : l == "top" || l == "bottom" && (r += x - a);
    } else
      this[e(389)] != null ? r += this[e(389)] : this[e(443)] != null && (r += x * this[e(443)]);
    return this.backgroundRepeat == e(454), { x: i, y: r, width: o, height: a };
  }
  [P(403)](n) {
    const x = P, t = this;
    t[x(382)] != null && (n[x(382)] = t.filter), t.font != null && (n.font = t[x(466)]), t[x(418)] != null && (n[x(418)] = t[x(418)]), t[x(416)] != null && (n[x(416)] = t[x(416)]), t[x(462)] != null && (n[x(462)] = t.fillStyle), t[x(426)] != null && (n[x(426)] = t[x(426)]), t[x(414)] != null && (n.lineCap = t.lineCap), t.lineJoin != null && (n[x(522)] = t[x(522)]), t.lineWidth != null && (n.lineWidth = t[x(475)]), t[x(450)] != null && (n[x(450)] = t[x(450)]), t.lineDash != null ? n.setLineDash(t[x(479)]) : n[x(501)]([]), t[x(505)] != null && (n[x(505)] = t.lineDashOffset), t[x(408)] != null && (n[x(408)] = t[x(408)]), t.shadowBlur != null && (n[x(434)] = t[x(434)]), t[x(525)] != null && (n[x(525)] = t.shadowColor), t[x(432)] != null && (n[x(432)] = t.shadowOffsetX), t.shadowOffsetY != null && (n[x(429)] = t[x(429)]), t[x(407)] != null && (n[x(407)] = t[x(407)]);
  }
  [P(515)]() {
    const n = P;
    return (this[n(449)] || 0) * 2 + (this[n(511)] || 0) * 2 + (this.lineWidth || 0);
  }
  static [P(451)](n) {
    const x = P;
    let t = new R1(n);
    return n[x(498)] != null && (t[x(490)] = n._backgroundImage), t;
  }
  static [P(385)](n, x, t) {
    const e = P;
    let s;
    t == 1 ? s = Ws[e(420)](n, x[e(466)]) : s = Ws[e(421)](n, x[e(466)]);
    let i = s[e(491)], r = s[e(521)];
    if (x[e(388)] != null)
      r = x[e(388)];
    else {
      let a = x.font || e(477), c = a[e(427)](/.*?(\d+)px.*/);
      c != null && (r = parseInt(c[1]));
    }
    let o = r * t;
    return { width: i, height: o, lineHeight: r };
  }
  set [P(411)](n) {
    const x = P;
    if (n == null)
      return;
    let t = new yt(this[x(466)]);
    t[x(487)](n), this.font = t[x(520)]();
  }
  get [P(411)]() {
    return new yt(this.font).size;
  }
  set fontFamily(n) {
    const x = P;
    if (n == null)
      return;
    let t = new yt(this[x(466)]);
    t[x(404)](n), this.font = t[x(520)]();
  }
  get [P(509)]() {
    const n = P;
    return new yt(this[n(466)])[n(399)];
  }
  set fontWeight(n) {
    const x = P;
    if (n == null)
      return;
    let t = new yt(this[x(466)]);
    t[x(455)](n), this.font = t[x(520)]();
  }
  get fontWeight() {
    const n = P;
    return new yt(this[n(466)])[n(495)]();
  }
};
function Ce(n, x) {
  const t = Le();
  return Ce = function(e, s) {
    return e = e - 377, t[e];
  }, Ce(n, x);
}
let w0 = R1;
er([b(P(448))], w0.prototype, P(489), 2), Object[P(457)](w0[P(517)], { border: { get() {
  return this._border;
}, set(n) {
  const x = P;
  if (this.dirty = !![], n != null) {
    this[x(437)] = void 0, this[x(449)] = void 0, this[x(459)] = void 0;
    let t = n.toLowerCase()[x(442)](/\s+/ig, " ").split(" ");
    for (let e = 0; e < t[x(405)]; e++) {
      let s = t[e];
      nr(s) ? this[x(437)] = s : s[x(465)]("px") ? this.borderWidth = parseFloat(s[x(464)](0, s[x(405)] - 2)) : this[x(459)] = s;
    }
  }
  this[x(516)] = n;
} }, backgroundImage: { get() {
  return this._backgroundImage;
}, set(n) {
  const x = P;
  if (this[x(447)] = !![], this._backgroundImage = n, n != null && (n = n.trim(), n[x(519)](x(524)))) {
    this[x(510)] = void 0;
    let t = n[x(442)](/\s+/ig, " ");
    t = t[x(464)](5, t.length - 2), this._backgroundImage = t;
    let e = this;
    V0[x(390)](t, function(s) {
      e._backgroundImageObject = s;
    });
  }
} }, backgroundSize: { get() {
  return this[P(467)];
}, set(n) {
  const x = P;
  if (this[x(447)] = !![], this[x(467)] = n, n != null && n != x(384)) {
    let t = h1(n), e = t[0], s = t[1];
    e != null && (e[x(503)] == x(452) ? this.backgroundWidth = e[x(446)] : this[x(395)] = e[x(446)]), s != null && (s[x(503)] == x(452) ? this.backgroundHeight = s[x(446)] : this[x(483)] = s[x(446)]);
  }
} }, backgroundPosition: { get() {
  return this[P(413)];
}, set(n) {
  const x = P;
  if (this.dirty = !![], this[x(413)] = n, this[x(456)] = void 0, this[x(394)] = void 0, this[x(381)] = void 0, this[x(389)] = void 0, this[x(502)] = void 0, this.backgroundPositionYRate = void 0, n != null && n != "initial") {
    let t = h1(n), e = t[0], s = t[1];
    e != null && (e[x(503)] == x(452) ? this[x(381)] = e.value : e.type == x(377) ? this[x(502)] = e[x(446)] : this[x(394)] = e[x(446)]), s != null && (s[x(503)] == x(452) ? this.backgroundPositionY = s.value : s[x(503)] == "rate" ? this[x(443)] = s[x(446)] : this[x(456)] = s[x(446)]);
  }
} }, background: { get() {
  return this._background;
}, set(n) {
  const x = P;
  if (this[x(447)] = !![], this.backgroundWidth = null, this.backgroundHeight = null, this[x(395)] = null, this[x(483)] = null, this.backgroundPositionX = null, this[x(389)] = null, this[x(502)] = null, this.backgroundPositionYRate = null, this[x(498)] = null, this[x(490)] = null, n != null) {
    l1[x(433)][x(488)] = n;
    let t = l1[x(433)];
    this[x(508)] = t[x(508)], this[x(424)] = t[x(424)], this.backgroundRepeat == x(384) && (this[x(424)] = x(454)), this[x(490)] = t.backgroundImage, this[x(398)] = t.backgroundPosition, this[x(494)] = t[x(494)];
  }
  this._background = n;
} } });
function h1(n) {
  const x = P;
  let t = n[x(438)](" "), e = [];
  for (let s = 0; s < t[x(405)]; s++) {
    let i = t[s];
    if (i[x(405)] == 0)
      continue;
    if (i[x(465)]("px")) {
      let o = parseFloat(i[x(464)](0, i[x(405)] - 2));
      e[x(496)]({ type: x(452), value: o });
    } else if (i[x(465)]("%")) {
      let o = parseFloat(i[x(464)](0, i[x(405)] - 1)) / 100;
      e[x(496)]({ type: x(377), value: o });
    } else
      typeof i == x(476) && e[x(496)]({ type: x(476), value: i });
  }
  return e;
}
function nr(n) {
  return "none,hidden,dotted,dashed,solid,doubble,groove,ridge,inseet,outset,inherit"[P(504)](n) != -1;
}
V0.w != P(470) && (V0.w = P(458));
class sr {
  constructor(x, t, e, s) {
    const i = P;
    this.startX = 0, this[i(428)] = 0, this[i(444)] = 0, this[i(410)] = 0, this[i(392)] = ![], this[i(409)] = [], this.startX = x, this[i(428)] = t, this[i(444)] = e, this[i(410)] = s, this.cache = ![];
  }
  [P(461)](x, t) {
    const e = P;
    this[e(409)] == null && (this[e(409)] = []), this[e(409)].push([x, t]);
  }
  getGradient(x) {
    const t = P;
    let e = x.createLinearGradient(this[t(473)], this[t(428)], this.stopX, this.stopY);
    if (this[t(409)] != null)
      for (var s = 0; s < this[t(409)][t(405)]; s++) {
        let i = this.colors[s];
        e[t(461)](i[0], i[1]);
      }
    return e;
  }
}
class ir {
  constructor(x, t, e, s, i, r) {
    const o = P;
    this[o(415)] = 0, this[o(406)] = 0, this[o(440)] = 0, this[o(379)] = 0, this[o(481)] = 0, this.radiusEnd = 0, this[o(409)] = [], this[o(415)] = x, this[o(406)] = t, this.radiusStart = e, this[o(379)] = s, this[o(481)] = i, this[o(396)] = r;
  }
  [P(461)](x, t) {
    const e = P;
    this[e(409)] == null && (this.colors = []), this[e(409)][e(496)]([x, t]);
  }
  [P(435)](x) {
    const t = P;
    let e = x[t(441)](this[t(415)], this[t(406)], this[t(440)], this[t(379)], this[t(481)], this[t(396)]);
    if (this[t(409)] != null)
      for (var s = 0; s < this.colors[t(405)]; s++) {
        let i = this[t(409)][s];
        e[t(461)](i[0], i[1]);
      }
    return e;
  }
}
let rr = new w0();
class or {
  constructor(x, t) {
    const e = P;
    let s = this;
    this[e(391)] = x, typeof x == e(476) && (this[e(391)] = new Image(), this[e(391)].src = x, V0[e(390)](x, function(i) {
      s.image = i;
    })), this[e(497)] = t || e(454);
  }
  [P(435)](x) {
    const t = P;
    return this.pattern == null && (this[t(383)] = x[t(386)](this.image, this[t(497)])), this[t(383)];
  }
}
let xx = P(484);
xx += P(378), xx += P(512), xx += P(463), xx += P(518);
let ix = xx[P(438)](",");
{
  let n = "";
  for (let t = 0; t < ix[P(405)]; t++) {
    let e = ix[t];
    n += P(422) + e + P(478) + e, t + 1 < ix.length && (n += "&&");
  }
  let x = P(402) + n + `;

    if(!noChange){
        this.dirty = true;
    }
    return this.dirty;
`;
  w0[P(517)][P(412)] = new Function("", x);
}
{
  let n = "this._changed = [];";
  for (let t = 0; t < ix[P(405)]; t++) {
    let e = ix[t];
    n += P(419) + e + P(486) + e + P(493) + e + P(506);
  }
  let x = `
    let state = this._preState;
    ` + n + P(513);
  w0[P(517)].getChanged = new Function("", x);
}
function Rt(n, x) {
  const t = Ee();
  return Rt = function(e, s) {
    return e = e - 176, t[e];
  }, Rt(n, x);
}
(function(n, x) {
  const t = Rt, e = n();
  for (; []; )
    try {
      if (parseInt(t(184)) / 1 * (-parseInt(t(188)) / 2) + -parseInt(t(177)) / 3 * (parseInt(t(183)) / 4) + -parseInt(t(190)) / 5 * (parseInt(t(179)) / 6) + parseInt(t(182)) / 7 + parseInt(t(192)) / 8 + parseInt(t(181)) / 9 * (parseInt(t(186)) / 10) + parseInt(t(185)) / 11 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Ee, 640453);
let Jt;
function Ee() {
  const n = ["73620WsGSkM", "6115263bEfDmb", "4RDLgyk", "63072UjCGpU", "8789253LenhZi", "1030uNDQLt", "preventDefault", "26nfdmEK", "time", "1624915neUNwx", "previous", "5394320jJWatl", "type", "3237321nlvUWg", "DragEvent", "12aZoJsi", "isDouble"];
  return Ee = function() {
    return n;
  }, Ee();
}
function Ys(n) {
  const x = Rt;
  let t = new KeyboardEvent(n[x(176)], n), e = t[x(187)];
  if (t.preventDefault = function() {
    n[x(187)](), e.call(this);
  }, t[x(191)] = Jt, Jt) {
    const s = n.key == Jt.key;
    let i = t[x(189)] - Jt.time;
    s && i < 400 && (t[x(180)] = !![]);
  }
  return Jt = t, t;
}
function ar(n, x) {
  const t = Rt;
  let e = {};
  x instanceof WheelEvent ? e = new WheelEvent(n, x) : window[t(178)] && x instanceof window[t(178)] ? e = new DragEvent(n, x) : x instanceof MouseEvent ? e = new MouseEvent(n, x) : x instanceof TouchEvent && (e = new TouchEvent(n, x));
  let s = e[t(187)];
  return e[t(187)] = function() {
    x[t(187)](), s.call(this);
  }, e.raw = x, e;
}
let v0 = class {
  constructor(x) {
    this.type = x;
  }
};
class H1 {
  constructor(x) {
    const t = Rt;
    this[t(176)] = x;
  }
}
const h = Me;
(function(n, x) {
  const t = Me, e = n();
  for (; []; )
    try {
      if (parseInt(t(505)) / 1 + parseInt(t(513)) / 2 + -parseInt(t(667)) / 3 + parseInt(t(665)) / 4 * (parseInt(t(688)) / 5) + -parseInt(t(686)) / 6 + parseInt(t(672)) / 7 * (parseInt(t(576)) / 8) + -parseInt(t(632)) / 9 * (parseInt(t(656)) / 10) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Te, 368039);
var cr = Object[h(575)], lr = Object.getOwnPropertyDescriptor, x0 = (n, x, t, e) => {
  const s = h;
  for (var i = e > 1 ? void 0 : e ? lr(x, t) : x, r = n[s(553)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && cr(x, t, i), i;
};
let F1 = new v0(h(512)), W1 = new v0(h(595)), Y1 = new v0("touchend"), X1 = new v0("mousedown"), q1 = new v0(h(657)), G1 = new v0(h(525)), U1 = new v0("mouseover"), Z1 = new v0(h(546)), J1 = new v0(h(612)), V1 = new v0("mouseenter"), Q1 = new v0(h(610)), K1 = new v0(h(603)), $1 = new v0("mousedragend");
function Me(n, x) {
  const t = Te();
  return Me = function(e, s) {
    return e = e - 498, t[e];
  }, Me(n, x);
}
let ti = new v0("selected");
function Te() {
  const n = ["重复添加", "addInLink", "skewY", "name", "getChildrenAABB", "css", "_obb", "dirty", "querySelector", "editable", "mousemove", "toLayerXY", "getOBBPoints", "getPoint", "push", "toAABB", "removeChild", "deep", "pickUp", "getK", "addClass", "selectedStyle", "prototype", "DisplayObject", "transformPoint", "getLinks", "localPoints", "isOutOfParent", "rect", "getAncestors", "getChildren", "click", "removeAt", "isMouseInPath", "render", "rotation", "zIndex", "draggable", "length", "vec", "添加自己为子节点了2", "getAllVisiable", "next", "segIndex out of bounds.", "paintSelected", "map", "getOBB", "touchstartHandler", "getTransform", "_isOutOfViewport", "concat", "paintChildrenWhenOutOfViewport", "mousedownHandler", "userData", "match", "mouseEnabled", "inLinks", "startsWith", "mousedragHandler", "painted", "defineProperty", "478376pVqHHI", "_getPickRadius", "serializers", "aabb", "getAllLinks", "setStyles", "getLayerTransform", "removeFromParent", "skewX", "mousePickupStroke", "points", "getUserData", "parent", "atan2", "updateZIndex", "string", "destroyed", "getCS", "updateChildrenDeep", "touchmove", "substring", "mousemoveHandler", "_destory", "stageToLocalXY", "point", "connectable", "互为子节点了", "mousedrag", "showSelected", "isVisible", "hasChildren", "link", "depth", "setUserData", "mouseout", "style", "dblclick", "indexOf", "getRoot", "replaceChild", "pickUpChild", "isSelected", "_OBBPoints", "getTopFrozenParent", "updatezIndex", "selectedHandler", "width", "_findChildren", "stageToLocalVec", "getStageTransform", "className", "hide", "definePosition arguments error.", "height", "getPaintedAABBInLayer", "removeClass", "9npoJLc", "classList", "dispatchEvent", "definePosition", "calculatePointOnMultiPointLine", "toObjectLocalXY", "hasListener", "positions", "upgradeParent", "mouseupHandler", "visible", "getAABB", "toIdMap", "children", "flatten", "transform", "addChilds", "mousePickupPath", "forEach", "mouseoutHandler", "upgradeLinks", "serializeable", "reset", "dblclickHandler", "15673930tLpGqU", "mouseup", "isIntersectRect", "pickType", "remove", "isPointOn", "setZIndex", "frozen", "function", "12amEadN", "hasChild", "204096KLuOXC", "touchendHandler", "scaleX", "notContains", "lineWidth", "77LNqgLI", "getTransformByDeep", "sort", "reverse", "replace child not found", "setzIndex", "_style", "removeInLink", "invert", "isAncestors", "toStageXY", "getStyle", "clickHandler", "origin", "1362600RTMWgO", "localAABB", "886175bitBRC", "_pickRadius", "unselectedHandler", "log", "removeOutLink", "union", "setOrigin", "set", "535975xinuMe", "isMouseInStroke", "dontNeedPickup", "unselected", "addOutLink", "scaleY", "outLinks", "touchstart", "1010234uEKBLR", "filter"];
  return Te = function() {
    return n;
  }, Te();
}
let xi = new v0(h(508)), Xs = new H1(h(660));
const ex = class extends K0 {
  constructor() {
    const n = h;
    super(), this.id = 0, this[n(566)] = !![], this[n(564)] = ![], this.id = B0[n(557)](), this[n(645)] = [], this[n(647)] = new _s(), this[n(611)] = new w0(), this[n(678)] = new w0(), this[n(633)] = [], this[n(685)] = [0, 0], this[n(639)] = {}, this.inLinks = [], this[n(511)] = [];
  }
  getAABB(n, x) {
    const t = h;
    if (x == null)
      throw new Error("minDeep is required.");
    let e = this[t(521)];
    if (e != null && x === z0)
      return this._obb[t(579)];
    this[t(521)] = this[t(561)](x), e = this[t(521)];
    let s = e[t(579)].clone();
    if (n && this[t(606)]()) {
      const r = this.getChildrenAABB(n, x);
      q.union(s, r);
    }
    let i = this[t(678)][t(671)] || 0;
    return i != 0 && (s.x -= i * 0.5, s.y -= i * 0.5, s[t(622)] += i, s[t(629)] += i), s;
  }
  [h(573)](n) {
    const x = h;
    if (this.dispatchEvent(K1), this[x(570)] == ![] || this[x(552)] == ![])
      return;
    let t = this[x(588)].stageToLocalVec([n.dx, n.dy]);
    this.translateWith(t[0], t[1]);
  }
  [h(503)](n, x) {
    const t = h;
    return this[t(685)][0] = n, this[t(685)][1] = x, this;
  }
  [h(556)]() {
    throw new Error("getAllVisiable() not implements");
  }
  [h(539)](n) {
    const x = h;
    return this[x(563)]()[x(600)](n);
  }
  [h(563)]() {
    const n = h;
    return y0[n(593)](this)[n(563)](this);
  }
  [h(683)](n) {
    return this[h(611)][n];
  }
  [h(581)](n) {
    return this[h(520)](n);
  }
  [h(605)]() {
    return this[h(642)];
  }
  [h(520)](n, x) {
    const t = h;
    if (typeof n == t(591) && x != null) {
      let e = n;
      n = {}, n[e] = x;
    }
    return this[t(611)].merge(n, this), this[t(611)][t(522)] = !![], this;
  }
  clearCss() {
    const n = h;
    this.style[n(654)](), this[n(611)][n(522)] = !![];
  }
  [h(535)](n) {
    const x = h;
    Z.remove(this[x(633)], n), this[x(633)][x(529)](n), this[x(611)][x(522)] = !![];
  }
  [h(631)](n) {
    const x = h;
    Z[x(660)](this[x(633)], n), this[x(611)][x(522)] = !![];
  }
  [h(673)](n) {
    const x = h;
    return y0.getCS(this)[x(673)](this, n);
  }
  [h(582)]() {
    const n = h;
    return y0[n(593)](this)[n(673)](this, z0);
  }
  getStageTransform() {
    const n = h;
    return y0[n(593)](this)[n(673)](this, z1);
  }
  show() {
    const n = h;
    return this[n(522)] = !![], this[n(642)] = !![], this;
  }
  [h(627)]() {
    const n = h;
    return this.dirty = !![], this[n(642)] = ![], this;
  }
  [h(649)](n, x) {
    const t = h, e = n.render;
    if (this[t(661)] = ![], !e[t(507)](this)) {
      if (this[t(659)] == "rect") {
        this.isPointOn = !![];
        return;
      }
      this[t(661)] = e[t(548)](x);
    }
  }
  [h(585)](n, x) {
    const t = h;
    this[t(661)] = ![];
    const e = n[t(549)];
    e.dontNeedPickup(this) || (x == null && (x = this[t(498)]), this.isPointOn = e[t(506)](x, null));
  }
  [h(609)](n) {
    return this.userData = n, this;
  }
  [h(587)]() {
    return this.userData;
  }
  removeUserData() {
    const n = h;
    return this[n(568)] = void 0, this;
  }
  [h(635)](n, x) {
    const t = h;
    if (n == null || x == null)
      throw new Error(t(628));
    this[t(639)][n] = x;
  }
  getPositionNames() {
    return Object.keys(this.positions);
  }
  getPoint(n, x) {
    return this.getLocalPoint(n, x);
  }
  getLocalPoint(n, x) {
    const t = h;
    let e = this.getSegmentPoints(), s = e.length - 1;
    if (x != null) {
      if (x >= s)
        throw console[t(500)](this), console.log(x, s), new Error(t(558));
      e = [e[x], e[x + 1]];
    }
    return M[t(636)](e, n);
  }
  [h(623)](n, x, t = ![]) {
    const e = h;
    let s = this, i = s[e(645)], r = [], o = typeof x == e(664);
    for (var a = 0; a < i[e(553)]; a++) {
      let c = i[a];
      if (o ? x(c) && r[e(529)](c) : c[n] == x && r.push(c), t) {
        let l = c._findChildren(n, x, t);
        r = r[e(565)](l);
      }
    }
    return r;
  }
  querySelectorAll(n) {
    const x = h;
    let t, e, s = n, i, r = n[x(569)](/(.*)\s*(\[.*\])/);
    if (r && (s = r[1], i = r[2]), s[x(572)](".") ? e = (o) => o[x(633)][x(613)](s) != -1 : s[x(572)]("#") ? e = (o) => o.id == s[x(596)](1) : s != "" && (e = (o) => o.className == s), i != null && (t = i.match(/\[\s*(.*?)\s*([>|<|=]{1,2})\s*['"]{0,1}(.*?)['"]{0,1}]$/)) != null) {
      let o = t[1], a = t[2], c = t[3], l = (u) => "" + u[o] == c;
      a == ">" ? l = (u) => u[o] > parseInt(c) : a == ">=" ? l = (u) => u[o] >= parseInt(c) : a == "<" ? l = (u) => u[o] < parseInt(c) : a == "<=" && (l = (u) => u[o] <= parseInt(c));
      let f = l;
      return e != null && (f = (u) => e(u) && l(u)), this._findChildren(o, f, !![]);
    }
    return this[x(623)](s, e, !![]);
  }
  [h(523)](n) {
    return this.querySelectorAll(n)[0];
  }
  getAllNodes() {
    return this._findChildren("isNode", !![], !![]);
  }
  [h(580)]() {
    return this[h(623)]("isLink", !![], !![]);
  }
  [h(562)](n) {
    const x = h;
    this[x(570)] == !![] && this[x(634)](F1);
  }
  [h(668)](n) {
    const x = h;
    this[x(570)] == !![] && this[x(634)](Y1);
  }
  touchmoveHandler(n) {
    const x = h;
    this[x(570)] == !![] && this[x(634)](W1);
  }
  [h(567)](n) {
    this[h(570)] == !![] && this.dispatchEvent(X1);
  }
  [h(641)](n) {
    const x = h;
    this[x(570)] == !![] && this[x(634)](q1);
  }
  mouseoverHandler(n) {
    const x = h;
    this[x(570)] == !![] && this[x(634)](U1);
  }
  [h(597)](n) {
    const x = h;
    this[x(570)] == !![] && this[x(634)](G1);
  }
  mouseenterHandler(n) {
    const x = h;
    this.mouseEnabled == !![] && this[x(634)](V1);
  }
  [h(651)](n) {
    const x = h;
    this[x(570)] == !![] && this[x(634)](Q1);
  }
  mousedragEndHandler(n) {
    const x = h;
    this[x(570)] == !![] && this[x(634)]($1);
  }
  [h(684)](n) {
    const x = h;
    this[x(570)] == !![] && this[x(634)](Z1);
  }
  [h(655)](n) {
    const x = h;
    this[x(570)] == !![] && this[x(634)](J1);
  }
  [h(621)]() {
    const n = h;
    this[n(570)] == !![] && (this[n(617)] = !![], this[n(634)](ti));
  }
  [h(499)]() {
    const n = h;
    this[n(617)] = ![], this[n(570)] == !![] && this[n(634)](xi);
  }
  [h(533)](n, x) {
    const t = h;
    let e = this[t(616)](n);
    if (e == null && this[t(661)] && this.visible && (this[t(570)] == ![] && x != !![] || (e = this)), e != null) {
      let s = e[t(619)]();
      s != null && (e = s);
    }
    return e;
  }
  pickUpChild(n, x = ![]) {
    const t = h, e = this;
    let s = e[t(645)];
    if (this.visible == ![])
      return null;
    for (var i = s[t(553)] - 1; i >= 0; i--) {
      let r = s[i];
      if (r[t(574)] == ![] && r.children[t(553)] > 0 && e[t(566)] == ![])
        continue;
      let o = r.pickUp(n, x);
      if (o != null)
        return o;
    }
    return null;
  }
  addChild(n) {
    const x = h;
    return hr(this, n), this[x(522)] = !![], this;
  }
  [h(662)](n) {
    const x = h;
    this.zIndex = n, this[x(588)] && this[x(588)].updateZIndex(), this[x(522)] = !![];
  }
  [h(677)](n) {
    return this[h(662)](n);
  }
  [h(590)]() {
    const n = h;
    this[n(645)][n(674)](function(x, t) {
      const e = n;
      return x[e(551)] - t[e(551)];
    }), this[n(522)] = !![];
  }
  [h(620)]() {
    return this[h(590)]();
  }
  updateChildrenDeep(n = ![]) {
    const x = h;
    if (this[x(645)][x(553)] > 0) {
      const t = this[x(645)];
      for (let e = 0; e < t[x(553)]; e++) {
        const s = t[e];
        s[x(532)] = this.deep + 1, s[x(645)][x(553)] > 0 && s[x(594)](n);
      }
    }
  }
  [h(545)]() {
    return this[h(645)];
  }
  [h(666)](n) {
    const x = h;
    return this[x(645)][x(613)](n) != -1;
  }
  [h(606)]() {
    const n = h;
    return this[n(645)][n(553)] > 0;
  }
  [h(583)]() {
    const n = h;
    return this[n(588)] && this.parent[n(531)](this), this[n(522)] = !![], this;
  }
  [h(660)]() {
    return this[h(583)]();
  }
  [h(648)](n) {
    const x = h;
    this[x(522)] = !![];
    for (var t = 0; t < n[x(553)]; t++) {
      let e = n[t];
      e[x(588)] = this, e[x(532)] = this[x(532)] + 1, this[x(645)][x(529)](e), e[x(606)]() && e[x(594)](!![]);
    }
    this[x(620)]();
  }
  [h(531)](n) {
    const x = h;
    this[x(522)] = !![];
    let t = this[x(645)][x(613)](n);
    return t == -1 ? this : (Z[x(547)](this[x(645)], t), n.parent = null, n[x(634)](Xs), this);
  }
  removeChilds(n) {
    for (var x of n)
      this.removeChild(x);
    return this;
  }
  removeAllChild() {
    const n = h;
    return this[n(522)] = !![], this.children[n(650)](function(x) {
      const t = n;
      x[t(588)] = null, x.dispatchEvent(Xs);
    }), this[n(645)][n(553)] = 0, this[n(522)] = !![], this;
  }
  [h(615)](n, x) {
    const t = h, e = this[t(645)][t(613)](n);
    if (e == -1)
      throw new Error(t(676));
    this[t(645)][e] = x, n[t(588)] = null, x[t(588)] = this;
  }
  [h(630)]() {
    const n = h;
    return this[n(521)][n(579)];
  }
  [h(519)](n, x) {
    return ei(this, n, x);
  }
  [h(614)]() {
    const n = h;
    let x = this;
    for (; x.parent != null; )
      x = x[n(588)];
    return x;
  }
  [h(599)](n, x) {
    const t = h;
    return this[t(625)]()[t(680)]()[t(600)]({ x: n, y: x });
  }
  [h(624)](n) {
    const x = h;
    return this[x(625)]()[x(680)]()[x(554)]([], n);
  }
  [h(682)](n, x) {
    const t = h;
    return this[t(625)]()[t(600)]({ x: n, y: x });
  }
  [h(526)](n, x) {
    const t = h;
    return this.getLayerTransform()[t(600)]({ x: n, y: x });
  }
  [h(637)](n, x, t) {
    const e = h;
    let s = this[e(682)](n, x);
    return t[e(599)](s.x, s.y);
  }
  [h(516)](n) {
    const x = h;
    if (this[x(522)] = !![], this[x(571)] == null && (this.inLinks = []), this[x(571)][x(529)](n), this[x(638)](x(516))) {
      let t = new Event("addInLink");
      t[x(607)] = n, this[x(634)](t);
    }
  }
  [h(509)](n) {
    const x = h;
    if (this[x(522)] = !![], this[x(511)][x(529)](n), this[x(638)](x(509))) {
      let t = new Event(x(509));
      t.link = n, this[x(634)](t);
    }
  }
  [h(679)](n) {
    const x = h;
    if (this[x(522)] = !![], Z[x(660)](this.inLinks, n), this.hasListener("removeInLink")) {
      let t = new Event(x(679));
      t[x(607)] = n, this.dispatchEvent(t);
    }
  }
  removeOutLink(n) {
    const x = h;
    if (this[x(522)] = !![], this.outLinks != null && Z[x(660)](this[x(511)], n), this.hasListener("removeOutLink")) {
      let t = new Event(x(501));
      t[x(607)] = n, this[x(634)](t);
    }
  }
  [h(540)]() {
    const n = h;
    let x = [];
    return this[n(571)] && (x = x[n(565)](this[n(571)])), this[n(511)] && (x = x.concat(this.outLinks)), x;
  }
  [h(561)](n = z0) {
    const x = h;
    let t = this[x(618)]();
    if (this[x(532)] < n)
      return new Mt(t);
    let e = this.getTransformByDeep(n), s = e[x(586)](t), i = new Mt(s);
    return i[x(541)] = t, i[x(687)] = Mt[x(530)](i.localPoints), i;
  }
  [h(527)]() {
    const n = h;
    let x = this[n(521)];
    return x == null && (x = this[n(643)](![], z0), this[n(521)] = x), x[n(586)];
  }
  [h(534)](n, x) {
    const t = h;
    let e = this[t(528)](x - 1e-4, n), s = this.getPoint(x + 1e-4, n), i = s.x - e.x, r = s.y - e.y;
    return Math[t(589)](r, i);
  }
  [h(652)]() {
    const n = h;
    return this[n(540)]()[n(560)]((t) => {
      t[n(640)]();
    })[n(514)]((t) => t != null);
  }
  [h(542)]() {
    const n = h;
    let x = this, t = x[n(588)];
    if (t != null) {
      const e = x[n(643)](![], z0);
      return !t[n(643)](![], z0)[n(658)](e);
    }
    return ![];
  }
  [h(619)]() {
    const n = h;
    let x = this[n(544)]();
    for (let t = 0; t < x[n(553)]; t++)
      if (x[t][n(663)])
        return x[t];
    return null;
  }
  [h(544)]() {
    const n = h;
    if (this[n(588)] == null)
      return [];
    let x = this, t = [];
    for (; x[n(588)] != null; )
      t[n(529)](x[n(588)]), x = x[n(588)];
    return t[n(675)]();
  }
  [h(681)](n) {
    const x = h;
    if (this === n[x(588)])
      return !![];
    let t = n[x(544)]();
    return Z[x(666)](t, this);
  }
  [h(577)]() {
    return this[h(498)];
  }
  [h(644)]() {
    const n = h;
    let x = ex.flatten(this[n(645)]), t = /* @__PURE__ */ new Map();
    return x[n(650)]((e) => {
      t[n(504)](e.id, e);
    }), t[this.id] = this, t;
  }
  [h(598)]() {
    const n = h;
    this[n(592)] = !![], this[n(588)] && this.parent[n(531)](this), this.listeners = void 0, this[n(611)] = void 0, this.children = void 0, this[n(647)] = void 0, this[n(639)] = void 0, this[n(521)].aabb = void 0, this[n(685)] = void 0, this.userData = void 0, this.inLinks = void 0, this[n(511)] = void 0;
  }
  static [h(646)](n, x) {
    const t = h;
    let e = [];
    for (var s = 0; s < n[t(553)]; s++) {
      let i = n[s];
      if ((x == null || x(i) == !![]) && (e[t(529)](i), i[t(645)] && i[t(645)][t(553)] > 0)) {
        let r = ex.flatten(i[t(645)], x);
        e = e.concat(r);
      }
    }
    return e;
  }
  static getNoChildrensObjects(n) {
    const x = h;
    let t = ex.flatten(n);
    return t = ex[x(646)](n, (e) => {
      const s = x;
      return Z[s(670)](t, e[s(588)]);
    }), t;
  }
  static [h(643)](n, x = ![], t = z0) {
    const e = h;
    let s = n[0].getAABB(x, t).clone();
    for (let i = 1; i < n[e(553)]; i++)
      s = q[e(502)](s, n[i][e(643)](x, t));
    return s;
  }
};
let D = ex;
x0([b(h(538))], D[h(537)], h(626), 2), x0([b(h(543))], D[h(537)], h(659), 2), x0([b(null)], D[h(537)], h(559), 2), x0([b(![])], D[h(537)], h(574), 2), x0([b(![])], D[h(537)], h(661), 2), x0([b(!![])], D[h(537)], h(522), 2), x0([b(5)], D.prototype, h(498), 2), x0([b(![])], D[h(537)], h(592), 2), x0([b(["className", "id", h(518), h(551), "frozen", h(524), h(536), h(570), "connectable", h(568), h(604), "draggable", "visible", "origin", "classList"])], D[h(537)], h(578), 2), x0([b(0)], D[h(537)], h(551), 2), x0([b(0)], D[h(537)], h(608), 2), x0([b(![])], D.prototype, "frozen", 2), x0([b(1)], D[h(537)], h(669), 2), x0([b(1)], D[h(537)], h(510), 2), x0([b(0)], D.prototype, h(584), 2), x0([b(0)], D[h(537)], h(517), 2), x0([b(0)], D[h(537)], "deep", 2), x0([b(0)], D.prototype, h(550), 2), x0([b(!![])], D.prototype, "visible", 2), x0([b(!![])], D[h(537)], h(604), 2), x0([b(!![])], D[h(537)], h(653), 2), x0([b(!![])], D[h(537)], h(601), 2), x0([b(!![])], D[h(537)], "mouseEnabled", 2), x0([b(!![])], D[h(537)], h(552), 2), x0([b(![])], D[h(537)], h(617), 2), x0([b(!![])], D[h(537)], h(524), 2);
function ei(n, x, t) {
  const e = h;
  let s = new q(0, 0, 0, 0);
  if (n[e(606)]()) {
    let r = n[e(545)]();
    s = r[0][e(643)](x, t);
    for (var i = 1; i < r[e(553)]; i++) {
      let a = r[i], c = a.getAABB(x, t);
      q[e(502)](s, c);
    }
  }
  return s;
}
function hr(n, x) {
  const t = h;
  if (n === x)
    throw console[t(500)](n), new Error(t(555));
  if (Z[t(666)](n[t(544)](), x) && (console[t(500)](t(602)), console.log(n, x)), n[t(588)] === x && (console[t(500)]("互为子节点了2"), console[t(500)](n, x)), n[t(522)] = !![], x[t(588)] = n, x[t(532)] = n[t(532)] + 1, n.children[t(613)](x) != -1)
    throw console[t(500)](n, x), new Error(t(515));
  return n[t(645)][t(529)](x), x[t(645)][t(553)] > 0 && x[t(594)](!![]), n.updatezIndex(), n;
}
(function(n, x) {
  const t = je, e = n();
  for (; []; )
    try {
      if (parseInt(t(299)) / 1 * (parseInt(t(307)) / 2) + parseInt(t(306)) / 3 + -parseInt(t(308)) / 4 + -parseInt(t(304)) / 5 + parseInt(t(295)) / 6 + -parseInt(t(300)) / 7 + parseInt(t(301)) / 8 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Ae, 320922);
function Ae() {
  const n = ["getChildren", "scaleBy", "hasChildren", "MIN_SAFE_INTEGER", "scaleY", "796116ysgDqz", "resizeTo", "translateWith", "height", "1cDwPZN", "274260HxWmeJ", "6781808frJAGF", "scaleX", "length", "1174120VqHlEM", "width", "192084Sqzqib", "18188SvIKWF", "1834432gJwzRS", "toStageXY", "MAX_SAFE_INTEGER"];
  return Ae = function() {
    return n;
  }, Ae();
}
function je(n, x) {
  const t = Ae();
  return je = function(e, s) {
    return e = e - 291, t[e];
  }, je(n, x);
}
function fr(n, x, t, e, s) {
  const i = je;
  let r = n[i(305)] * n[i(302)], o = n[i(298)] * n[i(294)], a = r * x - r, c = o * t - o;
  if (e != null && s != null) {
    let l = { x: n.width * 0.5, y: n[i(298)] * 0.5 }, f = n[i(309)](l.x, l.y), u = (e - f.x) / 2, y = (s - f.y) / 2;
    x >= 1 ? (a += u, c += y) : (a -= u * x, c -= y * t);
  }
  n[i(297)](-(a / 2), -(c / 2)), n[i(291)](x, t);
}
function hx(n, x) {
  var t = ze();
  return hx = function(e, s) {
    e = e - 237;
    var i = t[e];
    return i;
  }, hx(n, x);
}
function ze() {
  var n = ["84CXsZCh", "2705304aTjpSm", "2987976ijbDJo", "styleY", "9VrCNJV", "rgba(255,0,0,0.9)", "30842450FwFAQl", "191766gLncZD", "rgba(0,255,0, 0.9)", "rgba(0,255,0, 0.4)", "1964PpIHwC", "60KHTuLx", "737337faGrqz", "styleX", "top", "right", "7847768vkievE", "hide", "visible"];
  return ze = function() {
    return n;
  }, ze();
}
var ur = hx;
(function(n, x) {
  for (var t = hx, e = n(); []; )
    try {
      var s = parseInt(t(248)) / 1 + -parseInt(t(237)) / 2 + -parseInt(t(238)) / 3 + -parseInt(t(246)) / 4 * (parseInt(t(247)) / 5) + parseInt(t(243)) / 6 * (parseInt(t(255)) / 7) + -parseInt(t(252)) / 8 + parseInt(t(240)) / 9 * (parseInt(t(242)) / 10);
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(ze, 869607);
class dr {
  constructor() {
    var x = hx;
    this[x(254)] = ![], this.lineDashScale = 1, this[x(249)] = new w0({ strokeStyle: "rgba(255,0,0,0.3)", fillStyle: x(241), textAlign: x(251), textBaseline: x(250), lineWidth: 1 }), this[x(239)] = new w0({ strokeStyle: x(245), fillStyle: x(244), textBaseline: "bottom", lineWidth: 1 });
  }
  show() {
    this.visible = !![];
  }
  [ur(253)]() {
    this.visible = ![];
  }
}
const Fx = Be;
(function(n, x) {
  const t = Be, e = n();
  for (; []; )
    try {
      if (-parseInt(t(445)) / 1 + -parseInt(t(441)) / 2 * (-parseInt(t(446)) / 3) + parseInt(t(434)) / 4 + parseInt(t(439)) / 5 * (parseInt(t(437)) / 6) + -parseInt(t(447)) / 7 * (parseInt(t(435)) / 8) + parseInt(t(438)) / 9 + parseInt(t(443)) / 10 * (-parseInt(t(433)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(De, 309233);
function De() {
  const n = ["2342ytFhhv", "_jtopo_debug_mode", "10VDMcyH", "getItem", "180367QcVQkP", "1473wYQGiD", "14qeymeQ", "8122939lLBnkL", "994120MBioDY", "639256BZKtJL", "setItem", "30hSZlSM", "2174598yLRCQr", "322750njpGmm", "true"];
  return De = function() {
    return n;
  }, De();
}
let Pt = { isDebug: localStorage[Fx(444)](Fx(442)) == Fx(440), showFPS: ![], paintAABB: ![], debugInfo: null, debugMode: function() {
  const n = Fx;
  let x = localStorage.getItem(n(442)) == n(440), t = !x;
  localStorage[n(436)](n(442), "" + t), Pt.isDebug = t;
} };
function Be(n, x) {
  const t = De();
  return Be = function(e, s) {
    return e = e - 433, t[e];
  }, Be(n, x);
}
(function(n, x) {
  for (var t = Re, e = n(); []; )
    try {
      var s = -parseInt(t(473)) / 1 * (-parseInt(t(472)) / 2) + parseInt(t(476)) / 3 + parseInt(t(481)) / 4 + -parseInt(t(474)) / 5 * (-parseInt(t(477)) / 6) + parseInt(t(479)) / 7 + parseInt(t(480)) / 8 + -parseInt(t(475)) / 9;
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Ne, 123600);
function Ne() {
  var n = ["12RNnAib", "25743DLZVKC", "5BYYfom", "3703995LVZgeQ", "207378KXSFKp", "320586oWmALo", "length", "1247057yHwUwC", "521280tyjqzr", "59316PCqvLs"];
  return Ne = function() {
    return n;
  }, Ne();
}
function Re(n, x) {
  var t = Ne();
  return Re = function(e, s) {
    e = e - 472;
    var i = t[e];
    return i;
  }, Re(n, x);
}
class ms {
  constructor(x) {
    var t = Re;
    this[t(478)] = 0, this.x = x.x, this.y = x.y;
  }
}
(function(n, x) {
  const t = m0, e = n();
  for (; []; )
    try {
      if (-parseInt(t(508)) / 1 + parseInt(t(509)) / 2 + parseInt(t(523)) / 3 * (parseInt(t(478)) / 4) + parseInt(t(501)) / 5 + -parseInt(t(510)) / 6 * (-parseInt(t(492)) / 7) + parseInt(t(511)) / 8 * (parseInt(t(514)) / 9) + -parseInt(t(481)) / 10 * (-parseInt(t(482)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(He, 690649);
function pr(n, x, t, e) {
  const s = m0, i = n.x, r = x.x, o = n.y, a = x.y, c = [r - i, a - o];
  F[s(504)](c, c);
  const l = [-c[1] * e, c[0] * e], f = M[s(490)](n, l, t), u = M[s(490)](x, l, t);
  return [f, u];
}
function br(n, x, t) {
  const e = m0, s = n.x, i = x.x, r = n.y, o = x.y, a = [i - s, o - r];
  F[e(504)](a, a);
  const c = [-a[1] * t, a[0] * t], l = M[e(490)](n, c, 1), f = M[e(490)](x, c, 1);
  return [l[0], f[0]];
}
function gr(n, x, t) {
  const e = m0, s = [n.x - x.x, n.y - x.y], i = [t.x - x.x, t.y - x.y], r = F.normalize([], i), o = F[e(480)](s, r), a = F[e(499)]([], r, o);
  return a[e(507)] = o, a;
}
function _r(n, x, t) {
  const e = m0, s = gr(n, x, t), i = [t.x - x.x, t.y - x.y], r = F[e(520)](i), o = s[e(507)] / r, a = new ms();
  return a.x = x.x + s[0], a.y = x.y + s[1], a.segLen = r, a[e(507)] = s[e(507)], a[e(518)] = o, a;
}
function yr(n, x, t) {
  const e = m0, s = [n.x - x.x, n.y - x.y], i = [t.x - x.x, t.y - x.y], r = F[e(504)]([], i), o = F[e(520)](i);
  let a;
  const c = F[e(480)](s, r);
  if (c > o)
    a = t;
  else if (c < 0)
    a = x;
  else {
    let f = F[e(499)]([], r, c);
    a = { x: x.x + f[0], y: x.y + f[1] };
  }
  let l = new ms(a);
  return l.segLen = o, l[e(507)] = c, l[e(518)] = c / o, l;
}
function He() {
  const n = ["end", "points", "isNode", "lenght of points less than 2", "multiplyC", "positionToLocalPoint", "1657475NZtgLk", "getStageTransform", "length", "normalize", "stageToLocalXY", "dist", "projectionLen", "1019075XFTwgF", "181666nCEfJC", "24quprga", "10928IFkQfr", "segIndex", "unkwnow object!", "5139dTjAxK", "number of points is less than 2", "distancePoint", "object", "rate", "getOBBPoints", "len", "isLink", "MAX_SAFE_INTEGER", "538887Mhavdg", "error segIndex:", "4SmhUXm", "begin", "dot", "70PsjrrM", "481789FlZUye", "abs", "push", "getEndPoint", "getOBB", "getBeginPoint", "toFixed", "seg", "createPointsBidirectional", "segLen", "37079GbwOrU", "point", "concat"];
  return He = function() {
    return n;
  }, He();
}
function x1(n, x) {
  const t = m0;
  if (x[t(503)] < 2)
    throw new Error(t(515));
  let e = new ms(x[0]), s = Number.MAX_SAFE_INTEGER;
  for (let i = 0; i < x[t(503)] - 1; i++) {
    const r = x[i], o = x[i + 1], a = yr(n, r, o), c = M.distancePoint(a, n);
    c < s && (e = a, e[t(489)] = [r, o], e[t(506)] = c, e[t(512)] = i, s = c);
  }
  return e;
}
function Fe(n, x, t, e, s = ![]) {
  const i = m0, r = [x.x - n.x, x.y - n.y], o = [e.x - t.x, e.y - t.y], a = F.normalize([], [-r[1], r[0]]), c = F[i(504)]([], [-o[1], o[0]]), l = a[0], f = a[1], u = c[0], y = c[1], m = l * y - u * f;
  if (m == 0)
    return null;
  const p = F[i(480)](a, [n.x, n.y]), k = F[i(480)](c, [t.x, t.y]), w = { x: (y * p - f * k) / m, y: (l * k - u * p) / m };
  return s == ![] && (!f1(w, n, x) || !f1(w, t, e)) ? null : w;
}
function ni(n, x, t, e = ![]) {
  const s = m0;
  if (t[s(503)] < 2)
    throw new Error(s(498));
  let i = [];
  for (var r = 0; r < t[s(503)] - 1; r++) {
    const o = t[r], a = t[r + 1];
    let c = Fe(n, x, o, a, e);
    c != null && i[s(484)](c);
  }
  return i = mr(i), i;
}
function f1(n, x, t) {
  const e = m0;
  let s = [t.x - x.x, t.y - x.y], i = F[e(520)](s), r = { x: (x.x + t.x) / 2, y: (x.y + t.y) / 2 }, o = [n.x - r.x, n.y - r.y];
  return F[e(520)](o) <= i * 0.5 + 1e-8;
}
function m0(n, x) {
  const t = He();
  return m0 = function(e, s) {
    return e = e - 477, t[e];
  }, m0(n, x);
}
function mr(n) {
  const x = m0;
  let t = {}, e = [];
  for (var s = 0; s < n[x(503)]; s++) {
    let i = n[s], r = i.x[x(488)](6) + "-" + i.y[x(488)](6);
    t[r] == null && (e[x(484)](i), t[r] = i);
  }
  return e;
}
function Ir(n, x, t, e) {
  const s = m0;
  let i = Number[s(522)], r = null, o = n.getTransform();
  for (var a = 0; a < t.length; a++) {
    const c = t[a], l = o[s(496)](c[s(519)]());
    c[s(497)] && l[s(484)](l[0]), j1(l[s(503)] >= 2, c, l);
    let f = x1(x, l);
    f.dist < i && f[s(506)] < e && (i = f.dist, f[s(517)] = c, r = f);
  }
  return r;
}
function wr(n, x, t) {
  const e = m0;
  let s = Number.MAX_SAFE_INTEGER, i;
  for (let r = 0; r < x[e(503)]; r++) {
    const o = x[r];
    let a = o[e(502)](), c = o.getAnchorPoints();
    for (let l = 0; l < c[e(503)]; l++) {
      let f = c[l], u = a[e(493)](o[e(500)](f)), y = M[e(516)](u, n);
      y < s && y < t && (s = y, i = { object: o, anchorName: f });
    }
  }
  return i;
}
function vr(n, x) {
  const t = m0;
  let e = n[t(512)], s = n[t(518)], i = n[t(517)], r = s >= 0.25 && s <= 0.75, o = s - 0.5, a = Math[t(483)](n[t(491)] * o);
  if (i[t(497)]) {
    if (a > x || !r)
      return null;
    if (e == 0)
      return L.ct;
    if (e == 1)
      return L.rm;
    if (e == 2)
      return L.cb;
    if (e == 3)
      return L.lm;
    throw new Error(t(477) + e);
  } else if (i[t(521)]) {
    let c = i[t(505)](n.x, n.y);
    return M.distancePoint(c, i[t(487)]()) <= x ? L[t(479)] : M.distancePoint(c, i[t(485)]()) <= x ? L[t(495)] : null;
  } else
    throw new Error(t(513));
}
function qx(n) {
  const x = m0;
  return Math[x(483)](Math[x(483)](n) % Math.PI) < 0.5;
}
function qs(n, x, t) {
  return n < x ? x : n > t ? t : n;
}
const Vt = st;
function st(n, x) {
  const t = We();
  return st = function(e, s) {
    return e = e - 200, t[e];
  }, st(n, x);
}
(function(n, x) {
  const t = st, e = n();
  for (; []; )
    try {
      if (-parseInt(t(215)) / 1 + parseInt(t(200)) / 2 * (-parseInt(t(236)) / 3) + parseInt(t(227)) / 4 * (-parseInt(t(228)) / 5) + -parseInt(t(205)) / 6 * (-parseInt(t(214)) / 7) + parseInt(t(234)) / 8 + -parseInt(t(235)) / 9 + parseInt(t(217)) / 10 * (parseInt(t(240)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(We, 937096);
function Pr(n, x, t) {
  const e = st;
  t = t | 1;
  const s = document.createElementNS(e(202), e(248));
  return s.setAttribute("xmlns", e(202)), s.style = e(216) + n + "px;height:" + x + e(225) + t + ";", s[e(251)] = e(201) + t + e(250), s;
}
function kr(n) {
  const x = st;
  let t = document[x(230)](x(255));
  t.width = n[x(203)][x(237)] ? +n[x(203)].width : n[x(237)], t[x(241)] = n[x(203)][x(241)] ? +n[x(203)][x(241)] : n[x(241)];
  let e = t[x(223)]("2d");
  return e[x(226)](t.width / n[x(218)], t[x(241)] / n[x(220)]), e[x(222)](n, 0, 0), x(252) + n[x(237)] + x(239) + n[x(241)] + x(209) + t[x(208)](x(238)) + x(239) + n[x(241)] + x(219) + n[x(237)] + x(232);
}
async function Sr(n) {
  const x = st, t = n[x(233)](/\<br\>/gi, x(253)), e = t[x(249)](/<img .*?>/g);
  if (e == null || e[x(245)] == 0)
    return new Promise(function(i) {
      i([[], []]);
    });
  const s = [];
  return new Promise(function(i) {
    const r = x;
    e[r(221)](function(o) {
      const a = r, c = document[a(230)]("div");
      c[a(251)] = o;
      const l = c[a(213)](a(243));
      l[a(204)] = function() {
        const f = a, u = kr(l);
        s.push(u), s[f(245)] == e[f(245)] && i([e, s]);
      };
    });
  });
}
class si {
  constructor(x, t, e, s = 1) {
    const i = st;
    this[i(212)] = !![], this[i(237)] = 1, this.height = 1, this.opacity = 1, this[i(212)] = !![], x !== null && x[i(231)](i(242)) && (x = x[i(246)](i(242).length)), this[i(229)] = x, this.width = t, this[i(241)] = e, this[i(207)] = s | 1, this[i(248)] = Pr(t, e, this[i(207)]), this[i(255)] = document[i(230)](i(255));
  }
  setSize(x, t) {
    const e = st;
    this[e(237)] = x, this[e(241)] = t;
  }
  [Vt(206)](x) {
    const t = Vt;
    if (x != t(211))
      throw new Error(t(247));
    return t(242) + this[t(229)];
  }
  setHtml(x) {
    const t = Vt;
    this[t(229)] = x;
  }
  [Vt(210)]() {
    const x = Vt;
    let t = this[x(229)];
    const e = this[x(248)], s = this;
    let i = s.canvas, r = i[x(223)]("2d");
    return i[x(203)][x(237)] = s.width + "px", i[x(203)][x(241)] = s.height + "px", i.width = s.width, i[x(241)] = s[x(241)], new Promise(function(o) {
      const a = x;
      Sr(t)[a(244)](function(c) {
        const l = a, f = c[0], u = c[1];
        for (let p = 0; p < f[l(245)]; p++)
          t = t[l(233)](f[p], u[p]);
        const y = e.querySelector(l(224));
        y.innerHTML = t;
        let m = new Image();
        m.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(s.svg[l(254)]), m.onload = function() {
          const p = l;
          r[p(222)](m, 0, 0, s[p(237)], s[p(241)]), o(i);
        };
      });
    });
  }
}
function We() {
  const n = ["outerHTML", "canvas", "242556MYAXdW", '<foreignObject width="100%" height="100%" style="position:absolute;top:0;left:0; opacity: ', "http://www.w3.org/2000/svg", "style", "onload", "402OreqYD", "getAttribute", "opacity", "toDataURL", '" display="inline" style="vertical-align: middle;display: inline-block"><image xlink:href="', "getCanvas", "src", "isHtmlImage", "querySelector", "36827cqixQq", "1860340XXIagD", "border:0px;position:absolute;top:0px;left:0px;text-align:center;z-index:10;width:", "15430970MfBvJi", "naturalWidth", 'px" width="', "naturalHeight", "forEach", "drawImage", "getContext", "foreignObject", "px;opacity:", "scale", "4DYtKUz", "8742595YLaHhi", "html", "createElement", "startsWith", 'px" /></svg>', "replace", "11944920cohArR", "198063wkMqie", "9AehGev", "width", "image/png", '" height="', "22OCgmxN", "height", "HtmlImage", "img", "then", "length", "substring", "HtmlImage has only src attr", "svg", "match", `;">
        '</foreignObject>`, "innerHTML", '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink= "http://www.w3.org/1999/xlink" width="', "<div/>"];
  return We = function() {
    return n;
  }, We();
}
const d = fx;
(function(n, x) {
  const t = fx, e = n();
  for (; []; )
    try {
      if (parseInt(t(346)) / 1 + parseInt(t(285)) / 2 + parseInt(t(392)) / 3 + -parseInt(t(327)) / 4 * (-parseInt(t(394)) / 5) + -parseInt(t(363)) / 6 + -parseInt(t(395)) / 7 * (parseInt(t(422)) / 8) + parseInt(t(420)) / 9 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Ye, 754466);
var Or = Object.defineProperty, Lr = Object[d(399)], r0 = (n, x, t, e) => {
  const s = d;
  for (var i = e > 1 ? void 0 : e ? Lr(x, t) : x, r = n[s(369)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && Or(x, t, i), i;
};
function fx(n, x) {
  const t = Ye();
  return fx = function(e, s) {
    return e = e - 276, t[e];
  }, fx(n, x);
}
function Ye() {
  const n = ["resizeTo", "165860cTsqDd", "32627xQwKMf", "alignOriginToNode", "call", "lineWidth", "getOwnPropertyDescriptor", "rect", "_drawBackgroundAndBorder", "origin", "borderColor", "draw", "next", "imageSmoothingEnabled", "rotate", "serializers", "save", "borderRadius", "end", "textRotation", "fill", "mousePickupPath", "roundRect", "rotateCenter", "isDirty", "split", "_imageSrc", "7056009csYxWV", "_textDirty", "720pEQyIz", "src", "setImage", "textBaseline", "color", "left", "concat", "top", "repeat-y", "getBackgroundRect", "height", "dotted", "createPattern", "init", "restore", "center", "stroke", "canvas", "positionToLocalPoint", "prototype", "fillText", "_resLoadedBack", "1466012FDPlEu", "isClosed", "style", "dirty", "position not exist:", "width", "_textHeight", "getLinkChildren", "no-repeat", "number", "_calcTextPosition", "strokeStyle", "shape", "same parent, dont need change", "setLineDash", "clip", "resizeToFitImage", "originAlignPosition", "stageToLocalXY", "textPosition", "_getShapeSize", "translateTo", "pickType", "nearest", "mousePickupStroke", "resizeWith", "_style", "addChild", "_textArr", "outLinks", "getCtrlPoints", "closePath", "setOriginToPosition", "_paintText", "borderStyle", "drawShape", "backgroundColor", "strokeAndFill", "className", "scaleBy", "right", "hasChild", "64ghqtgY", "defineProperties", "normal", "_OBBPoints", "parent", "originAutoRotate", "canceled", "getRect", "isPointOn", "loadImage", "getLocalPoint", "rotation", "backgroundRepeat", "function", "rotateWith", "toStageXY", "translate", "_text", "scaleY", "429695JAdmgQ", "textAlign", "alignOriginToLink", "isNode", "zIndex", "zoomOut", "_textLineHeight", "setShape", "image", "rotateTo", "assign", "scale", "textOffsetY", "dashed", "translatePositionTo", "measureText", "originOffset", "8984784UlhYsV", "positions", "Rect", "tagName", "setXY", "getAttribute", "length", "zoom", "scaleX", "fillRect", "setRotateCenter", "text", "textOffsetX", "black", "borderWidth", "calcTextSize", "getSegmentPoints", "setOrigin", "fillStyle", "_image", "beginPath", "translateWith", "getPositionNormal", "Node", "getImage", "push", "target", "IMG", "_textWidth", "581898DQGlPx"];
  return Ye = function() {
    return n;
  }, Ye();
}
const ii = class extends D {
  constructor(n, x = 0, t = 0, e = 1, s = 1) {
    const i = d;
    super(), this.x = 0, this.y = 0, this.x = x || 0, this.y = t || 0, this.width = e || 0, this[i(432)] = s || 0, this[i(374)] = n;
  }
  [d(353)](n) {
    const x = d;
    this[x(297)] = n;
  }
  [d(348)](n, x, t, e) {
    const s = d;
    x != null && (this.originOffset = x), this[s(302)] = n, this[s(373)](n), t != null && this[s(380)](t, this[s(402)][1]), e != null && this[s(380)](this[s(402)][0], e);
  }
  [d(396)](n, x = d(278)) {
    const t = d;
    let e = lt[x];
    this[t(380)](e.x, e.y), this[t(302)] = n;
  }
  [d(330)]() {
    let x = this[d(290)] * 0.5, t = this.height * 0.5, e = -x, s = -t;
    return [{ x: e, y: s }, { x, y: s }, { x, y: t }, { x: e, y: t }];
  }
  [d(305)]() {
    const n = d, x = this._style;
    let t = x.borderWidth || 0, e = x.lineWidth || 0, s = x.padding || 0;
    const i = this[n(290)] - t * 2 - e - s * 2, r = this[n(432)] - t * 2 - e - s * 2;
    return { width: i, height: r };
  }
  [d(379)]() {
    const n = d, x = this[n(330)]();
    return this[n(297)].isClosed && x.push(x[0]), x;
  }
  [d(387)](n) {
    const x = this;
    return new Promise((t, e) => {
      const s = fx;
      if (x.image != null) {
        n ? n(x[s(354)]) : t(x[s(354)]);
        return;
      }
      let i = x[s(284)];
      if (i == null) {
        n ? n(null) : e(null);
        return;
      }
      n == null && (n = function() {
        t(x.image);
      }), i[s(405)] = n;
    });
  }
  [d(424)](n, x = ![]) {
    const t = d;
    let e = this, s = n, i = this[t(284)];
    if (i != null && (i[t(333)] = !![], delete this[t(284)]), s == null || s == "")
      return this[t(419)] = null, this[t(354)] = null, this;
    if (s[t(366)] == t(390))
      return this._imageSrc = s.getAttribute(t(423)), e[t(354)] = s, x == !![] && e[t(393)](s[t(290)], s[t(432)]), this;
    if (s[t(366)] == "CANVAS")
      return this[t(419)] = t(280), this[t(354)] = s, x == !![] && this[t(393)](s[t(290)], s[t(432)]), this;
    this[t(284)] = function(o) {
      const a = t;
      e[a(354)] = o, s instanceof si ? e[a(419)] = s[a(368)]("src") : e._imageSrc = o[a(368)](a(423)), x == !![] && e[a(393)](o.width, o[a(432)]);
    };
    let r = s;
    return V0[t(336)](r, this[t(284)]), this;
  }
  setText(n) {
    const x = d;
    if (n != this._text && (this[x(421)] = !![]), n == null) {
      this._text = n;
      return;
    }
    if (typeof n == x(294) && (n = "" + n), n.indexOf(`
`) != -1) {
      let t = n[x(418)](`
`);
      this[x(313)] = t;
    } else
      this[x(313)] = null;
    this[x(344)] = n, this[x(378)]();
  }
  calcTextSize() {
    const n = d;
    let x = this._textArr == null ? 1 : this[n(313)][n(369)], t;
    x == 1 ? t = w0.measureText(this._text, this[n(311)], x) : t = w0[n(361)](this[n(313)], this[n(311)], x), this._textWidth = t[n(290)], this[n(291)] = t[n(432)], this[n(352)] = t.lineHeight;
  }
  attr(n) {
    return Object[d(356)](this, n), this.dirty = !![], this;
  }
  [d(301)]() {
    const n = d;
    this[n(382)] != null && this[n(382)][n(290)] != null && this[n(393)](this._image[n(290)], this[n(382)][n(432)]);
  }
  [d(276)](n, x, t, e, s) {
    const i = d;
    this[i(288)] = !![], this.x = x || 0, this.y = t || 0, this.width = e || 0, this[i(432)] = s || 0, this[i(374)] = n;
  }
  drawShape(n) {
    const x = d;
    let t = this._getShapeSize();
    n.scale(t[x(290)], t.height), this[x(297)][x(404)](n, null, this), n[x(357)](1 / t.width, 1 / t[x(432)]);
  }
  [d(401)](n) {
    const x = d;
    let t = this[x(311)], e = t[x(377)] || 0;
    const s = e > 0;
    let i = -this[x(290)] * 0.5 + e * 0.5, r = -this[x(432)] * 0.5 + e * 0.5, o = this[x(290)] - e, a = this.height - e;
    const c = t[x(321)] != null;
    if (c) {
      n[x(398)] = e, n[x(381)] = t[x(321)], n[x(296)] = t.borderColor || x(376);
      let u = t.borderRadius || 0;
      (t[x(319)] == x(359) || t[x(319)] == x(433)) && n[x(299)]([1, 1]), n[x(383)](), u == 0 ? n.rect(i, r, o, a) : n[x(415)](i, r, o, a, u), n[x(413)]();
    }
    if (s) {
      if (!c) {
        n[x(398)] = e, n[x(381)] = t[x(321)], n[x(296)] = t[x(403)] || x(376);
        let u = t[x(410)] || 0;
        (t[x(319)] == x(359) || t.borderStyle == x(433)) && n[x(299)]([1, 1]), n[x(383)](), u == 0 ? n[x(400)](i, r, o, a) : n[x(415)](i, r, o, a, u), n[x(316)]();
      }
      n[x(279)]();
    }
    const l = this[x(354)] || this.style._backgroundImageObject, f = l != null;
    return f && this._drawImage(n, l, s, c, e), s || c || f;
  }
  _drawImage(n, x, t, e, s) {
    const i = d;
    if (this._imageSrc != null && this._imageSrc.toLowerCase().endsWith("svg")) {
      n.drawImage(x, -this[i(290)] * 0.5, -this[i(432)] * 0.5, this[i(290)], this.height);
      return;
    }
    const r = this[i(287)];
    let o = this[i(290)] - s - s, a = this[i(432)] - s - s, c = r[i(431)](o, a, this), l = -this[i(290)] * 0.5, f = -this.height * 0.5, u = l + c.x, y = f + c.y, m = c[i(290)], p = c[i(432)], k = x[i(290)], w = x[i(432)];
    const O = r[i(339)] || "no-repeat";
    if (O == i(293)) {
      n[i(406)] = r[i(406)] == null ? !![] : r[i(406)], n.drawImage(x, 0, 0, k, w, u, y, m, p);
      return;
    }
    (t || e) && n[i(300)]();
    let S = n[i(434)](x, O);
    n[i(381)] = S;
    let j = u % k, z = y % w;
    O == "repeat-x" ? z = 0 : O == i(430) && (j = 0), n.translate(j, z), n[i(372)](l - k, f - w, o + k + k, a + w + w), n[i(343)](-j, -z);
  }
  [d(322)](n) {
    const x = d;
    let t = this._style;
    n[x(409)](), this[x(401)](n) && this[x(414)](n), n.beginPath(), this[x(320)](n), t[x(381)] != null && (n[x(381)] = t[x(381)], n[x(413)]()), (t[x(398)] || 0) != 0 && t[x(296)] != null && (n.lineWidth = t[x(398)], n[x(296)] = t.strokeStyle, n.stroke()), this[x(335)] == ![] && this[x(307)] == x(297) && (this.shape[x(286)] ? this[x(414)](n) : this[x(309)](n, this._getPickRadius())), n[x(277)]();
  }
  [d(404)](n) {
    const x = d;
    this.width != 0 && this.height != 0 && this.strokeAndFill(n), this[x(318)](n);
  }
  _isTextOrStyleDirty() {
    const n = d;
    return this[n(421)] || this[n(287)][n(417)]();
  }
  _calcTextPosition(n = 0, x = 0) {
    const t = d;
    this._isTextOrStyleDirty() && this[t(378)]();
    let e = this._style, s = null;
    e[t(304)] != null ? s = this[t(281)](e.textPosition) : s = { x: 0, y: this[t(432)] * 0.5 };
    let i = 0, r = -(this[t(291)] - this[t(352)]) * 0.5;
    return e.textAlign == t(427) ? i = n + x : e[t(347)] == t(325) && (i = -(n + x)), e.textBaseline == t(429) ? r = n + x : e[t(425)] == "bottom" && (r = -(n + x) - this[t(291)] + this[t(352)]), s.x += i, s.y += r, e[t(375)] != null && (s.x += e.textOffsetX), e[t(358)] != null && (s.y += e.textOffsetY), s;
  }
  [d(318)](n) {
    const x = d;
    let t = this[x(344)];
    if (t == null)
      return;
    let e = this._style, s = this[x(295)](), i = this[x(313)];
    if (n[x(381)] = e[x(426)] || "black", this[x(412)] == 0)
      if (i == null)
        n[x(283)](t, s.x, s.y);
      else {
        let o = this[x(352)];
        for (var r = 0; r < i.length; r++)
          n[x(283)](i[r], s.x, s.y + r * o);
      }
    else {
      if (n.translate(s.x, s.y), n[x(407)](this[x(412)]), i == null)
        n.fillText(t, 0, 0);
      else {
        let o = this[x(352)];
        for (var r = 0; r < i[x(369)]; r++)
          n[x(283)](i[r], 0, 0 + r * o);
      }
      n.rotate(-this[x(374)]), n[x(343)](-s.x, -s.y);
    }
    return this[x(421)] = ![], s;
  }
  [d(292)](n) {
    const x = d;
    let t = [], e = this[x(314)];
    for (var s = 0; s < e.length; s++) {
      let i = e[s], r = i[x(411)][x(389)];
      !Z[x(326)](t, r) && t[x(388)](r), n && r instanceof ii && r[x(314)][x(369)] > 0 && Z.addAll(t, r.getLinkChildren(n));
    }
    return t;
  }
  [d(308)](n, x) {
    const t = d, e = this.getSegmentPoints(), s = ni({ x: n, y: x }, { x: 0, y: 0 }, e);
    return s == null || s[t(369)] == 0 ? { x: n, y: x } : s[0];
  }
  [d(373)](n) {
    const x = d;
    return this[x(416)] = n, this;
  }
  [d(384)](n, x) {
    return this.dirty = !![], this.x += n, this.y += x, this;
  }
  [d(306)](n, x) {
    const t = d;
    return this[t(288)] = !![], this.x = n, this.y = x, this;
  }
  [d(343)](n, x) {
    return this.dirty = !![], this.x = n, this.y = x, this;
  }
  setXY(n, x) {
    return this.dirty = !![], this.x = n, this.y = x, this;
  }
  [d(360)](n, x, t) {
    const e = d;
    this[e(288)] = !![];
    let s = this[e(281)](n), i = x - s.x, r = t - s.y;
    this[e(384)](i, r);
  }
  [d(393)](n, x) {
    const t = d;
    return this[t(288)] = !![], this.width = n, this[t(432)] = x, this;
  }
  [d(310)](n, x) {
    const t = d;
    return this[t(288)] = !![], this.width += n, this[t(432)] += x, this[t(290)] < 0 && (this.width = 0), this[t(432)] < 0 && (this[t(432)] = 0), this;
  }
  [d(324)](n, x) {
    const t = d;
    return this[t(288)] = !![], this[t(371)] *= n, this[t(345)] *= x, this;
  }
  [d(370)](n, x, t, e) {
    const s = d;
    return this[s(288)] = !![], this[s(290)] * this[s(371)], this[s(432)] * this[s(345)], this[s(324)](n, x), this;
  }
  [d(351)]() {
    return this[d(370)](0.8, 0.8), this;
  }
  zoomIn() {
    return this[d(370)](1.25, 1.25), this;
  }
  scaleTo(n, x) {
    const t = d;
    return this[t(371)] = n, this[t(345)] = x, this;
  }
  [d(355)](n) {
    const x = d;
    return this[x(338)] = n, this;
  }
  [d(407)](n) {
    return this.rotation = n, this;
  }
  [d(341)](n) {
    const x = d;
    return this[x(338)] += n, this;
  }
  [d(334)]() {
    const n = d;
    return new q(this.x - this[n(290)] * 0.5, this.y - this[n(432)] * 0.5, this[n(290)], this.height);
  }
  getPoint(n, x) {
    const t = d;
    let e = this[t(337)](n, x);
    return { x: -this.width * 0.5 + e.x, y: -this[t(432)] + e.y };
  }
  changeParent(n) {
    const x = d;
    if (this[x(331)] === n)
      throw new Error(x(298));
    let t = this, e = t[x(342)](0, 0), s = n[x(303)](e.x, e.y);
    return t[x(367)](s.x, s.y), t.parent && t[x(331)].removeChild(t), n[x(312)](t), this;
  }
  [d(317)](n) {
    let x = lt[n];
    return this.origin[0] = x.x, this.origin[1] = x.y, this;
  }
  [d(281)](n, x, t) {
    const e = d;
    let s = this[e(364)][n];
    if (s == null && (s = lt[n]), s == null)
      throw Error(e(289) + n);
    return typeof s == e(340) ? s[e(397)](this, x, t) : { x: s.x * this[e(290)], y: s.y * this[e(432)] };
  }
  [d(385)](n) {
    const x = d;
    let t = this[x(281)](L[x(278)]), e = this.positionToLocalPoint(n);
    return q[x(329)](t, e);
  }
};
let E = ii;
r0([b(d(386))], E[d(282)], d(323), 2), r0([b(R[d(365)])], E[d(282)], "shape", 2), r0([b(1)], E[d(282)], d(290), 2), r0([b(1)], E[d(282)], d(432), 2), r0([b(0)], E[d(282)], d(338), 2), r0([b(null)], E[d(282)], d(302), 2), r0([b(!![])], E[d(282)], d(332), 2), r0([b(0)], E[d(282)], "originOffset", 2), r0([b(null)], E[d(282)], d(374), 2), r0([b(null)], E[d(282)], d(344), 2), r0([b(null)], E[d(282)], d(313), 2), r0([b(null)], E.prototype, d(421), 2), r0([b(0)], E.prototype, d(391), 2), r0([b(0)], E[d(282)], d(291), 2), r0([b(0)], E[d(282)], d(352), 2), r0([b(null)], E.prototype, d(284), 2), r0([b(!![])], E[d(282)], d(349), 2), r0([b(Bx[d(386)])], E.prototype, d(350), 2), r0([b(0)], E[d(282)], d(412), 2), r0([b(D.prototype[d(408)][d(428)]([d(374), "x", "y", d(290), d(432), "shape", d(371), "scaleY", d(338), d(362), d(375), d(358), d(332), d(412), d(302), d(416)]))], E[d(282)], d(408), 2), r0([b(function() {
  return [d(407), "lt", "lb", "rt", "rb"];
})], E[d(282)], d(315), 2), r0([b(function() {
  return ["ct", "cb", "lm", "rm"];
})], E[d(282)], "getAnchorPoints", 2), r0([b(d(297))], E[d(282)], "pickType", 2), r0([b(d(278))], E[d(282)], d(416), 2), Object[d(328)](E.prototype, { text: { get() {
  return this._text;
}, set(n) {
  this.setText(n);
} }, imageSrc: { get() {
  return this[d(419)];
}, set(n) {
  const x = d;
  n == x(280) && (n = null), this[x(424)](n), this._imageSrc = n;
} } });
function Xe() {
  const n = ["dispatchEvent", "_computeLayer", "5937628BLtnDI", "forEach", "wheelZoom", "toFileJson", "getOwnPropertyDescriptor", "3436wICQZm", "min", "name", "mouseY", "css", "setRender", "removeChild", "_findChildren", "scaleX", "runScript", "fillByJson", "getChildrenAABB", "viewportRect", "_bgInfo", "draggable", "dispose", "hide", "_OBBPoints", "frames", "loopRender", "find", "toStageRect", "serializerSystem", "no-repeat", "getUnionRect", "containsRect", "style", "_obb", "render", "toJson", "time", "changed", "_frames", "axis", "mouseX", "toLayerRect", "height", "getTransform", "backgroundPosition", "7567350JQmSYW", "diff:", "stringify", "context", "_layerIndex", "resetTo", "className", "removeFromParent", "updateViewRect", "startsWith", "layersContainer", "point", "update", "destroyed", "dragHandle", "hidden", "serializers", "_requestReapint", "flatten", "8813wGsIqE", "push", "canvas", "defineProperty", "4364574pmIxlt", "offsetTop", "backgroundSize", "inputSystem", "10UHWPDz", "log", "width", "children", "left", "pickUpByRect", "isDebug", "zoomMinLimit", "7456mtFYar", "5JXAlxV", "translateWith", "_restoreBackground", "setSize", "isLayer", "getAllVisiable", "listeners", "dirty", "pickUpChild", "forceUpdate", "defaultPrevented", "centerBy", "stage", "toPojo", "553dpiYyN", "px ", "show", "6233211epdjZa", "prototype", "openJson", "hasListener", "_background", "layer", "scaleTo", "addChild", "0px", "map", "updateCanvasOffset", "18908329RdGOmb", "aabb", "inherit", "invert", "resizeTo", "overflow", "setDrawDelay", "_dragDrawDelay", "setBackground", "displayList", "top", "length", "_destory", "zoom", "cuttingHide", "remove", "getWidth", "styleSystem", "getAABB", "substring", "keys", "addChilds", "backgroundRepeat", "Layer has been destroyed already.", "_calcBackgroundPosition", "hideAxis", "getPoints", "visible", "getHeight", "updateSize", "renderLayer", "offsetLeft", "draw", "_paintPrepare", "background"];
  return Xe = function() {
    return n;
  }, Xe();
}
const v = qe;
function qe(n, x) {
  const t = Xe();
  return qe = function(e, s) {
    return e = e - 314, t[e];
  }, qe(n, x);
}
(function(n, x) {
  const t = qe, e = n();
  for (; []; )
    try {
      if (parseInt(t(366)) / 1 * (parseInt(t(422)) / 2) + parseInt(t(339)) / 3 + parseInt(t(417)) / 4 * (-parseInt(t(352)) / 5) + parseInt(t(316)) / 6 + parseInt(t(335)) / 7 * (parseInt(t(351)) / 8) + -parseInt(t(369)) / 9 + parseInt(t(343)) / 10 * (-parseInt(t(380)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Xe, 943600);
var Cr = Object[v(338)], Er = Object[v(421)], u1 = (n, x, t, e) => {
  const s = v;
  for (var i = e > 1 ? void 0 : e ? Er(x, t) : x, r = n[s(391)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && Cr(x, t, i), i;
};
class ut extends E {
  constructor(x) {
    const t = v;
    super(), this.className = "Layer", this[t(356)] = !![], this[t(434)] = new q(0, 0, 1, 1), this[t(394)] = !![], this[t(389)] = [], this[t(419)] = !![], this[t(455)] = new dr(), this[t(456)] = -1, this.mouseY = -1, this.zoomMaxLimit = { x: 10, y: 10 }, this[t(350)] = { x: 0.1, y: 0.1 }, this[t(454)] = 0, this[t(333)] = ![], this[t(387)] = ![], this._bgInfo = { sw: null, sh: null, x: null, y: null }, this.name = x, this[t(407)] = ![], this[t(389)] = [], Pt[t(349)] && (y0[t(374)] = this);
  }
  get [v(440)]() {
    return this[v(454)];
  }
  set [v(440)](x) {
    this._frames = x;
  }
  [v(328)]() {
    const x = v;
    return this._calcBackgroundPosition(), this[x(333)] = !![], !![];
  }
  showAxis() {
    this[v(455)].show();
  }
  [v(405)]() {
    const x = v;
    this.axis[x(438)]();
  }
  [v(427)](x) {
    const t = v;
    this[t(450)] != null && this.render[t(437)](), this[t(450)] = x, this[t(328)]();
  }
  [v(413)]() {
    const x = v;
    this.displayList = [];
    let t = this[x(314)]()[x(383)](), e = t[x(327)]({ x: this.stage.inputSystem.x || 0, y: this[x(364)][x(342)].y || 0 });
    return this[x(456)] = e.x, this[x(425)] = e.y, this.dirty && this[x(324)](), !![];
  }
  getViewportRectInLayer() {
    return this.viewportRect;
  }
  [v(420)](x = ![]) {
    const t = v;
    let e = this[t(364)].serializerSystem[t(365)]([this], x);
    return e.CustomStyle = this[t(364)][t(397)][t(365)](), JSON[t(318)](e);
  }
  [v(371)](x) {
    const t = v;
    B0[t(321)](100), this.removeAllChild(), this[t(364)].serializerSystem[t(432)](this, x), this[t(364)][t(397)][t(416)](this), this[t(404)](), this[t(364)].cancelZoom(), this[t(364)].translateToCenter();
  }
  [v(431)](x) {
    x(this[v(364)], this);
  }
  [v(324)]() {
    const x = v;
    this.viewportRect.setTo(0, 0, this[x(364)][x(345)], this[x(364)][x(458)]);
    let t = this[x(314)]()[x(383)]();
    const e = this[x(434)];
    let s = t[x(327)]({ x: e.x, y: e.y }), i = t[x(327)]({ x: e[x(345)], y: e[x(458)] });
    return e.x = s.x, e.y = s.y, e[x(345)] = i.x - s.x, e[x(458)] = i.y - s.y, this[x(434)] = e, e;
  }
  [v(409)](x, t) {
    const e = v;
    (x != this[e(450)][e(396)]() || t != this[e(450)][e(408)]()) && (this[e(450)][e(355)](x, t), this[e(384)](x, t), this[e(328)]());
  }
  [v(360)](x = ![]) {
    const t = v;
    let e = this[t(450)][t(319)];
    return super[t(360)](e, x);
  }
  [v(348)](x) {
    const t = v, e = this;
    let s = [], i = e[t(357)]();
    if (i != null)
      for (var r = 0; r < i[t(391)]; r++) {
        let o = i[r];
        if (!o.painted)
          continue;
        let a = o._obb[t(381)];
        x[t(447)](a) && s[t(336)](o);
      }
    return s;
  }
  [v(353)](x, t) {
    const e = v;
    return super[e(353)](x, t), this[e(404)](), this;
  }
  _calcBackgroundPosition() {
    const x = v;
    if (!this[x(450)])
      return;
    let t = this[x(435)], e = this[x(448)][x(402)];
    if (e != null && e != x(445)) {
      let s = 100, i = 100, r = this.style._backgroundImageObject;
      r != null && (s = r[x(345)], i = r[x(458)]);
      let o = s * this[x(430)], a = i * this.scaleY, c = this[x(345)] * 0.5 % o + this.x, l = this[x(458)] * 0.5 % a + this.y;
      if (t.sw != o || t.sh != a || t.x != c || t.y != l) {
        const f = this[x(450)][x(337)];
        f[x(448)][x(341)] = o + x(367) + a + "px", f[x(448)][x(315)] = c + "px " + l + "px";
      }
      t.sw = o, t.sh = a, t.x = c, t.y = l;
    }
  }
  [v(426)](x) {
    const t = v;
    super[t(426)](x);
    let e = x;
    if (this[t(450)]) {
      const s = this[t(450)].canvas;
      Object[t(400)](e).forEach((r) => {
        const o = t;
        let a = e[r];
        r[o(325)]("background") && (s[o(448)][r] = a);
      });
    }
    return this;
  }
  [v(398)](x = ![]) {
    const t = v;
    let e = this[t(433)](x, z0);
    return this[t(443)](e);
  }
  show() {
    const x = v;
    return super[x(368)](), this[x(450)][x(368)](), this[x(404)](), this;
  }
  [v(438)]() {
    const x = v;
    return super[x(438)](), this[x(450)][x(438)](), this;
  }
  [v(439)]() {
    const x = v;
    let t = this[x(345)], e = this[x(458)];
    return [{ x: 0, y: 0 }, { x: t, y: 0 }, { x: t, y: e }, { x: 0, y: e }];
  }
  [v(406)]() {
    return this[v(439)]();
  }
  [v(412)](x) {
  }
  [v(393)](x, t, e, s) {
    const i = v;
    if (this[i(372)](i(393))) {
      let o = new Event("zoom", { cancelable: !![] });
      if (o[i(393)] = { x, y: t, cx: e, cy: s }, this[i(415)](o), o[i(362)] == !![])
        return this;
    }
    if (x < 1) {
      let o = this[i(350)];
      if (this[i(434)][i(345)] >= this.width * (1 / o.x) && this.viewportRect[i(458)] >= this.height * (1 / o.y))
        return this;
    } else {
      let o = this.zoomMaxLimit;
      if (this[i(434)][i(345)] <= this[i(345)] * (1 / o.x) && this[i(434)].height <= this[i(458)] * (1 / o.y))
        return this;
    }
    return fr(this, x, t, e, s), this;
  }
  cancelZoom() {
    const x = v;
    this[x(375)](1, 1), this.translateTo(0, 0), this[x(359)] = !![];
  }
  [v(361)]() {
    const x = v;
    this.render[x(410)](this);
  }
  [v(388)](x, t) {
    const e = v;
    this[e(450)].canvas[e(448)].background = x, this.render[e(337)][e(448)][e(341)] = t;
  }
  [v(442)](x, t, e = ![]) {
    return this[v(429)](x, t, e);
  }
  [v(443)](x) {
    const t = v;
    let e = x.clone(), s = this[t(314)](), i = s[t(327)]({ x: e.x, y: e.y }), r = s[t(327)]({ x: e.x + e[t(345)], y: e.y + e[t(458)] });
    return e.x = i.x, e.y = i.y, e[t(345)] = r.x - i.x, e[t(458)] = r.y - i.y, e;
  }
  [v(457)](x) {
    const t = v;
    let e = this.getTransform()[t(383)](), s = new q(), i = e[t(327)]({ x: x.x, y: x.y }), r = e.point({ x: x.x + x[t(345)], y: x.y + x[t(458)] });
    return s.x = i.x, s.y = i.y, s[t(345)] = r.x - i.x, s.height = r.y - i.y, s;
  }
  [v(330)](x) {
    if (this[v(436)] == ![])
      return;
    let e = x.dx, s = x.dy;
    this.updateCanvasOffset(e, s);
  }
  [v(379)](x, t) {
    const e = v;
    if (this[e(387)] == ![]) {
      this[e(353)](x, t);
      return;
    }
    let s = this[e(450)][e(337)], i = s[e(411)], r = s[e(340)];
    s.style[e(347)] = i + x + "px", s[e(448)][e(390)] = r + t + "px";
  }
  [v(386)](x) {
    const t = v;
    this[t(387)] = x, x ? this[t(364)][t(326)][t(448)][t(385)] = t(331) : this[t(364)][t(326)][t(448)][t(385)] = t(382);
  }
  dragEndHandler() {
    const x = v;
    if (this[x(387)] == ![])
      return;
    let t = this[x(450)].canvas, e = t.offsetLeft, s = t[x(340)];
    this.translateWith(e, s), t.style.left = x(377), t[x(448)][x(390)] = x(377);
  }
  addChild(x) {
    const t = v;
    return super[t(376)](x), this[t(328)](), this;
  }
  addChilds(x) {
    const t = v;
    super[t(401)](x), this[t(328)]();
  }
  [v(363)](x) {
    const t = v;
    let e = this, s = e.stage, i;
    if (x == null)
      i = e.getAABB(!![]);
    else if (x instanceof D)
      i = e.toStageRect(x[t(449)].aabb);
    else {
      let l = x[t(378)]((f) => e.toStageRect(f._obb[t(381)]));
      i = xt[t(446)](l);
    }
    let r = s[t(345)] / 2, o = s[t(458)] / 2, a = r - i.x, c = o - i.y;
    a -= i[t(345)] / 2, c -= i[t(458)] / 2, e[t(353)](a, c), e[t(328)]();
  }
  [v(354)](x) {
    const t = v;
    let e = Object[t(400)](x);
    const s = this[t(450)][t(337)];
    x[t(373)] != null && (s[t(448)][t(414)] = x._background), e[t(418)]((i) => {
      const r = t;
      let o = x[i];
      i[r(325)](r(414)) && (s.style[i] = o);
    }), s[t(345)] += 1, s[t(345)] -= 1;
  }
  _reloadJsonTest() {
    const x = v;
    let t = this[x(364)][x(444)], e = t[x(451)]([this]);
    console[x(452)]("reloadJsonTest"), this.openJson(e);
    let s = t[x(451)]([this]);
    console.timeEnd("reloadJsonTest");
    function i(o, a) {
      const c = x, l = Math[c(423)](o[c(391)], a[c(391)]);
      for (let f = 0; f < l; f++)
        if (o[f] !== a[f])
          return console[c(344)](c(317), o[c(399)](f, f + 20), a[c(399)](f, f + 20)), f;
      return o[c(391)] !== a.length ? l : -1;
    }
    let r = i(e, s);
    return r != -1 ? console.log(x(453), r) : console[x(344)]("passed"), e;
  }
  getAllVisiable() {
    const x = v;
    return D[x(334)](this[x(346)], (t) => t[x(407)] == !![]);
  }
  [v(441)](x = 60) {
    const t = v;
    this[t(454)] = x;
  }
  [v(392)]() {
    const x = v;
    if (this[x(329)])
      throw new Error(x(403));
    this[x(329)] = !![], this[x(450)].canvas[x(395)](), this[x(364)] && this[x(364)][x(428)](this), this.displayList = void 0, this[x(358)] = void 0, this[x(448)] = void 0, this[x(434)] = void 0, this.classList = void 0, this[x(450)] = void 0, this[x(364)] = void 0, this[x(346)][x(418)]((t) => t[x(323)]()), this[x(346)] = void 0;
  }
}
u1([b(["id", v(424), v(322)])], ut.prototype, v(332), 2), u1([b("undefined")], ut[v(370)], v(320), 2);
const Qt = Ht;
(function(n, x) {
  const t = Ht, e = n();
  for (; []; )
    try {
      if (parseInt(t(433)) / 1 * (parseInt(t(428)) / 2) + -parseInt(t(420)) / 3 + parseInt(t(422)) / 4 + parseInt(t(435)) / 5 + parseInt(t(429)) / 6 * (-parseInt(t(434)) / 7) + -parseInt(t(444)) / 8 * (-parseInt(t(442)) / 9) + -parseInt(t(418)) / 10 * (-parseInt(t(440)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Ge, 621258);
function Ht(n, x) {
  const t = Ge();
  return Ht = function(e, s) {
    return e = e - 418, t[e];
  }, Ht(n, x);
}
let ct = {};
const ks = /* @__PURE__ */ new Map();
function ri(n, x, t) {
  const e = Ht;
  let s = ks.get(n);
  s != null && clearTimeout(s), s = setTimeout(() => {
    ks.delete(n), x();
  }, t), ks[e(423)](n, s);
}
var Mr = 40;
function Tr(n) {
  const x = Ht;
  if (n == null)
    return null;
  let t = "";
  for (var e = 0; e < n[x(443)]; e += x(431)[x(443)])
    n[x(443)] != Mr - 1 && (CanvasRender[x(439)][x(446)] = function() {
    }), t += String[x(426)](n[x(419)](e, e + x(431)[x(443)]));
  return t;
}
ct[Qt(432)] = function() {
  const n = Qt;
  return navigator[n(424)].indexOf(n(427)) > 0;
}, ct[Qt(445)] = function() {
  const n = Qt;
  return !!(window[n(448)] && navigator[n(424)][n(421)](n(437)) === -1);
}, ct.isChrome = function() {
  return navigator[Qt(424)].toLowerCase().match(/chrome/) != null;
}, ct.gc = Tr;
function Ge() {
  const n = ["320662pBURfW", "1302UGEwTe", "width", "fun", "isFirefox", "1uYNBym", "30471AhNlgu", "297355JUddJo", "height", "Opera", "abs", "prototype", "292567vLfajm", "contains", "3395592bhNjCV", "length", "8PJNIzo", "isIE", "setWidth", "function", "attachEvent", "730FystjQ", "substring", "3627777EikzPX", "indexOf", "945788NBAhXD", "set", "userAgent", "keys", "fromCharCode", "Firefox"];
  return Ge = function() {
    return n;
  }, Ge();
}
const C = ux;
(function(n, x) {
  const t = ux, e = n();
  for (; []; )
    try {
      if (-parseInt(t(389)) / 1 + parseInt(t(377)) / 2 + parseInt(t(394)) / 3 + -parseInt(t(387)) / 4 * (-parseInt(t(383)) / 5) + parseInt(t(398)) / 6 + parseInt(t(397)) / 7 + parseInt(t(378)) / 8 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Ue, 649971);
function Ue() {
  const n = ["white", "393441dzuczi", " repeat", "rgba(255,255,255,0.2)", "1629215KfjQtk", "78072jokVvC", "1px solid rgba(0,0,0,0.5)", "1527690MfMQbE", "5241640UrEsrH", "middle", "black", "createLightGridImg", "theme not exist:", "230aDsqJa", "center", "assign", "createDarkGridImg", "9304AGgIaM", "forEach", "1252979xAlqzE", "top", "1px solid rgba(255,255,255,0.5)", "keys"];
  return Ue = function() {
    return n;
  }, Ue();
}
function ux(n, x) {
  const t = Ue();
  return ux = function(e, s) {
    return e = e - 377, t[e];
  }, ux(n, x);
}
const dx = { copyFrom: function(n) {
  const x = ux;
  let t = dx[n];
  if (t == null)
    throw new Error(x(382) + n);
  let e = Object[x(392)](t), s = {};
  return e[x(388)]((i) => {
    const r = x;
    s[i] = Object[r(385)]({}, t[i]);
  }), s;
}, DefaultLight: { SelectArea: { border: C(399), backgroundColor: "rgba(0,0,236,0.1)" }, Layer: { background: ft[C(381)]() + C(395) }, Node: { textPosition: "cb", textAlign: C(384), textBaseline: C(390), strokeStyle: C(380) }, TextNode: { textPosition: C(384), textAlign: C(384), textBaseline: C(379), strokeStyle: C(380) }, TipNode: { textPosition: "ct", textAlign: C(384), textBaseline: C(390) }, ShapeNode: { lineWidth: 1, textPosition: "cb", textAlign: C(384), textBaseline: C(390), strokeStyle: C(380) }, CircleNode: { textPosition: "cb", textAlign: C(384), textBaseline: C(390), strokeStyle: C(380) }, VideoNode: { textPosition: "cb", textAlign: C(384), textBaseline: "top" }, RatioNode: { textPosition: C(384), textAlign: C(384), textBaseline: C(379) }, Link: { lineWidth: 1, strokeStyle: C(380) }, AutoFoldLink: { strokeStyle: C(380) }, FoldLink: { strokeStyle: "black" }, FlexionalLink: { strokeStyle: C(380) }, CurveLink: { strokeStyle: C(380) }, BezierLink: { strokeStyle: C(380) }, ArcLink: { strokeStyle: C(380) } }, DefaultDark: { SelectArea: { border: C(391), backgroundColor: C(396) }, Layer: { background: ft[C(386)]() + C(395) }, Node: { textPosition: "cb", textAlign: "center", textBaseline: C(390), strokeStyle: C(393), color: "white" }, TextNode: { textPosition: C(384), textAlign: C(384), textBaseline: "middle", strokeStyle: "white", color: C(393) }, TipNode: { textPosition: "ct", textAlign: C(384), textBaseline: C(390), color: C(393) }, ShapeNode: { lineWidth: 1, textPosition: "cb", textAlign: "center", textBaseline: C(390), strokeStyle: C(393), color: C(393) }, CircleNode: { textPosition: "cb", textAlign: "center", textBaseline: C(390), strokeStyle: C(393), color: C(393) }, VideoNode: { textPosition: "cb", textAlign: C(384), textBaseline: C(390), strokeStyle: C(393), color: C(393) }, RatioNode: { textPosition: C(384), textAlign: C(384), textBaseline: C(379), color: C(393) }, Link: { strokeStyle: C(393) }, AutoFoldLink: { strokeStyle: "white" }, FoldLink: { strokeStyle: C(393) }, FlexionalLink: { strokeStyle: C(393) }, CurveLink: { strokeStyle: "white" }, BezierLink: { strokeStyle: C(393) }, ArcLink: { strokeStyle: "white" } } }, Wx = px;
(function(n, x) {
  const t = px, e = n();
  for (; []; )
    try {
      if (parseInt(t(401)) / 1 * (parseInt(t(373)) / 2) + -parseInt(t(400)) / 3 + parseInt(t(395)) / 4 * (-parseInt(t(372)) / 5) + parseInt(t(386)) / 6 * (-parseInt(t(378)) / 7) + -parseInt(t(376)) / 8 * (-parseInt(t(381)) / 9) + parseInt(t(397)) / 10 * (-parseInt(t(380)) / 11) + parseInt(t(392)) / 12 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Ze, 796596);
function Ze() {
  const n = ["zIndex", "stage", "3231486qsBLkU", "font", "bold 16px arial", "_frames", "mouseY", "SelectArea", "41067252PzMCju", "render", "areaBox", "71512CsTplu", "mouseX", "30jJWzkn", "DefaultDark", "style", "2866023sHgeys", "783wJLsKh", "back", "white", "axis", "getHeight", "draw", "save", "180RMvsiJ", "1698gNsZpo", "fillStyle", "red", "4632MQMfjm", "mouseoutHandler", "14GsfMgy", "mouseDownY", "4857468woqNHp", "11043HJRmID", "globalAlpha", "HandlerLayer"];
  return Ze = function() {
    return n;
  }, Ze();
}
var Ar = ct.gc;
let d1 = V0.w;
function px(n, x) {
  const t = Ze();
  return px = function(e, s) {
    return e = e - 372, t[e];
  }, px(n, x);
}
class Is extends ut {
  constructor(x) {
    const t = px;
    super(), this.className = t(383), this[t(389)] = 0, this[t(384)] = Bx.HandlerLayerCanvas, this[t(396)] = 0, this[t(390)] = 0, this.mouseDownX = 0, this[t(379)] = 0, B0[t(402)](), this[t(385)] = x, this[t(399)] = new w0({ fillStyle: t(375), font: "13px arial" }), this[t(394)] = new E(), B0[t(402)](), this[t(394)].css(dx[t(398)][t(391)]), this.addChild(this[t(394)]), this[t(404)].visible = ![], this.visible = !![];
  }
  [Wx(377)](x) {
    this[Wx(394)].hide();
  }
  [Wx(406)](x) {
    const t = Wx;
    if (d1 == null)
      return;
    x[t(407)](), x[t(382)] = 0.6, x[t(387)] = t(388);
    let e = Ar(d1);
    x[t(374)] = t(403), x.fillText(e, 16, this[t(393)][t(405)]() - 16), x.restore();
  }
}
const O0 = Ve;
function Je() {
  const n = ["test", "string", "call", "isMobileDevice", "isFirefox", "style", "forEach", "type", "touches", "getXYInDom", "105672rTqkWV", "offsetParent", "scrollTop", "3081474BNqPyC", "517835GUElHx", "body", "none", "oncanplay", "getOffsetPosition", "5655912fqKhCP", "appendChild", "clientY", "src", "msRequestFullscreen", "mousewheel", "video/mp4", "position", "pageYOffset", "muted", "pageXOffset", "userAgent", "20WGHSzy", "_backup", "1116717fSAgJe", "fixed", "ownerDocument", "offsetLeft", "webkitRequestFullscreen", "getBoundingClientRect", "1YEjPWs", "clientLeft", "mozRequestFullScreen", "substring", "split", "createElement", "1272294cNRXYJ", "addEventListener", "clientTop", "top", "left", "10ADvknC", "source", "pageX", "fullScreen", "fullWindow", "276lvFVvO", "935vRtwFA", "63028vNLPih", "clientX", "scrollLeft", "attachEvent", "FullWindowDom", "documentElement"];
  return Je = function() {
    return n;
  }, Je();
}
(function(n, x) {
  const t = Ve, e = n();
  for (; []; )
    try {
      if (parseInt(t(477)) / 1 * (parseInt(t(483)) / 2) + parseInt(t(471)) / 3 + -parseInt(t(469)) / 4 * (parseInt(t(515)) / 5) + -parseInt(t(493)) / 6 * (parseInt(t(495)) / 7) + parseInt(t(520)) / 8 + parseInt(t(514)) / 9 * (parseInt(t(488)) / 10) + parseInt(t(494)) / 11 * (-parseInt(t(511)) / 12) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Je, 377232);
const oi = class {
  static [O0(484)](n, x, t) {
    const e = O0;
    let s = n[e(498)] || n[e(484)];
    ct[e(505)]() && x == e(525) ? x = "DOMMouseScroll" : window.attachEvent && x[e(480)](0, 2) !== "on" && (x = "on" + x), s[e(503)](n, x, t);
  }
  static [O0(519)](n) {
    const x = O0;
    if (n == null)
      return { left: 0, top: 0 };
    let t = 0, e = 0;
    if (n[x(476)] != null) {
      let s = n[x(476)](), i = n[x(473)], r = i[x(516)], o = i[x(500)], a = o[x(485)] || r[x(485)] || 0, c = o[x(478)] || r[x(478)] || 0;
      t = s.top + (window[x(528)] || o && o[x(513)] || r[x(513)]) - a, e = s.left + (window[x(530)] || o && o[x(497)] || r[x(497)]) - c;
    } else
      do
        t += n.offsetTop || 0, e += n[x(474)] || 0, n = n[x(512)];
      while (n);
    return { left: e, top: t };
  }
  static createVideo(n, x) {
    const t = O0;
    if (typeof n == t(502)) {
      let e = document.createElement("video");
      e[t(529)] = "muted", e[t(506)].display = t(517);
      let s = document[t(482)](t(489));
      return s[t(508)] = t(526), s[t(523)] = n, e[t(521)](s), document.body[t(521)](e), e[t(518)] = function() {
        x(e);
      }, e;
    } else
      return n;
  }
  static [O0(492)](n) {
    const x = O0;
    let t = "position,width,height,left,top,bottom,right,zIndex"[x(481)](",");
    if (n[x(491)] == !![]) {
      let e = n._backup;
      t[x(507)]((s) => {
        n.style[s] = e[s];
      }), n.fullScreen = ![];
    } else {
      let e = {};
      t[x(507)]((s) => {
        const i = x;
        e[s] = n[i(506)][s];
      }), n[x(470)] = e, n[x(506)][x(527)] = x(472), n[x(506)][x(487)] = 0, n[x(506)][x(486)] = 0, n.style.bottom = 0, n[x(506)].right = 0, n[x(506)].zIndex = Bx[x(499)], n[x(491)] = !![];
    }
  }
  static [O0(491)](n) {
    const x = O0;
    n.requestFullscreen ? n.requestFullscreen() : n[x(479)] ? n[x(479)]() : n[x(475)] ? n[x(475)]() : n.msRequestFullscreen && n[x(524)]();
  }
  static [O0(510)](n, x) {
    const t = O0;
    let e = x.touches[0][t(490)], s = x[t(509)][0].pageY;
    x[t(509)][0][t(490)] == null && (e = x[t(509)][0][t(496)] + document.body.scrollLeft - document[t(516)][t(478)], s = x[t(509)][0][t(522)] + document[t(516)].scrollTop - document[t(516)][t(485)]);
    let i = oi[t(519)](n), r = e - i[t(487)], o = s - i[t(486)];
    return { x: r, y: o };
  }
};
let Q0 = oi;
function Ve(n, x) {
  const t = Je();
  return Ve = function(e, s) {
    return e = e - 468, t[e];
  }, Ve(n, x);
}
Q0[O0(504)] = /Android|webOS|iPhone|iPad|iPod|BlackBerry/i[O0(501)](navigator[O0(468)]);
const bx = Ke;
(function(n, x) {
  const t = Ke, e = n();
  for (; []; )
    try {
      if (parseInt(t(352)) / 1 * (-parseInt(t(350)) / 2) + parseInt(t(346)) / 3 + -parseInt(t(353)) / 4 * (parseInt(t(343)) / 5) + parseInt(t(345)) / 6 + -parseInt(t(339)) / 7 * (parseInt(t(351)) / 8) + parseInt(t(354)) / 9 * (-parseInt(t(355)) / 10) + -parseInt(t(348)) / 11 * (-parseInt(t(340)) / 12) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Qe, 748653);
let jr = `
<svg viewBox="0 0 24 24" id="zoom-in">
<path d="M4,20 L9.58788778,14.4121122"/>
<path d="M14,16 C10.6862915,16 8,13.3137085 8,10 C8,6.6862915 10.6862915,4 14,4 C17.3137085,4 20,6.6862915 20,10 C20,13.3137085 17.3137085,16 14,16 Z"/>
<path d="M16.6666667 10L11.3333333 10M14 7.33333333L14 12.6666667"/>
</svg>
<svg viewBox="0 0 24 24" id="zoom-out">
<path d="M14,16 C10.6862915,16 8,13.3137085 8,10 C8,6.6862915 10.6862915,4 14,4 C17.3137085,4 20,6.6862915 20,10 C20,13.3137085 17.3137085,16 14,16 Z"/>
<path d="M16.6666667 10L11.3333333 10M4 20L9.58788778 14.4121122"/>
</svg>
<svg viewBox="0 0 24 24" id="back-left">
<path d="M5,17 L5,15 C5,10.0294373 8.80557963,6 13.5,6 C18.1944204,6 22,10.0294373 22,15"/>
<polyline points="8 15 5 18 2 15"/>
</svg>
<svg viewBox="0 0 24 24" id="align-center">
<path d="M8 10L16 10M6 6L18 6M6 14L18 14M8 18L16 18"/>
</svg>
<svg viewBox="0 0 24 24" id="edit">
<path d="M18.4142136 4.41421356L19.5857864 5.58578644C20.366835 6.36683502 20.366835 7.63316498 19.5857864 8.41421356L8 20 4 20 4 16 15.5857864 4.41421356C16.366835 3.63316498 17.633165 3.63316498 18.4142136 4.41421356zM14 6L18 10"/>
</svg>
<svg viewBox="0 0 24 24" id="lock-alt">
<rect width="14" height="10" x="5" y="11"/>
<path d="M12,3 L12,3 C14.7614237,3 17,5.23857625 17,8 L17,11 L7,11 L7,8 C7,5.23857625 9.23857625,3 12,3 Z"/>
<circle cx="12" cy="16" r="1"/>
</svg>
<svg viewBox="0 0 24 24" id="lock-open">
<path d="M7,7.625 L7,7 C7,4.23857625 9.23857625,2 12,2 L12,2 C14.7614237,2 17,4.23857625 17,7 L17,11"/>
<rect width="14" height="10" x="5" y="11"/>
</svg>
<svg viewBox="0 0 24 24" id="pan">
<path d="M20,14 L20,17 C20,19.209139 18.209139,21 16,21 L10.0216594,21 C8.75045497,21 7.55493392,20.3957659 6.80103128,19.3722467 L3.34541668,14.6808081 C2.81508416,13.9608139 2.94777982,12.950548 3.64605479,12.391928 C4.35756041,11.8227235 5.38335813,11.8798792 6.02722571,12.5246028 L8,14.5 L8,13 L8.00393081,13 L8,11 L8.0174523,6.5 C8.0174523,5.67157288 8.68902517,5 9.5174523,5 C10.3458794,5 11.0174523,5.67157288 11.0174523,6.5 L11.0174523,11 L11.0174523,4.5 C11.0174523,3.67157288 11.6890252,3 12.5174523,3 C13.3458794,3 14.0174523,3.67157288 14.0174523,4.5 L14.0174523,11 L14.0174523,5.5 C14.0174523,4.67157288 14.6890252,4 15.5174523,4 C16.3458794,4 17.0174523,4.67157288 17.0174523,5.5 L17.0174523,11 L17.0174523,7.5 C17.0174523,6.67157288 17.6890252,6 18.5174523,6 C19.3458794,6 20.0174523,6.67157288 20.0174523,7.5 L20.0058962,14 L20,14 Z"/>
</svg>
<svg viewBox="0 0 24 24" id="apps-alt">
<rect x="5" y="5" width="2" height="2"/>
<rect x="11" y="5" width="2" height="2"/>
<rect x="17" y="5" width="2" height="2"/>
<rect x="5" y="11" width="2" height="2"/>
<rect x="11" y="11" width="2" height="2"/>
<rect x="17" y="11" width="2" height="2"/>
<rect x="5" y="17" width="2" height="2"/>
<rect x="11" y="17" width="2" height="2"/>
<rect x="17" y="17" width="2" height="2"/>
</svg>
<svg viewBox="0 0 24 24" id="maximise">
<polyline points="21 16 21 21 16 21"/>
<polyline points="8 21 3 21 3 16"/>
<polyline points="16 3 21 3 21 8"/>
<polyline points="3 8 3 3 8 3"/>
</svg>
<svg viewBox="0 0 24 24" id="minimise">
<polyline points="8 3 8 8 3 8"/>
<polyline points="21 8 16 8 16 3"/>
<polyline points="3 16 8 16 8 21"/>
<polyline points="16 21 16 16 21 16"/>
</svg>
<svg viewBox="0 0 24 24" id="download">
<path d="M12,3 L12,16"/>
<polyline points="7 12 12 17 17 12"/>
<path d="M20,21 L4,21"/>
</svg>
<svg viewBox="0 0 24 24" id="rectangle">
<rect width="18" height="18" x="3" y="3"/>
</svg>
<svg viewBox="0 0 24 24" id="cursor">
<polygon points="7 20 7 4 19 16 12 16 7 21"/>
</svg>
<svg viewBox="0 0 24 24" id="search">
<path d="M14.4121122,14.4121122 L20,20"/>
<circle cx="10" cy="10" r="6"/>
</svg>
<svg viewBox="0 0 24 24" id="eye">
<path d="M22 12C22 12 19 18 12 18C5 18 2 12 2 12C2 12 5 6 12 6C19 6 22 12 22 12Z"/>
<circle cx="12" cy="12" r="3"/>
</svg>
<svg viewBox="0 0 24 24" id="save">
<path d="M17.2928932,3.29289322 L21,7 L21,20 C21,20.5522847 20.5522847,21 20,21 L4,21 C3.44771525,21 3,20.5522847 3,20 L3,4 C3,3.44771525 3.44771525,3 4,3 L16.5857864,3 C16.8510029,3 17.1053568,3.10535684 17.2928932,3.29289322 Z"/>
<rect width="10" height="8" x="7" y="13"/>
<rect width="8" height="5" x="8" y="3"/>
</svg>
<svg viewBox="0 0 24 24" id="image">
<rect width="18" height="18" x="3" y="3"/>
<path stroke-linecap="round" d="M3 14l4-4 11 11"/>
<circle cx="13.5" cy="7.5" r="2.5"/>
<path stroke-linecap="round" d="M13.5 16.5L21 9"/>
</svg>
<svg viewBox="0 0 24 24" id="upload">
<path d="M12,4 L12,17"/>
<polyline points="7 8 12 3 17 8"/>
<path d="M20,21 L4,21"/>
</svg>
`, ai = document[bx(344)](bx(342));
function Qe() {
  const n = ["495wDkbbE", "18610iTsqko", "244979pKbOTz", "36jzglNv", "innerHTML", "div", "5PdaoQV", "createElement", "5734440QhMMmN", "2752464mMBDju", "get", "2482062yFbzZF", "querySelector", "159804kLJioT", "8gmGLXU", "6qmxTVE", "4738948dOECEl"];
  return Qe = function() {
    return n;
  }, Qe();
}
ai[bx(341)] = jr;
function Ke(n, x) {
  const t = Qe();
  return Ke = function(e, s) {
    return e = e - 339, t[e];
  }, Ke(n, x);
}
let e1 = {};
e1[bx(347)] = function(n) {
  return ai[bx(349)]("#" + n);
};
const N = gx;
(function(n, x) {
  const t = gx, e = n();
  for (; []; )
    try {
      if (parseInt(t(438)) / 1 + parseInt(t(509)) / 2 + -parseInt(t(428)) / 3 + -parseInt(t(423)) / 4 * (parseInt(t(475)) / 5) + -parseInt(t(458)) / 6 * (parseInt(t(446)) / 7) + parseInt(t(437)) / 8 * (parseInt(t(420)) / 9) + parseInt(t(411)) / 10 * (-parseInt(t(461)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})($e, 922347);
function P0(n) {
  const x = gx;
  return e1[x(480)](n)[x(409)];
}
let ci = N(459);
ci = "";
function $e() {
  const n = ["save", "upload", "button[iconid='edit']", "files", "search", "openJson", 'input[type="file"]', "normal", "centerBy", `</button>
</div>

<div class="group">
<button title="导出PNG" class="item" iconId='image'>`, "style", "onkeydown", "加载出现错误", "3634340SnyXjY", "result", "title", "edit", "none", "要保存的文件名：", "innerHTML", `</button>
<button title="保存到本地" class="item" iconId='save'>`, "addEventListener", "hideOverview", "outerHTML", `</button>
<button title="居中" class="item" iconId='align-center'>`, "22308560LhSVbq", "Enter", "onclick", `</button>
<input title="查找" type="text" placeholder="查找" value=""></input>
<button class="item" iconId='search'>`, "div", "showOverview", "editor", "view", "readAsText", "12153492JLTzzF", "domObj", "buttons", "1389272ZYlHQD", "translate", "rectangle", "eye", "iconId", "2350152dYFtgc", "imageToBase64", "effectSystem", "querySelector", '<input type="file"/>', "flash", "setMode", "ondblclick", "pan", "8JzxdgI", "1753749ZyZVId", "stage", 'input[type="text"]', "removeAllActive", "change", "length", "getHeigth", `</button>
<button title="取消缩放" class="item" iconId='back-left'>`, "14PiLeeF", "target", `
<div class="group">
<button title="默认" class="item active" group='mode' iconId='cursor'>`, "button", "zoomIn", "getAttribute", "getDom", "align-center", "maximise", "reloadJsonTest", "fileInput", "createElement", "1912206qzQvhh", ' style="display:none" ', "querySelectorAll", "11nvkgEt", "input", "lock-alt", ".json", `</button>
<div style="display:none;"><input type="file"/></div>
</div>
`, "onload", "drag", `</button>
<button title="框选模式" class="item" group='mode' iconId='rectangle'>`, "remove", "group", "visible", "translateToCenter", "log", "indexOf", "5MZXNPt", "select", `</button>
<button title="打开本地文件" class="item" iconId='upload'>`, "update", "initActiveStatus", "get", "text", "zoomOut", "overview", "add", "classList", "fullWindow", "display", "jtopo_toolbar", "play", "hide", "initToolbar", "activeBtn", "getCurrentLayer", "value", `</button>
<button title="编辑模式" edit="true" class="item" group='mode' iconId='edit' `];
  return $e = function() {
    return n;
  }, $e();
}
function gx(n, x) {
  const t = $e();
  return gx = function(e, s) {
    return e = e - 401, t[e];
  }, gx(n, x);
}
var zr = N(448) + P0("cursor") + N(495) + ci + ">" + P0(N(402)) + N(468) + P0(N(425)) + `</button>
<button title="拖拽模式"  class="item" group='mode' iconId='pan'>` + P0(N(436)) + `</button>
<button title="锁定模式" class="item" group='mode' iconId='lock-alt'>` + P0(N(463)) + `</button>
</div>

<div class="group">
<button title="放大"  class="item" iconId='zoom-in'>` + P0("zoom-in") + `</button>
<button title="缩小"  class="item" iconId='zoom-out'>` + P0("zoom-out") + N(410) + P0(N(453)) + `</button>
<button title="缩放至画布" class="item" iconId='minimise'>` + P0("minimise") + N(445) + P0("back-left") + `</button>
</div>

<div class="group">
<button title="缩略图" class="item" iconId='eye'>` + P0(N(426)) + `</button>
<button title="浏览器全屏" class="item" iconId='maximise'>` + P0(N(454)) + N(414) + e1[N(480)](N(500))[N(409)] + N(505) + P0("image") + N(477) + P0(N(497)) + N(406) + P0(N(496)) + N(465);
class li {
  constructor(x) {
    const t = N;
    this[t(429)] = ![], this[t(439)] = x, this[t(491)](x, zr);
    let e = this;
    setTimeout(function() {
      e.initActiveStatus();
    }, 200);
  }
  [N(452)]() {
    return this[N(421)];
  }
  show() {
    const x = N;
    this[x(421)][x(506)].display = "block";
  }
  [N(490)]() {
    const x = N;
    this[x(421)][x(506)][x(487)] = x(403);
  }
  remove() {
    this[N(421)].remove();
  }
  [N(444)]() {
    const x = N;
    return this[x(421)][x(506)][x(487)] == x(403) ? 0 : this[x(421)].clientHeight + 1;
  }
  [N(479)]() {
    const x = N;
    if (this[x(439)].mode == x(402)) {
      let e = document[x(431)](x(498));
      this[x(492)](e);
    }
  }
  [N(491)](x, t) {
    const e = N;
    let s = this, i = document[e(457)](e(415));
    this[e(421)] = i, i[e(485)][e(484)](e(488)), i.innerHTML = t;
    let r = i[e(460)](e(449));
    this[e(422)] = r;
    let o = i[e(431)](e(502)), a = o.parentNode;
    function c(p) {
      const k = e;
      a[k(405)] = k(432), l();
      let w = p[k(447)][k(499)][0];
      const O = new FileReader();
      O[k(419)](w), O[k(466)] = function() {
        const S = k, j = s[S(439)][S(493)](), z = this[S(510)];
        try {
          j[S(501)](z), j[S(424)](0, 0), j.scaleTo(1, 1), document[S(401)] = w.name;
        } catch (E0) {
          console[S(473)](E0), alert(S(508));
        }
      };
    }
    function l() {
      const p = e;
      o = i[p(431)](p(502)), o[p(407)](p(442), c);
    }
    l(), this[e(456)] = o;
    function f() {
      const p = e;
      let k = x.getCurrentLayer(), w = i[p(431)](p(440))[p(494)];
      if (w[p(443)] > 0) {
        let O = k.displayList;
        for (let S = 0; S < O[p(443)]; S++) {
          const j = O[S];
          if (j[p(481)] != null && j[p(481)][p(474)](w) != -1) {
            k[p(504)](j, 10), x[p(430)][p(433)](j)[p(489)](), x[p(417)] != null ? x[p(417)][p(478)]() : x[p(478)]();
            return;
          }
        }
      }
    }
    let u = { cursor: function() {
      const p = e;
      x[p(434)](p(503));
    }, rectangle: function() {
      const p = e;
      x[p(434)](p(476));
    }, pan: function() {
      const p = e;
      x[p(434)](p(467));
    }, edit: function() {
      x.setMode("edit");
    }, "lock-alt": function() {
      const p = e;
      x[p(434)](p(418));
    }, eye: function() {
      const p = e;
      x[p(483)] == null || x[p(483)][p(471)] == ![] ? x[p(416)]() : x[p(408)]();
    }, "zoom-in": function() {
      x[e(450)]();
    }, "zoom-out": function() {
      x[e(482)]();
    }, "back-left": function() {
      x.cancelZoom();
    }, minimise: function() {
      x.zoomFullStage();
    }, "align-center": function() {
      x[e(472)]();
    }, maximise: function() {
      x[e(486)]();
    }, image: function() {
      x.saveImageInfo();
    }, save: function() {
      const p = e;
      let k = prompt(p(404)), w = s.imageToBase64;
      k != null && x.download(k + p(464), w);
    }, upload: function() {
      o.click();
    }, search: f };
    i[e(431)](e(462))[e(507)] = function(p) {
      const k = e;
      p.key == k(412) && f();
    }, i[e(431)]("input")[e(435)] = function() {
      const p = e;
      console.log("reloadJsonTest"), x.getCurrentLayer()[p(455)]();
    };
    function y(p) {
      const k = e;
      p[k(413)] = function() {
        const w = k;
        let O = p[w(451)](w(427));
        u[O](), s[w(492)](p);
      };
    }
    for (var m = 0; m < r[e(443)]; m++) {
      let p = r[m];
      y(p);
    }
  }
  [N(492)](x) {
    const t = N;
    let e = x[t(451)](t(470));
    e != null && (this[t(441)](e), x[t(485)][t(484)]("active"));
  }
  [N(441)](x) {
    const t = N;
    let e = this[t(422)];
    for (var s = 0; s < e[t(443)]; s++) {
      let i = e[s];
      x == i[t(451)](t(470)) && i.classList[t(469)]("active");
    }
  }
}
const rt = It;
(function(n, x) {
  const t = It, e = n();
  for (; []; )
    try {
      if (-parseInt(t(358)) / 1 + parseInt(t(312)) / 2 * (parseInt(t(357)) / 3) + -parseInt(t(370)) / 4 + -parseInt(t(305)) / 5 * (parseInt(t(355)) / 6) + parseInt(t(332)) / 7 * (parseInt(t(362)) / 8) + -parseInt(t(367)) / 9 + parseInt(t(345)) / 10 * (parseInt(t(376)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(tn, 964465);
class n1 extends K0 {
  constructor() {
    const x = It;
    super(), this[x(315)] = !![], this[x(349)] = 0, this[x(316)] = 0, this.x = -1, this.y = -1, this[x(356)] = ![], this[x(347)] = ![], this[x(364)] = ![], this[x(368)] = ![], this[x(379)] = ![], this[x(317)] = 0, this[x(323)] = 50, this[x(309)] = 0, this[x(339)] = 0;
  }
  preventDefault() {
    const x = It;
    this[x(361)] && this[x(361)][x(380)]();
  }
  [rt(329)]() {
    return this[rt(339)] == 2;
  }
  [rt(346)](x, t) {
    const e = rt, s = Object[e(372)]({}, this);
    this[e(353)] = s, this[e(361)] = x, this[e(331)] = x.timeStamp, this.buttons = x.buttons, this[e(339)] = x[e(339)], this[e(347)] = ![], this[e(368)] = t != e(308), this[e(344)] = ![];
    let i = this;
    this.idleTimer != null && window[e(385)](this[e(310)]), this[e(310)] = setTimeout(function() {
      const r = e;
      i[r(344)] = !![];
    }, this.idleTimeout), this[e(326)] = t, this.x = x.offsetX, this.y = x[e(371)], t == e(335) || t == e(340) ? (this.isMouseDown = !![], this[e(349)] = this.x, this.mouseDownY = this.y) : (t == e(384) || t == e(363) || t == e(308) || t == e(322)) && (this.isMouseDown = ![], s && s[e(326)] == e(334) && (this.isDragEnd = !![])), this[e(364)] = this[e(356)] == !![] && (t == e(334) || t == e(360)), this[e(379)] = this.isDraging && s[e(364)] != !![], this.dx = this.x - s.x, this.dy = this.y - s.y;
  }
  [rt(366)](x) {
    const t = rt;
    if (Q0[t(354)]) {
      Dr(x);
      return;
    }
    let e = x[t(324)], s = x[t(375)], i = s.render.canvas;
    ["mouseenter", "mouseout", t(320), t(335), t(384), t(334), t(381), t(363), t(378), t(365), t(342), t(383), "drop"][t(325)](function(o) {
      Q0.addEventListener(i, o, function(a) {
        const c = It;
        if (a[c(377)] < 0 || a[c(371)] < 0 || (e[c(346)](a, o), x.update(), x[c(343)] == D0[c(333)]))
          return;
        if (x[c(343)] == D0[c(382)] && (o == c(365) || o == "dragend" || o == c(383) || o == c(373))) {
          e[c(330)](a);
          return;
        }
        let l = o + "Handler";
        e.isDraging ? l = c(313) : o == "touchmove" && (a.touches.length == 1 || a[c(307)][c(318)] >= 2) && (l = "mousedragHandler"), o == c(335) && x[c(369)](), !(x.mode == D0[c(382)] && x[c(314)] != null && x.editor[l] && (x[c(314)][l](a), e[c(361)][c(328)])) && (x[l] && (x[l](a), x[c(306)] && (x[c(306)][c(341)] = !![]), e.event[c(328)]) || (o == c(381) && a[c(380)](), e[c(330)](a)));
      });
    });
  }
  mockMouseEvent(x, t, e, s) {
    const i = rt, r = x.getBoundingClientRect();
    e = r[i(348)] + e, s = r[i(337)] + s;
    const o = new MouseEvent(t, { clientX: e, clientY: s });
    console[i(352)](o), x[i(330)](o);
  }
}
function Dr(n) {
  const x = rt;
  let t = n[x(324)], e = n[x(375)], s = e.render[x(319)];
  ["touchstart", x(360), x(322)].map(function(r) {
    const o = x;
    Q0[o(311)](s, r, function(a) {
      const c = o;
      if (a.preventDefault(), n[c(343)] == D0[c(333)])
        return;
      if (t[c(346)](a, r), a[c(307)][c(318)] == 0 && r == c(322)) {
        n[c(374)] && n[c(374)](t);
        return;
      }
      if (a.touches.length == 0)
        return;
      let l = Q0.getXYInDom(s, a);
      if (t[c(377)] = l.x, t[c(371)] = l.y, t.x = l.x, t.y = l.y, t.x = l.x, t.y = l.y, a[c(307)][c(318)] > 1) {
        r == c(360) && n[c(313)] && n[c(313)](t);
        return;
      }
      r == c(340) && n.forceUpdate();
      let f = r + c(336);
      n[f] && n[f](t), t[c(330)](a);
    });
  });
}
function tn() {
  const n = ["previous", "isMobileDevice", "12NpPVyl", "isMouseDown", "144kahFfw", "1292602QsSOVN", "clientY", "touchmove", "event", "379288OKyJrv", "click", "isDraging", "dragstart", "_initEvent", "1774917aeLtay", "isMouseOn", "forceUpdate", "942120EGFcZG", "offsetY", "assign", "drop", "touchendHandler", "handlerLayer", "5582588iPztEE", "offsetX", "dblclick", "isDragStart", "preventDefault", "mousewheel", "edit", "dragover", "mouseup", "clearTimeout", "3473245afqzvy", "overview", "touches", "mouseout", "buttons", "idleTimer", "addEventListener", "35184anNJXY", "mousedragHandler", "editor", "wheelZoom", "mouseDownY", "touchesDistance", "length", "canvas", "mouseover", "stopPropagation", "touchend", "idleTimeout", "inputSystem", "map", "type", "getBoundingClientRect", "defaultPrevented", "isRightButton", "dispatchEvent", "timeStamp", "28QqAsSj", "view", "mousemove", "mousedown", "Handler", "top", "clientX", "button", "touchstart", "dirty", "dragend", "mode", "isIdle", "60EfREQY", "update", "isDragEnd", "left", "mouseDownX", "getElementById", "targetCanvas", "log"];
  return tn = function() {
    return n;
  }, tn();
}
function It(n, x) {
  const t = tn();
  return It = function(e, s) {
    return e = e - 305, t[e];
  }, It(n, x);
}
function _x(n, x) {
  const t = xn();
  return _x = function(e, s) {
    return e = e - 468, t[e];
  }, _x(n, x);
}
const s0 = _x;
(function(n, x) {
  const t = _x, e = n();
  for (; []; )
    try {
      if (parseInt(t(503)) / 1 + -parseInt(t(492)) / 2 * (-parseInt(t(508)) / 3) + -parseInt(t(487)) / 4 * (parseInt(t(518)) / 5) + parseInt(t(483)) / 6 * (parseInt(t(472)) / 7) + parseInt(t(469)) / 8 * (-parseInt(t(490)) / 9) + -parseInt(t(523)) / 10 * (parseInt(t(507)) / 11) + -parseInt(t(482)) / 12 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(xn, 477518);
class hi extends K0 {
  constructor(x) {
    const t = _x;
    super(), this.debug = ![], this[t(521)] = ![], this[t(495)] = /* @__PURE__ */ new Map(), this[t(519)] = /* @__PURE__ */ new Map(), this.stage = x, this[t(475)](), this[t(488)] = ![];
  }
  [s0(474)]() {
    this._disabled = !![];
  }
  [s0(473)]() {
    const x = s0;
    this[x(521)] = ![];
  }
  [s0(520)](x, t) {
    const e = s0;
    let s = x[e(499)]()[e(524)]("+")[e(481)]()[e(502)]("+");
    this[e(495)].set(s, t);
  }
  [s0(501)](x) {
    return this[s0(479)](x) != null;
  }
  [s0(479)](x) {
    const t = s0;
    let e = x.toLowerCase()[t(524)]("+")[t(481)]()[t(502)]("+");
    return this[t(495)].get(e);
  }
  [s0(480)](x) {
    return this[s0(516)](x);
  }
  unbind(x) {
    const t = s0;
    let e = x.toLowerCase()[t(524)]("+")[t(481)]()[t(502)]("+");
    this[t(495)][t(500)](e);
  }
  isKeydown(x) {
    return this[s0(519)].get(x);
  }
  [s0(494)](x, t) {
    const e = s0;
    t == null && (t = new KeyboardEvent(e(496)), t.mock = !![]), this[e(491)](x.toLowerCase()[e(524)]("+"), t, !![]);
  }
  [s0(470)]() {
    const x = s0;
    let t = document[x(468)].tagName;
    return t == x(527) || t == x(511);
  }
  [s0(491)](x, t, e) {
    const s = s0;
    if (e == ![] || this[s(470)]())
      return;
    const i = this;
    let r = this[s(514)], o = r.editor, a = x[s(481)]().join("+")[s(499)]();
    this[s(488)] && console[s(489)]("按下", a);
    let c = this[s(495)].keys();
    for (let l of c) {
      if (l != a || o != null && o[s(526)] == !![])
        continue;
      t.preventDefault();
      let f = i.regMap[s(471)](l);
      f && f(t);
    }
  }
  [s0(493)](x) {
    const t = s0;
    let e = x[t(498)][t(499)](), s = this[t(514)], i = [];
    x[t(497)] && (this[t(519)][t(512)](t(476), !![]), i.push(t(504))), x[t(477)] && (this.keyMap[t(512)](t(515), !![]), i[t(506)](t(522))), x.shiftKey && (this[t(519)].set(t(485), !![]), i[t(506)](t(486))), x[t(510)] && (this[t(519)][t(512)]("Meta", !![]), i.push(t(484))), i.indexOf(e) == -1 && i[t(506)](e), this.keyMap.set(e, !![]);
    let r = Ys(x);
    this[t(513)] = r, this[t(491)](i, r, s.inputSystem[t(517)]), this[t(525)](r);
  }
  [s0(509)](x) {
    const t = s0, e = this;
    e[t(519)][t(512)](x[t(498)], ![]);
    let s = e[t(514)][t(505)];
    if (s != null && s[t(526)] == !![])
      return;
    let i = Ys(x);
    e[t(525)](i);
  }
  [s0(475)]() {
    const x = s0;
    let t = this;
    document[x(478)](x(496), function(e) {
      const s = x;
      t._disabled != !![] && t[s(493)](e);
    }), document.addEventListener(x(528), function(e) {
      const s = x;
      t._disabled != !![] && t[s(509)](e);
    });
  }
}
function xn() {
  const n = ["keydown", "ctrlKey", "key", "toLowerCase", "delete", "isKeyRegistered", "join", "909126mzfSCA", "control", "editor", "push", "474276GQnbvD", "6HqGymo", "keyupHandler", "metaKey", "TEXTAREA", "set", "preKeydownEvent", "stage", "Alt", "unbind", "isMouseOn", "65xWiGnO", "keyMap", "bindKey", "_disabled", "alt", "140FJmKEi", "split", "dispatchEvent", "textInputMode", "INPUT", "keyup", "activeElement", "8LDPQPu", "isMouseOnInputDomElement", "get", "6130201YYkgVL", "enable", "disable", "init", "Control", "altKey", "addEventListener", "getKeyBinding", "unBind", "sort", "4695768DaDJOm", "6bueOni", "meta", "Shift", "shift", "171908nBKiAv", "debug", "log", "3194514sdOQLL", "fireKey", "601234LTvJrk", "keydownHandler", "sendKey", "regMap"];
  return xn = function() {
    return n;
  }, xn();
}
const u0 = nn;
function en() {
  const n = ["185hcWBZn", "noChildrensObjects", "removeAll", "mousedragHandler", "has", "33732kuzAxN", "mousedragEndHandler", "27009qEbPZh", "3PwiTkY", "addAll", "dispatchEvent", "21496GrCIOr", "selectedHandler", "isDraging", "mouseoutHandler", "1131EulqIw", "call", "group", "12CnuOIz", "unselectedHandler", "event", "408ntgavS", "length", "defaultPrevented", "72254sspKVX", "objects", "push", "96686hEwSnN", "20pktJVZ", "draggable", "577786xTfYYS", "groupdragend", "remove", "288589xMykVo", "hasChild", "isEmpty", "getNoChildrensObjects"];
  return en = function() {
    return n;
  }, en();
}
(function(n, x) {
  const t = nn, e = n();
  for (; []; )
    try {
      if (-parseInt(t(521)) / 1 + -parseInt(t(524)) / 2 * (parseInt(t(505)) / 3) + -parseInt(t(508)) / 4 * (parseInt(t(497)) / 5) + -parseInt(t(515)) / 6 * (parseInt(t(493)) / 7) + parseInt(t(518)) / 8 * (parseInt(t(504)) / 9) + -parseInt(t(525)) / 10 * (-parseInt(t(527)) / 11) + parseInt(t(502)) / 12 * (parseInt(t(512)) / 13) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(en, 100771);
function nn(n, x) {
  const t = en();
  return nn = function(e, s) {
    return e = e - 493, t[e];
  }, nn(n, x);
}
let p1 = new InputEvent(j0[u0(528)]), Br = new InputEvent(j0.groupdrag);
class fi extends K0 {
  constructor() {
    const x = u0;
    super(), this.objects = [], this[x(510)] = ![], this[x(498)];
  }
  [u0(495)]() {
    const x = u0;
    return this[x(522)][x(519)] == 0;
  }
  [u0(511)](x) {
    const t = u0;
    this[t(510)] = ![], !this[t(495)]() && this[t(507)](p1);
  }
  mousedragHandler(x) {
    const t = u0;
    if (this.dispatchEvent(Br), x[t(517)][t(520)] == !![])
      return;
    let e = this[t(496)]();
    for (var s = 0; s < e[t(519)]; s++) {
      let i = e[s];
      i[t(526)] && i[t(500)] && i[t(500)](x);
    }
  }
  [u0(503)](x) {
    const t = u0;
    this[t(507)](p1);
    let e = this[t(496)]();
    for (var s = 0; s < e[t(519)]; s++) {
      let i = e[s];
      i[t(526)] && i[t(503)] && i[t(503)](x);
    }
  }
  getNoChildrensObjects() {
    const x = u0;
    return D[x(496)](this[x(522)]);
  }
  [u0(506)](x) {
    const t = u0;
    for (var e = 0; e < x[t(519)]; e++) {
      let s = x[e];
      s[t(514)] = this, !Z[t(494)](this[t(522)], s) && (s[t(509)] && s[t(509)](), this.objects[t(523)](s));
    }
    return this;
  }
  add(x) {
    const t = u0;
    return x[t(514)] = this, Z.hasChild(this[t(522)], x) ? this : (x.selectedHandler[t(513)](x), this.objects[t(523)](x), this);
  }
  [u0(529)](x) {
    const t = u0;
    return x[t(514)] = void 0, x[t(516)] && x[t(516)](x), Z[t(529)](this[t(522)], x), this;
  }
  [u0(499)]() {
    const x = u0;
    let t = this[x(522)];
    for (var e = 0; e < t[x(519)]; e++) {
      let s = t[e];
      s[x(514)] = void 0, s[x(516)] && s[x(516)]();
    }
    return this[x(522)][x(519)] = 0, this;
  }
  [u0(501)](x) {
    const t = u0;
    return Z.hasChild(this[t(522)], x);
  }
}
function sn() {
  const n = ["5621472msmNwS", "_timer", "<li>Target: id: ", "<li>&nbsp;&nbsp;-Parent: (x: ", "1254cbjlLs", "numberFixed", "none", "<li>&nbsp;&nbsp;-Layer:  (x: ", "38546tLQsLu", "isIdle", ") </li>", "start", "<li>Links: ", ", y: ", "3194795dLTSwO", "186issDrI", "add", "98602vMRYoO", "1084755HPWaCz", "<li>_aabb:[x:", "toStageXY", "pickedObject", "] </li>", "displayList", "getCurrentLayer", "setContent", "style", "]</li>", "init", "createElement", "getAllLinks", ", h:", "width", "<li>Nodes: ", "getChildren", " y: ", ",w: ", "toLayerXY", "classList", "4rySicU", "ceil", "inputSystem", "<li>Total: ", "debugInfo", "height", "<li>Mouse-Canvas( x: ", "origin", "toFixed", "</li>", ")</li>", "domElement", ",y: ", "checkDom", "<li>", "2425959LBlAHY", "stage", "hide", "length", "appendChild", "display", "<li>Painted: ", "div", "204560YDSOoy", "8KjJGKO", "<li>&nbsp;&nbsp;-Canvas: (x: ", "aabb", "layersContainer", "innerHTML"];
  return sn = function() {
    return n;
  }, sn();
}
const U0 = yx;
(function(n, x) {
  const t = yx, e = n();
  for (; []; )
    try {
      if (parseInt(t(548)) / 1 * (-parseInt(t(511)) / 2) + parseInt(t(558)) / 3 * (parseInt(t(535)) / 4) + parseInt(t(554)) / 5 + parseInt(t(555)) / 6 * (parseInt(t(557)) / 7) + parseInt(t(540)) / 8 + parseInt(t(526)) / 9 + parseInt(t(534)) / 10 * (-parseInt(t(544)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(sn, 361954);
function yx(n, x) {
  const t = sn();
  return yx = function(e, s) {
    return e = e - 494, t[e];
  }, yx(n, x);
}
class Nr {
  constructor(x) {
    const t = yx;
    this.numberFixed = 0, this[t(527)] = x;
  }
  [U0(500)]() {
    const x = U0, t = document[x(501)](x(533));
    t[x(510)][x(556)]("jtopo_debugPanel"), this.stage[x(538)][x(530)](t), this.domElement = t, this[x(528)]();
  }
  [U0(551)](x = 24) {
    const t = U0, e = this, s = this[t(527)];
    function i() {
      const r = t;
      if (s[r(513)][r(549)])
        return;
      let o = s[r(506)](), a = 0, c = 0, l = 0;
      for (var f = 0; f < o.length; f++) {
        let O = o[f];
        a += O[r(495)][r(529)], c += O.getAllNodes()[r(529)], l += O[r(502)]()[r(529)];
      }
      let u = Math[r(512)](s[r(513)].x), y = Math.ceil(s[r(513)].y), m = s[r(496)](), p = { x: 0, y: 0 };
      m != null && (p = m.stageToLocalXY(u, y));
      const k = s[r(513)][r(561)];
      let w = r(517) + u + r(507) + y + r(521);
      if (w += "<li>Mouse-Layer( x: " + p.x[r(519)](2) + r(507) + p.y[r(519)](2) + r(521), w += r(505) + c + r(520), w += r(552) + l + r(520), w += r(514) + (c + l) + r(520), w += r(532) + a + r(520), k) {
        w += r(542) + k.id;
        const O = k._obb[r(537)], S = k[r(560)](0, 0), j = k[r(509)](0, 0), z = this[r(545)];
        w += r(559) + O.x[r(519)](z) + r(523) + O.y.toFixed(z) + r(508) + O[r(504)][r(519)](z) + r(503) + O[r(516)][r(519)](z) + r(494), w += "<li>Origin: [" + k[r(518)][0][r(519)](z) + ", " + k[r(518)][1][r(519)](z) + r(499), w += r(536) + S.x[r(519)](z) + r(553) + S.y[r(519)](z) + r(550), k instanceof E && (w += r(543) + k.x.toFixed(z) + r(553) + k.y[r(519)](z) + r(550)), w += r(547) + j.x[r(519)](z) + r(553) + j.y[r(519)](z) + ") </li>";
      }
      Pt[r(515)] && (w += r(525) + Pt[r(515)] + r(520)), e[r(497)](w);
    }
    this[t(541)] = setInterval(i, x);
  }
  [U0(497)](x) {
    const t = U0;
    this[t(522)][t(539)] = x;
  }
  [U0(524)]() {
    this.domElement == null && this.init();
  }
  [U0(528)]() {
    const x = U0;
    return this[x(524)](), clearInterval(this[x(541)]), this[x(522)][x(498)].display = x(546), this;
  }
  show(x) {
    const t = U0;
    return this[t(524)](), this[t(522)].style[t(531)] = "block", this[t(551)](x), this;
  }
}
var Rr = rn;
(function(n, x) {
  for (var t = rn, e = n(); []; )
    try {
      var s = parseInt(t(437)) / 1 * (parseInt(t(434)) / 2) + -parseInt(t(438)) / 3 + -parseInt(t(433)) / 4 * (parseInt(t(441)) / 5) + parseInt(t(436)) / 6 + parseInt(t(432)) / 7 + parseInt(t(435)) / 8 + parseInt(t(440)) / 9;
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(on, 525261);
function rn(n, x) {
  var t = on();
  return rn = function(e, s) {
    e = e - 432;
    var i = t[e];
    return i;
  }, rn(n, x);
}
function on() {
  var n = ["679368UVgDvE", "477436QrpKyM", "5981584DxQBWm", "903348RWQSJg", "1BcmJiK", "2136099vxmpXA", "dispose", "1836891EFDOdp", "30oQaHwC", "6406911aNYAdH"];
  return on = function() {
    return n;
  }, on();
}
class Hr extends K0 {
  constructor() {
    super(), this.stoped = ![];
  }
  [Rr(439)]() {
  }
}
const I = an;
(function(n, x) {
  const t = an, e = n();
  for (; []; )
    try {
      if (parseInt(t(306)) / 1 * (-parseInt(t(371)) / 2) + parseInt(t(422)) / 3 + -parseInt(t(341)) / 4 + parseInt(t(361)) / 5 * (parseInt(t(388)) / 6) + -parseInt(t(323)) / 7 + parseInt(t(331)) / 8 + parseInt(t(417)) / 9 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(cn, 804079);
var Fr = Object[I(351)], Wr = Object[I(352)], gt = (n, x, t, e) => {
  const s = I;
  for (var i = e > 1 ? void 0 : e ? Wr(x, t) : x, r = n[s(425)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && Fr(x, t, i), i;
};
function an(n, x) {
  const t = cn();
  return an = function(e, s) {
    return e = e - 306, t[e];
  }, an(n, x);
}
function cn() {
  const n = ["height", "centerOffset", "serializers", "removeInLink", "BezierLink", "840520sTteRQ", "getPoints", "scale", "DefaultPositions", "removeOutLink", "className", "getTransform", "translateWith", "invert", "_calcAZ", "2lUocqw", "point", "getLayerTransform", "asBeginArrow", "target", "isPointOn", "name", "string", "call", "getSize", "same parent, dont need change", "ctrlPoint2", "drawShape", "abs", "deep", "parent", "copy", "6dmOUzF", "beginArrow", "unlinkBegin", "getPointsNormalization", "getBeginPoint", "beginOffset", "createLabel", "localAABB", "ctrlPoint", "text", "_text", "_pickRadius", "setEndArrow", "Link", "attr", "width", "addOutLink", "transform", "stageToLocalXY", "setEnd", "setBeginArrow", "beginPath", "toLayerXY", "_offsetAZ", "concat", "center", "LinkHelper", "toStageXY", "stroke", "15759009oLyIPz", "normalize", "translate", "visible", "localPoints", "2923251UdlYqo", "getBeginArrow", "zIndex", "length", "611313hrYBCJ", "setBegin", "fold2Offset", "getEndPoint", "lineWidth", "points", "asEndArrow", "prototype", "positions", "getLocalPoint", "assign", "shape", "_obb", "dirty", "negate", "not reached", "endOffset", "6407604AiUuND", "log", "isDisplayObjectTarget", "_OBBPoints", "positionToLocalPoint", "position not exist:", "updatePoints", "addInLink", "588640doEKdt", "setLabel", "end", "nearest", "unlink", "removeChild", "label", "AutoFoldLink", "getShapeOrigin", "_setOffsetByVec", "2545352HprcOC", "isAlone", "asLabel", "Line", "unlinkEnd", "endArrow", "getLabel", "getSegmentPoints", "Invalid link's position arguments", "max", "defineProperty", "getOwnPropertyDescriptor", "draw", "begin", "ctrlPoint1"];
  return cn = function() {
    return n;
  }, cn();
}
const Gx = {};
Gx[L.begin] = function() {
  return this[I(311)][0];
}, Gx[L.end] = function() {
  return this[I(311)][1];
}, Gx[L[I(413)]] = function() {
  const n = I;
  return M.middle(this[n(311)][0], this[n(311)][1]);
};
class G extends D {
  constructor(x, t, e, s, i) {
    const r = I;
    super(), this[r(424)] = Bx[r(401)], this.points = null, t == null && (t = new M(0, 0)), e == null && (e = new M(10, 0)), this[r(307)](t, s), this.setEnd(e, i), this[r(397)] = x;
  }
  get [I(397)]() {
    const x = I;
    return this[x(337)] != null ? this[x(337)][x(397)] : this[x(398)];
  }
  set [I(397)](x) {
    const t = I;
    this.dirty = !![], this[t(332)](x), this._text = x;
  }
  [I(332)](x) {
    const t = I;
    return x == null && this[t(337)] == null ? this : x instanceof E ? (y0.LinkHelper[t(343)](this, x), x) : this[t(337)] != null && typeof x == t(378) ? (this[t(337)][t(397)] = x, this) : (y0[t(414)][t(394)](this, x), this);
  }
  [I(402)](x) {
    const t = I;
    return Object[t(316)](this, x), this[t(319)] = !![], this;
  }
  [I(347)]() {
    return this[I(337)];
  }
  [I(423)]() {
    return this[I(389)];
  }
  [I(408)](x) {
    const t = I;
    if (!(x instanceof E))
      throw new Error("arrow must be Node");
    return y0.LinkHelper[t(374)](this, x), this;
  }
  getEndArrow() {
    return this[I(346)];
  }
  [I(400)](x) {
    const t = I;
    if (!(x instanceof E))
      throw new Error("arrow must be Node");
    return y0[t(414)][t(312)](this, x), this;
  }
  [I(326)]() {
    return this[I(362)]();
  }
  [I(307)](x, t) {
    const e = I;
    this[e(319)] = !![], this[e(354)] = Hs(x, t), this[e(354)].isDisplayObjectTarget() && this[e(354)].target[e(365)](this), this[e(354)].target instanceof D && this.begin.target[e(404)](this);
  }
  [I(407)](x, t) {
    const e = I;
    this[e(319)] = !![], this[e(333)] = Hs(x, t), this[e(333)].isDisplayObjectTarget() && this.end[e(375)][e(359)](this), this[e(333)][e(375)] instanceof D && this[e(333)][e(375)][e(330)](this);
  }
  [I(392)]() {
    const x = I;
    return this.points == null && (this[x(311)] = this[x(329)]()), this[x(311)][0];
  }
  getEndPoint() {
    const x = I;
    return this[x(311)] == null && (this.points = this[x(329)]()), this[x(311)][this[x(311)][x(425)] - 1];
  }
  drawPoints(x) {
    return this[I(383)](x);
  }
  [I(383)](x) {
    const t = I;
    let e = this[t(380)](), s = this[t(339)](), i = s.x, r = s.y;
    x[t(409)](), x[t(419)](i, r), x.scale(e, e);
    let o = Z[t(391)](this[t(318)].localPoints);
    this[t(317)][t(353)](x, o, this), x[t(363)](1 / e, 1 / e), x[t(419)](-i, -r), x[t(416)]();
  }
  getShapeOrigin() {
    const x = I;
    let t = this._obb[x(395)], e = t[x(403)] || 1, s = t[x(356)] || 1, i = t.x + e * 0.5, r = t.y + s * 0.5;
    return { x: i, y: r };
  }
  getSize() {
    const x = I;
    let t = this[x(318)][x(421)], e = t[0], s = t[t.length - 1];
    if (t[x(425)] == 2) {
      let c = Math[x(384)](e.x - s.x) || 1, l = Math.abs(e.y - s.y) || 1;
      return Math[x(350)](c, l);
    }
    let i = this[x(318)][x(395)], r = i[x(403)] || 1, o = i[x(356)] || 1;
    return Math[x(350)](r, o);
  }
  [I(353)](x) {
    const t = I;
    if (this[t(354)] == null || this[t(333)] == null)
      return this;
    this[t(376)] = ![], this[t(383)](x);
    const e = this._getPickRadius();
    return !this.isPointOn && this.mousePickupStroke(x, e), this;
  }
  _getPickRadius() {
    const x = I, t = this[x(399)];
    return this._style[x(310)] >= t ? 0 : t;
  }
  [I(368)](x, t) {
    const e = I;
    if (this[e(354)] instanceof Z0) {
      let s = this[e(354)];
      s.x += x, s.y += t;
    }
    if (this[e(333)] instanceof Z0) {
      let s = this.end;
      s.x += x, s.y += t;
    }
    return this;
  }
  [I(370)]() {
    const x = I;
    let t = mx(this, this[x(354)]), e = mx(this, this[x(333)]);
    return this[x(411)](t, e, this[x(354)], !![]), this[x(411)](t, e, this[x(333)], ![]), [t, e];
  }
  [I(411)](x, t, e, s) {
    const i = I;
    let r = ln(this, e, [x, t], s), o = s ? this[i(389)] : this[i(346)], a = s ? this[i(393)] || 0 : this[i(322)] || 0, c = s ? x : t;
    if (o != null && o[i(420)] == !![]) {
      let l = this._style[i(310)] || 2, f = a + l + o[i(403)];
      s && (f = -f), this._setOffsetByVec(c, r, f);
    } else
      a != 0 && this[i(340)](c, r, a);
  }
  [I(340)](x, t, e) {
    let s = [0, 0];
    e != 0 ? F.multiplyC(s, t, -e) : s = t, x.x += s[0], x.y += s[1];
  }
  updatePoints() {
    const x = I;
    let t = this[x(370)]();
    return this[x(311)] = t, this[x(311)];
  }
  [I(362)]() {
    const x = I;
    return this[x(311)] == null && (this.points = this[x(329)]()), this[x(311)];
  }
  [I(367)]() {
    return this[I(405)];
  }
  [I(334)](x, t) {
    const e = I, s = this[e(348)](), i = x1({ x, y: t }, s);
    return i == null || i[e(425)] == 0 ? { x, y: t } : i;
  }
  [I(348)]() {
    return this[I(362)]();
  }
  upgradeParent() {
    const x = I;
    let t = this[x(354)], e = this[x(333)], s, i;
    if ((t instanceof N0 || t instanceof ht) && (s = t[x(375)]), (e instanceof N0 || e instanceof ht) && (i = e[x(375)]), s == null || i == null)
      return;
    let r = Ux(s, i);
    if (J0(r), this[x(386)] !== r)
      return this.changeParent(r), r;
  }
  [I(342)]() {
    const x = I;
    return this[x(354)][x(325)]() || this[x(333)][x(325)]() ? ![] : !![];
  }
  isBeginDisplayObject() {
    return this[I(354)].isDisplayObjectTarget();
  }
  isEndDisplayObject() {
    const x = I;
    return this.end[x(325)]();
  }
  [I(390)]() {
    const x = I;
    this[x(354)][x(325)]() && this[x(354)][x(375)][x(365)](this), this[x(307)](this[x(392)]());
  }
  [I(345)]() {
    const x = I;
    this[x(333)][x(325)]() && this[x(333)][x(375)][x(359)](this), this.setEnd(this[x(309)]());
  }
  [I(335)]() {
    this[I(390)](), this.unlinkEnd();
  }
  changeParent(x) {
    const t = I;
    if (this[t(386)] === x)
      throw new Error(t(381));
    let e = this, s = this;
    function i(r, o, a) {
      const c = t;
      let l = r[o];
      l != null && (l = r[c(415)](l.x, l.y), r[o] = a[c(406)](l.x, l.y));
    }
    if (s[t(354)] instanceof Z0 && s[t(333)] instanceof Z0) {
      let r = s[t(415)](s[t(354)].x, s[t(354)].y), o = x[t(406)](r.x, r.y);
      s[t(307)](o), r = s[t(415)](s[t(333)].x, s.end.y), o = x[t(406)](r.x, r.y), s[t(407)](o);
    }
    return s[t(366)] == "CurveLink" ? i(s, t(396), x) : s[t(366)] == t(360) ? (i(s, t(355), x), i(s, t(382), x)) : s[t(366)] == t(338) && (i(s, "fold1Offset", x), i(s, t(308), x), i(s, t(357), x)), e[t(386)] && e[t(386)][t(336)](e), x.addChild(e), this;
  }
  [I(327)](x, t, e) {
    const s = I;
    let i = this[s(314)][x];
    if (i == null && (i = this[s(364)][x]), i == null)
      throw Error(s(328) + x);
    return typeof i == "function" ? i[s(379)](this, t, e) : i;
  }
}
gt([b("Link")], G[I(313)], "className", 2), gt([b(R[I(344)])], G[I(313)], I(317), 2), gt([b(!![])], G[I(313)], "isLink", 2), gt([b(5)], G[I(313)], "_pickRadius", 2), gt([b(Gx)], G[I(313)], "DefaultPositions", 2), gt([b(D.prototype.serializers[I(412)]([I(393), I(322)]))], G[I(313)], I(358), 2), gt([b(function() {
  return [I(354), "end"];
})], G.prototype, "getAnchorPoints", 2);
function mx(n, x) {
  const t = I;
  let e;
  if (x instanceof N0) {
    let s = x[t(375)];
    e = Xr(n, s, x[t(377)]);
  } else if (x instanceof vt)
    e = qr(n, x);
  else if (x instanceof Z0)
    e = { x: x.x, y: x.y };
  else if (x instanceof ht) {
    let s = x.target, i = x.segIndex, r = x.t;
    e = Yr(n, s, i, r);
  } else if (x instanceof Nx)
    e = x.fn();
  else
    throw console[t(324)](x), new Error(t(349));
  return e;
}
function Yr(n, x, t, e) {
  const s = I;
  let i;
  if (x[s(386)] === n[s(386)])
    i = x[s(315)](e, t), i = x[s(367)]()[s(372)](i);
  else {
    let r;
    n[s(385)] == z0 ? r = n[s(373)]() : r = n[s(386)][s(373)](), i = x[s(315)](e, t), i = x[s(373)]()[s(372)](i), i = r.invert()[s(372)](i);
  }
  return i;
}
function Xr(n, x, t) {
  const e = I;
  let s;
  if (x[e(386)] === n[e(386)])
    s = x[e(327)](t), x.isNode && (s = x[e(367)]()[e(372)](s)), J0(s, x, t);
  else {
    J0(n[e(386)], n);
    let i;
    n.deep == z0 ? i = n[e(373)]() : i = n[e(386)][e(373)](), s = x[e(327)](t), s = x[e(373)]()[e(372)](s), s = i.invert().point(s), J0(s, x, t);
  }
  return s;
}
function qr(n, x) {
  const t = I;
  if (n[t(385)] == 0)
    throw new Error("link's deep is 0!");
  const e = x[t(375)], s = n.begin[t(375)] === e, i = s ? n.end : n[t(354)], r = i[t(375)];
  let o;
  n[t(385)] == z0 ? o = n[t(373)]()[t(387)]() : o = n[t(386)][t(373)]()[t(387)]();
  let a;
  i instanceof vt ? a = r[t(410)](0, 0) : (s ? a = mx(n, n[t(333)]) : a = mx(n, n[t(354)]), a = o[t(372)](a));
  let c = e[t(373)]();
  a = c[t(387)]()[t(369)]()[t(372)](a);
  let l = e.nearest(a.x, a.y);
  return l = c[t(372)](l), l = o.invert()[t(372)](l), l;
}
function Ux(n, x) {
  const t = I;
  return n[t(386)] === x[t(386)] ? n.parent : n[t(385)] == x[t(385)] ? Ux(n.parent, x[t(386)]) : n[t(385)] > x.deep ? Ux(n[t(386)], x) : Ux(n, x[t(386)]);
}
function ln(n, x, t, e) {
  const s = I;
  if (n[s(366)] == s(401)) {
    let r = t[t[s(425)] - 2], o = t[t[s(425)] - 1], a = [o.x - r.x, o.y - r.y];
    return F.normalize(a, a);
  }
  let i = ![];
  if (e) {
    if (i = x instanceof N0 && x[s(375)] instanceof E && x.name !== s(413), i == ![]) {
      t = t || n.getPoints();
      let r = t[0], o = t[1], a = [r.x - o.x, r.y - o.y];
      return n[s(366)] == s(338) && F[s(320)](a, a), F.normalize(a, a);
    }
  } else if (i = x instanceof N0 && x[s(375)] instanceof E && x[s(377)] !== s(413), i == ![]) {
    t = t || n[s(362)]();
    let r = t[t[s(425)] - 2], o = t[t[s(425)] - 1], a = [o.x - r.x, o.y - r.y];
    return F[s(418)](a, a);
  }
  if (x instanceof N0) {
    let r = t1(x[s(377)]);
    return !e && F[s(320)](r, r), r;
  }
  throw new Error(s(321));
}
function hn() {
  var n = ["56612qpnWbS", "47728175LtbRSK", "276612XxRtHz", "2MvOoyt", "1606035ddVrjH", "10VHOgNS", "enumerable", "defineProperty", "11192922GBYIuu", "writable", "3732918dRmRms", "309mayjkD", "8qaKmNf", "9705381FyOXVZ"];
  return hn = function() {
    return n;
  }, hn();
}
function fn(n, x) {
  var t = hn();
  return fn = function(e, s) {
    e = e - 306;
    var i = t[e];
    return i;
  }, fn(n, x);
}
(function(n, x) {
  for (var t = fn, e = n(); []; )
    try {
      var s = parseInt(t(316)) / 1 * (parseInt(t(315)) / 2) + -parseInt(t(310)) / 3 * (-parseInt(t(313)) / 4) + parseInt(t(317)) / 5 + parseInt(t(309)) / 6 + parseInt(t(312)) / 7 * (parseInt(t(311)) / 8) + parseInt(t(307)) / 9 + parseInt(t(318)) / 10 * (-parseInt(t(314)) / 11);
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(hn, 968947);
function pt(n, x) {
  for (var t in x) {
    let e = x[t];
    Gr(n, t, e);
  }
}
function Gr(n, x, t) {
  var e = fn;
  t[e(308)] == null && (t.writable = !![]), t[e(319)] == null && (t[e(319)] = !![]), Object[e(306)](n, x, t);
}
var I0 = dn;
function un() {
  var n = ["453110OLVMrJ", "textBaseline", "6Ympeuu", "textAlign", "className", "top", "textPosition", "2038760NzYzUo", "TextNode", "4852fUuVEh", "calcGap", "_textDirty", "417eMvlgC", "_style", "resizeToFitText", "_autoSize", "310092FGUNRq", "autoSize", "lineWidth", "52BHEXRX", "_calcTextPosition", "borderWidth", "isDirty", "2197086rJTqXA", "9WZiADM", "autoDirection", "defineProperty", "_textHeight", "prototype", "resizeTo", "5SyBCvs", "padding", "_textWidth", "823691remura", "length", "serializers", "calcTextSize", "_isTextOrStyleDirty", "10yngLdk", "2104xSxWLS", "style"];
  return un = function() {
    return n;
  }, un();
}
(function(n, x) {
  for (var t = dn, e = n(); []; )
    try {
      var s = parseInt(t(242)) / 1 * (parseInt(t(228)) / 2) + -parseInt(t(232)) / 3 * (-parseInt(t(239)) / 4) + -parseInt(t(219)) / 5 * (parseInt(t(253)) / 6) + -parseInt(t(230)) / 7 + -parseInt(t(237)) / 8 * (-parseInt(t(254)) / 9) + parseInt(t(227)) / 10 * (-parseInt(t(222)) / 11) + -parseInt(t(246)) / 12 * (-parseInt(t(249)) / 13);
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(un, 293527);
var Ur = Object[I0(215)], Zr = Object.getOwnPropertyDescriptor, Jr = (n, x, t, e) => {
  for (var s = I0, i = e > 1 ? void 0 : e ? Zr(x, t) : x, r = n[s(223)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && Ur(x, t, i), i;
};
class dt extends E {
  constructor(x, t = 0, e = 0, s = 1, i = 1, r = !![]) {
    var o = I0;
    super(x, t, e, s, i), this[o(255)] = !![], this[o(245)] = !![], this.autoSize = r;
  }
  get autoSize() {
    return this._autoSize;
  }
  set [I0(247)](x) {
    this._autoSize = x;
  }
  [I0(226)]() {
    var x = I0;
    return this[x(241)] || this[x(229)][x(252)]() ? (this[x(245)] && this[x(244)](), !![]) : ![];
  }
  [I0(244)]() {
    var x = I0;
    super[x(225)]();
    let e = this[x(243)][x(240)]();
    this[x(218)](this[x(221)] + e, this[x(216)] + e);
  }
  _calcTextPosition() {
    var x = I0;
    const t = this[x(243)];
    let e = t[x(251)] || 0, s = (t[x(220)] || 0) + (t[x(248)] | 0);
    return (t[x(231)] == "bottom" && (t[x(236)] == "lt" || t.textPosition == "ct" || t[x(236)] == "rt") || t[x(231)] == x(235) && (t[x(236)] == "lb" || t[x(236)] == "cb" || t[x(236)] == "rb") || t[x(233)] == "right" && (t[x(236)] == "lt" || t[x(236)] == "lm" || t.textPosition == "lb") || t[x(233)] == "left" && (t[x(236)] == "rt" || t[x(236)] == "rm" || t[x(236)] == "rb")) && (e = 0, s = 0), super[x(250)](e, s);
  }
}
Jr([b(I0(238))], dt[I0(217)], I0(234), 2), pt(dt.prototype, { serializers: { value: E[I0(217)][I0(224)].concat([I0(247), I0(255)]) } });
function dn(n, x) {
  var t = un();
  return dn = function(e, s) {
    e = e - 215;
    var i = t[e];
    return i;
  }, dn(n, x);
}
function pn() {
  const n = ["2865708gGCkal", "4454765ZDIkPG", "beginArrow", "negate", "originAlignPosition", "skewX", "getTransformByDeep", "cos", "getK", "autoDirection", "13857444QxtIlO", "136Giknqc", "identity", "positionToLocalPoint", "getTransform", "skewY", "translate", "parent", "calcOriginInParent", "665117tkkaUF", "sin", "2862777HXtfOz", "2JLbYtS", "originOffset", "height", "end", "deep is required.", "rotate", "getPoints", "endArrow", "transform", "scaleX", "origin", "begin", "rotation", "stage", "getPoint", "rotateCenter", "scaleY", "copy", "getOriginRotation", "deep", "2816280LXQErF", "313691SwkQaA", "width", "getCS", "atan2"];
  return pn = function() {
    return n;
  }, pn();
}
function bn(n, x) {
  const t = pn();
  return bn = function(e, s) {
    return e = e - 294, t[e];
  }, bn(n, x);
}
const _0 = bn;
(function(n, x) {
  const t = bn, e = n();
  for (; []; )
    try {
      if (-parseInt(t(300)) / 1 * (-parseInt(t(303)) / 2) + parseInt(t(302)) / 3 + -parseInt(t(323)) / 4 + parseInt(t(329)) / 5 + -parseInt(t(328)) / 6 + -parseInt(t(324)) / 7 * (-parseInt(t(339)) / 8) + -parseInt(t(338)) / 9 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(pn, 550746);
class s1 {
  [_0(321)](x) {
    return 0;
  }
  [_0(295)](x) {
    const t = _0;
    let e = x[t(311)];
    return e[t(340)](), this[t(311)](e, x), e;
  }
  [_0(334)](x, t) {
    const e = _0;
    if (t == null)
      throw new Error(e(307));
    if (x[e(322)] <= t || x[e(298)] == null)
      return x[e(295)]();
    let s = this[e(334)](x[e(298)], t)[e(320)]();
    return this.transform(s, x), s;
  }
  [_0(311)](x, t) {
    const e = _0;
    if (!(t instanceof E) || t[e(298)] == null && !(t instanceof ut))
      return;
    let s = this[e(299)](t, t[e(298)]), i = s[0] + t.x, r = s[1] + t.y;
    x[e(297)](i, r), (t[e(333)] != 0 || t[e(296)] != 0) && x[e(311)](1, t[e(333)], t[e(296)], 1, 0, 0), (t[e(312)] !== 1 || t[e(319)] !== 1) && x.scale(t[e(312)], t[e(319)]);
    let o = this.getOriginRotation(t) + t[e(315)];
    if (o != 0) {
      let a = t[e(294)](t[e(318)]);
      x[e(297)](a.x, a.y), x[e(308)](o), x[e(297)](-a.x, -a.y);
    }
  }
}
class ui extends s1 {
  [_0(299)](x, t) {
    const e = _0;
    if (x instanceof Is)
      return [0, 0];
    if (x instanceof ut) {
      const s = x[e(316)];
      return [s[e(325)] * 0.5, s[e(305)] * 0.5];
    } else if (x instanceof E) {
      let s = [x.origin[0] * t.width, x[e(313)][1] * t[e(305)]], i = x[e(332)];
      if (i != null) {
        let r = x[e(294)](i);
        s[0] -= r.x, s[1] -= r.y;
      }
      return s;
    } else if (x instanceof G)
      return [0, 0];
    throw new Error("unknow origin object type");
  }
}
class di extends s1 {
  [_0(299)](x, t) {
    const e = _0;
    if (t == null || x instanceof G)
      return x[e(313)];
    let s = x[e(313)][0], i = x[e(313)][1], r = t[e(317)](i, s);
    if (x[e(304)]) {
      let a = this.getOriginRotation(x);
      r = { x: r.x + x[e(304)] * Math[e(335)](a), y: r.y + x.originOffset * Math[e(301)](a) };
    }
    let o = x[e(332)];
    if (o != null) {
      let a = x[e(294)](o);
      r.x -= a.x, r.y -= a.y;
    }
    return [r.x, r.y];
  }
  [_0(311)](x, t) {
    const e = _0;
    if (t instanceof dt && t[e(337)] == !![]) {
      let s = this[e(321)](t);
      s < -Math.PI / 2 || s > Math.PI / 2 ? t[e(315)] = Math.PI : t.rotation = 0;
    }
    return super[e(311)](x, t);
  }
  [_0(321)](x) {
    const t = _0;
    let e = 0;
    if (x.originAutoRotate) {
      let i = x[t(313)][0], r = x.origin[1];
      e = x[t(298)][t(336)](i, r);
    }
    let s = x[t(298)];
    if (x === s[t(330)]) {
      let i = ln(s, s[t(314)], s[t(309)](), !![]);
      F[t(331)](i, i), e = Math[t(327)](i[1], i[0]);
    } else if (x === s[t(310)]) {
      let i = ln(s, s[t(306)], s[t(309)](), ![]);
      e = Math.atan2(i[1], i[0]);
    }
    return e;
  }
}
const Vr = new di(), Qr = new ui();
function i1(n) {
  return n[_0(298)] instanceof G ? Vr : Qr;
}
y0[_0(326)] = i1;
const T = Ix;
function Ix(n, x) {
  const t = gn();
  return Ix = function(e, s) {
    return e = e - 401, t[e];
  }, Ix(n, x);
}
(function(n, x) {
  const t = Ix, e = n();
  for (; []; )
    try {
      if (parseInt(t(487)) / 1 + -parseInt(t(434)) / 2 + parseInt(t(428)) / 3 + parseInt(t(484)) / 4 * (parseInt(t(504)) / 5) + parseInt(t(457)) / 6 + -parseInt(t(489)) / 7 * (-parseInt(t(492)) / 8) + -parseInt(t(474)) / 9 * (parseInt(t(506)) / 10) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(gn, 977733);
function gn() {
  const n = ["display", "draw", "shadowColor", "className", "image/png", "destoryed", "styleX", "_paintChildren", "360500UYMvrd", "cursor", "_computeStyle", "410085DWFoeu", "points", "776468FaBRAv", "getRectImageData", "isPointInStroke", "112ovnZJX", "quadraticCurveTo", "#009A93", "isPointOn", "isSelected", "save", "_style", "styleSystem", "lineWidth", "isMouseInObjectAABB", "inputSystem", "dispose", "5EcHSOR", "style", "176380UQXMBu", "setLineDash", "paintAABB", "layer", "paint", "restore", "context", "_paintNodeOrLinkPrepare", "getCursor", "toDataURL", "cuttingHide", "isLayer", "contextExtends", "displayList", "toStageXY", "transform", "applyTo", "devicePixelRatio", "lineTo", "paintChildrenWhenOutOfViewport", "pink", "visible", "push", "beginPath", "selectedStyle", "show", "shadowOffsetX", "hide", "closePath", "0px", "styleY", "absolute", "getHeight", "isPointInPath", "shadowBlur", "none", "2069190NkAxgi", "isIdle", "rgba(0,0,255,0.3)", "length", "stage", "getContext", "3054726hozJpG", "remove", "roundRect", "isOutOfViewPort", "moveTo", "children", "max", "getTransform", "getOBBPoints", "contains", "aabb", "_obb", "gray", "fillText", "exportPaintObjects", "strokeStyle", "_isOutOfViewport", "isDraging", "globalAlpha", "clearAll", "getWidth", "getViewportRectInLayer", "isIntersectRect", "5557968lrjyCw", "mouseX", "clear", "paintSelected", "shadowOffsetY", "axis", "canvas", "painted", "height", "updatePoints", "width", "showSelected", "render", "fillStyle", "scaleX", "stroke", "paintAxis", "594MwktCU", "paintOBB"];
  return gn = function() {
    return n;
  }, gn();
}
var Kr = ct.gc;
let b1 = V0.w;
class _n extends Hr {
  constructor(x, t) {
    const e = Ix;
    super(), this[e(481)] = ![], this[e(432)] = x, this[e(509)] = t, this[e(463)] = document.createElement(e(463)), Object.assign(this[e(463)][e(505)], { position: e(423), left: e(421) }), this[e(512)] = this[e(463)][e(433)]("2d"), this[e(512)][e(469)] = this, window[e(409)] && this[e(512)].scale(window[e(409)], window[e(409)]), this[e(404)]();
  }
  [T(503)]() {
    const x = T;
    this.canvas[x(435)]();
  }
  renderLayer(x) {
    const t = T;
    if (this[t(432)] = this[t(509)][t(432)], this.styleSystem = this[t(432)][t(499)], this[t(459)](), x[t(462)].visible && x[t(479)] != "HandlerLayer" && this[t(473)](x), this[t(510)](x), Pt.paintAABB == !![] && this[t(509)] != null) {
      let s = x[t(439)];
      if (s != null)
        for (var e = s[t(431)] - 1; e >= 0; e--) {
          let i = s[e];
          this[t(508)](i);
        }
    }
    {
      if (b1 == null)
        return;
      let s = this[t(512)];
      s.save(), s[t(452)] = 0.8, s.font = "bold 16px arial";
      let i = Kr(b1);
      s[t(470)] = t(446), s[t(447)](i, 14, this.getHeight() - 14), s[t(511)]();
    }
  }
  isOutOfViewPort(x) {
    const t = T;
    if (x[t(403)])
      return ![];
    if (this[t(509)] == null)
      return ![];
    const e = this.layer;
    return e[t(402)] == ![] ? ![] : !e[t(455)]()[t(456)](x._obb[t(444)]);
  }
  [T(513)](x) {
    const t = T;
    return x.painted = ![], x instanceof G && (x[t(488)] = x[t(466)]()), x[t(413)] == ![] ? ![] : (x[t(445)] = x.getOBB(), x._isOutOfViewport = this[t(437)](x), !![]);
  }
  overviewPaint(x) {
    return this.paint(x, !![], ![]);
  }
  exportPaint(x) {
    const t = T;
    return this[t(513)](x), this[t(510)](x, ![], !![]);
  }
  [T(448)](x) {
    const t = T;
    for (let e = 0; e < x[t(431)]; e++)
      this.exportPaint(x[e]);
  }
  paint(x, t = ![], e = ![]) {
    const s = T;
    let i = this[s(512)], r = this[s(432)];
    this[s(509)] != null && (x[s(495)] = ![]);
    let o = !(x instanceof G || x instanceof Is);
    if (i[s(497)](), o && i1(x)[s(407)](i, x), x[s(450)] == ![]) {
      x[s(464)] = !![], r[s(499)][s(486)](x), x[s(498)][s(408)](i);
      let a = x[s(496)] && x[s(468)] == !![];
      a && (i[s(497)](), this[s(460)](x)), x[s(477)](i), a && i[s(511)]();
    }
    return this[s(483)](x, t, e), i.restore(), x;
  }
  [T(483)](x, t = ![], e = ![]) {
    const s = T;
    let i = x[s(439)];
    if (i[s(431)] == 0 || x[s(450)] && x[s(411)] == ![])
      return;
    const r = this[s(509)];
    for (var o = 0; o < i[s(431)]; o++) {
      let a = i[o];
      this._paintNodeOrLinkPrepare(a) == !![] && (this.paint(a, t, e), r && a[s(464)] && r[s(405)][s(414)](a));
    }
  }
  [T(460)](x) {
    const t = T;
    let e = this[t(512)];
    if (x.selectedStyle != null && x.selectedStyle[t(408)](e), x[t(460)] != null) {
      x.paintSelected(e);
      return;
    }
    if (x instanceof E) {
      e[t(497)](), e[t(415)]();
      let s = 1;
      x[t(416)] != null ? s = x[t(416)].lineWidth | s : (e[t(507)]([0, 0]), this[t(499)] ? e[t(449)] = this[t(499)].selectedStyle : e.strokeStyle = t(494)), e[t(500)] = s;
      let i = x[t(467)] + s + 3, r = x.height + s + 3;
      e.rect(-i * 0.5, -r * 0.5, i, r), e[t(472)](), e[t(420)](), e.restore();
    } else
      this[t(499)] ? e[t(478)] = this[t(499)][t(416)] : e.shadowColor = "#009A93", e[t(426)] = 5, e[t(418)] = 3, e[t(461)] = 3;
  }
  [T(453)]() {
    this[T(459)]();
  }
  dontNeedPickup(x) {
    const t = T;
    let e = this.stage;
    return e == null ? !![] : this[t(509)] == null ? !![] : e[t(502)][t(451)] ? !![] : e[t(502)].x < 0 || e[t(502)].y < 0 ? !![] : e[t(502)][t(429)] == !![] ? !![] : this[t(501)](x) ? ![] : !![];
  }
  [T(501)](x) {
    const t = T;
    let e = x[t(445)][t(444)];
    return x instanceof G && (e = e.clone(), e.x -= 2, e.y -= 2, e[t(467)] += 4, e[t(465)] += 4), e[t(443)](this[t(509)][t(458)], this[t(509)].mouseY);
  }
  isMouseInStroke(x, t) {
    const e = T;
    let s = this.context, i = this.stage;
    if (x == null || x == 0)
      return t != null ? s[e(491)](t, i[e(502)].x, i[e(502)].y) : s.isPointInStroke(i.inputSystem.x, i[e(502)].y);
    let r = ![];
    for (var o = 0; o < x; o++) {
      if (t != null ? r = s[e(491)](t, i[e(502)].x + o, i[e(502)].y + o) : r = s.isPointInStroke(i[e(502)].x + o, i[e(502)].y + o), r)
        return !![];
      if (t != null ? r = s[e(491)](t, i[e(502)].x - o, i[e(502)].y - o) : r = s[e(491)](i.inputSystem.x - o, i.inputSystem.y - o), r)
        return !![];
      if (t != null ? r = s[e(491)](t, i[e(502)].x - o, i[e(502)].y + o) : r = s[e(491)](i[e(502)].x - o, i[e(502)].y + o), r)
        return !![];
      if (t != null ? r = s[e(491)](t, i[e(502)].x + o, i.inputSystem.y - o) : r = s[e(491)](i[e(502)].x + o, i[e(502)].y - o), r)
        return !![];
    }
    return ![];
  }
  isMouseInPath(x) {
    const t = T;
    let e = this[t(512)], s = this[t(432)];
    return x ? e[t(425)](x, s[t(502)].x, s.inputSystem.y) : e[t(425)](s.inputSystem.x, s[t(502)].y);
  }
  [T(404)]() {
    const x = T;
    this.context[x(436)] == null && (this[x(512)][x(436)] = function(t, e, s, i, r) {
      const o = x;
      this[o(415)](), this[o(438)](t + r, e), this.lineTo(t + s - r, e), this[o(493)](t + s, e, t + s, e + r), this[o(410)](t + s, e + i - r), this.quadraticCurveTo(t + s, e + i, t + s - r, e + i), this[o(410)](t + r, e + i), this.quadraticCurveTo(t, e + i, t, e + i - r), this.lineTo(t, e + r), this.quadraticCurveTo(t, e, t + r, e), this[o(420)]();
    });
  }
  [T(508)](x) {
    const t = T;
    if (x._obb == null)
      return;
    let e = this[t(509)], s = this[t(512)], i = x[t(445)].aabb;
    i = e.toStageRect(i), s[t(497)](), x instanceof ut ? s[t(449)] = t(430) : x instanceof G ? s[t(449)] = "pink" : s[t(449)] = "green", s[t(415)](), s.rect(i.x, i.y, i[t(467)], i[t(465)]), s[t(472)](), s[t(420)](), s[t(511)]();
  }
  [T(475)](x) {
    const t = T;
    if (x[t(445)] == null)
      return;
    let e = this.context, s = this[t(509)][t(441)](), i = s.points(x[t(442)]());
    e[t(497)](), x instanceof ut ? e[t(449)] = "rgba(0,0,255,0.3)" : x instanceof G ? e.strokeStyle = t(412) : e[t(449)] = "green", e.beginPath(), e[t(438)](i[0].x, i[0].y);
    for (let r = 1; r < i.length; r++) {
      const o = i[r];
      e[t(410)](o.x, o.y);
    }
    e[t(410)](i[0].x, i[0].y), e[t(472)](), e.closePath(), e[t(511)]();
  }
  [T(417)]() {
    const x = T;
    this.canvas.style[x(476)] = "block";
  }
  [T(419)]() {
    const x = T;
    this[x(463)][x(505)].display = x(427);
  }
  [T(454)]() {
    const x = T;
    return this.canvas[x(467)];
  }
  getHeight() {
    const x = T;
    return this[x(463)][x(465)];
  }
  setSize(x, t) {
    const e = T;
    this[e(463)][e(467)] = x, this[e(463)].height = t;
  }
  [T(514)]() {
    const x = T;
    return this.canvas[x(505)][x(485)];
  }
  setCursor(x) {
    const t = T;
    this.canvas[t(505)].cursor = x;
  }
  [T(401)](x, t) {
    const e = T;
    return x = x || e(480), this[e(463)][e(401)](x, t);
  }
  [T(490)](x, t, e, s) {
    const i = T;
    return x == null && (x = 0), t == 0 && (t = 0), e == null && (e = this[i(454)]()), s == null && (s = this[i(424)]()), this[i(512)].getImageData(x, t, e, s);
  }
  [T(473)](x) {
    const t = T;
    let e = this.context;
    const s = x[t(432)][t(467)], i = x[t(432)][t(465)], r = x[t(406)](0, 0);
    e.save(), r.x > 0 && r.x < s && (e[t(415)](), x[t(462)][t(422)][t(408)](e), e[t(438)](r.x, 0), e[t(410)](r.x, i), e[t(438)](r.x - 5, i - 8), e[t(410)](r.x, i), e[t(410)](r.x + 5, i - 8), e[t(472)](), e[t(447)]("+y", r.x + 6, i - 5)), r.y > 0 && r.y < i && (e[t(415)](), x[t(462)][t(482)][t(408)](e), e[t(438)](s * 0.5, r.y), e[t(410)](0, r.y), e.moveTo(s * 0.5, r.y), e[t(410)](s, r.y), e.moveTo(s - 8, r.y - 5), e[t(410)](s, r.y), e[t(410)](s - 8, r.y + 5), e[t(472)](), e[t(447)]("+x", s - 5, r.y + 5));
    let o = x[t(462)].styleX, a = x[t(462)].styleY;
    o.lineWidth = Math[t(440)](1, x[t(471)]), a[t(500)] = Math.max(1, x.scaleY), e[t(511)]();
  }
  [T(459)]() {
    const x = T;
    this[x(463)][x(467)] = this.canvas[x(467)];
  }
}
const J = wx;
(function(n, x) {
  const t = wx, e = n();
  for (; []; )
    try {
      if (parseInt(t(425)) / 1 + parseInt(t(441)) / 2 + -parseInt(t(387)) / 3 + parseInt(t(400)) / 4 * (parseInt(t(450)) / 5) + parseInt(t(455)) / 6 + -parseInt(t(381)) / 7 * (parseInt(t(448)) / 8) + -parseInt(t(439)) / 9 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(yn, 896392);
function wx(n, x) {
  const t = yn();
  return wx = function(e, s) {
    return e = e - 373, t[e];
  }, wx(n, x);
}
function yn() {
  const n = ["stage", "hide", "canvas", "mousemoveHandler", "union", "rgba(255,255,255,0.5)", "forEach", "rectObj", "addEventListener", "zIndex", "getAABB", "border", "render", "clearAll", "rect", "getRect", "mousedown", "674537CXmxsf", "getLayersAABBRect", "domElement", "Handler", "height", "mouseupHandler", "right", "_overviewTimer", "offsetY", "backgroundColor", "layersAABBRect", "dirty", "isDraging", "getChildren", "19293885ZMzzqN", "scale", "3347000rBBDHM", "setSize", "pickedObject", "context", "lineWidth", "mousemove", "stroke", "96gYQgMU", "moveWith", "530bsGFZq", "mouseup", "style", "getHeight", "update", "5831526Meheol", "strokeStyle", "visible", "getWidth", "fill", "save", "translateWith", "position", "handlerLayer", "translate", "layersContainer", "width", "mousewheelHandler", "598409DjCZCN", "show", "mousedownHandler", "offsetX", "max", "mousedragHandler", "1940073ODyiRo", "setTo", "initEvent", "restore", "paint", "paintDragRect", "map", "left", "solid 1px gray", "red", "Overview has no handler:", "overviewPaint", "css", "52556sYnZOA", "resizeTo", "0.7", "inputSystem", "preventDefault", "fillStyle", "rgba(0,250,50,0.2)", "contains"];
  return yn = function() {
    return n;
  }, yn();
}
class $r {
  constructor(x) {
    const t = wx;
    this.visible = ![], this[t(436)] = !![], this.layersAABBRect = new q(), this[t(408)] = x, this[t(403)] = new n1(), this.render = new _n(x);
    let e = this[t(420)][t(410)];
    e[t(452)][t(434)] = t(413), e.style[t(419)] = t(395), e[t(452)][t(375)] = "absolute", e[t(452)].zIndex = "" + (x[t(376)][t(417)] + 1), e[t(452)].opacity = t(402), e[t(452)][t(431)] = "0", e[t(452)][t(394)] = null, e[t(452)].bottom = "0", x[t(378)].appendChild(e), this[t(410)] = e, this[t(427)] = e, this.render.setSize(200, 200 * 0.618), this[t(415)] = new E(null, 0, 0), this[t(415)][t(409)](), this[t(389)](), this[t(409)]();
  }
  [J(399)](x) {
    const t = J;
    if (x == null)
      return this;
    for (let e in x)
      this[t(410)].style[e] = x[e];
    return this;
  }
  [J(389)]() {
    const x = J;
    let t = this, e = [x(424), x(451), x(446), "mousewheel"], s = t[x(420)], i = s[x(410)], r = this[x(403)];
    e[x(393)](function(o) {
      const a = x;
      Q0[a(416)](i, o, function(c) {
        const l = a;
        if (c[l(384)] < 0 || c[l(433)] < 0)
          return;
        r.update(c, o);
        let f = o + l(428);
        if (r[l(437)] && (f = l(386)), t[f] == null)
          throw new Error(l(397) + o);
        t[f](c);
      });
    });
  }
  [J(382)]() {
    const x = J;
    this.visible = !![], this[x(420)][x(382)](), clearInterval(this._overviewTimer);
    let t = this;
    return this[x(432)] = setInterval(function() {
      t.dirty && t.update();
    }, 500), this;
  }
  hide() {
    const x = J;
    return this[x(457)] = ![], this.render[x(409)](), clearInterval(this._overviewTimer), this;
  }
  [J(458)]() {
    const x = J;
    return this[x(420)][x(458)]();
  }
  getHeight() {
    const x = J;
    return this.render[x(453)]();
  }
  setSize(x, t) {
    const e = J;
    return this[e(420)][e(442)](x, t);
  }
  [J(426)]() {
    const x = J;
    let t = null;
    return this[x(408)][x(438)]()[x(414)](function(e, s) {
      const i = x;
      let r = e[i(418)](!![]);
      t == null ? t = r : t = q[i(412)](t, r);
    }), this[x(435)][x(388)](t.x, t.y, t.width, t[x(429)]), this[x(435)];
  }
  paint() {
    const x = J;
    let t = this, e = t[x(408)], s = t.render, i = t[x(458)](), r = t[x(453)](), o = this.getLayersAABBRect();
    if (o == null)
      return;
    let a = Math[x(385)](i, o[x(379)]), c = Math[x(385)](r, o[x(429)]), l = i / a, f = r / c;
    s[x(421)]();
    let u = s[x(444)];
    u[x(373)](), u[x(440)](l, f), u[x(377)](-o.x, -o.y), e[x(438)]()[x(414)](function(y) {
      const m = x;
      y[m(436)] = !![], s[m(398)](y);
    }), u[x(390)](), this.paintDragRect(u, o);
  }
  [J(392)](x, t) {
    const e = J;
    let s = this[e(415)], i = this.stage, r = this[e(420)], o = Math[e(385)](t[e(379)], i[e(379)]), a = Math[e(385)](t.height, i.height), c = i[e(379)] / o, l = i.height / a;
    if (c == 1 && l == 1) {
      s[e(409)]();
      return;
    }
    s[e(382)]();
    let f = r[e(458)]() * c, u = r[e(453)]() * l;
    s[e(401)](f, u);
    let y = r[e(458)]() / o, m = r[e(453)]() / a, p = -t.x * y, k = -t.y * m;
    p < 0 && (p = 0), k < 0 && (k = 0), p + s[e(379)] > r.getWidth() && (p = r.getWidth() - s[e(379)]), k + s[e(429)] > r[e(453)]() && (k = r.getHeight() - s[e(429)]), s.translateTo(p, k), x[e(373)](), x[e(445)] = 2, x[e(405)] = e(406), x[e(456)] = e(396), x.beginPath(), x[e(422)](s.x, s.y, s[e(379)], s.height), x[e(447)](), x[e(459)](), x[e(390)]();
  }
  [J(454)]() {
    const x = J;
    this[x(457)] && (this[x(408)][x(454)](), this[x(391)]());
  }
  [J(383)]() {
    const x = J;
    let t = this.rectObj[x(423)](), e = this.inputSystem.x, s = this[x(403)].y;
    t[x(407)](e, s) && (this[x(403)][x(443)] = this.rectObj);
    let i = e - (this[x(415)].x + this[x(415)].width / 2), r = s - (this[x(415)].y + this[x(415)][x(429)] / 2);
    this[x(449)](i, r);
  }
  [J(386)]() {
    const x = J;
    let t = this[x(403)].dx, e = this[x(403)].dy;
    this.moveWith(t, e);
  }
  [J(449)](x, t) {
    const e = J;
    if (!this[e(415)][e(457)])
      return;
    x < 0 && this[e(415)].x + x <= 0 && (x = -this.rectObj.x), x > 0 && this[e(415)].x + this[e(415)][e(379)] >= this[e(458)]() && (x = this[e(458)]() - this[e(415)][e(379)] - this.rectObj.x), t < 0 && this[e(415)].y <= 0 && (t = -this[e(415)].y), t > 0 && this[e(415)].y + this[e(415)][e(429)] >= this.getHeight() && (t = this[e(453)]() - this.rectObj[e(429)] - this[e(415)].y), this[e(415)][e(374)](x, t);
    let i = this.getLayersAABBRect(), r = i[e(379)], o = i.height, a = r * (x / this[e(458)]()), c = o * (t / this[e(453)]());
    this[e(408)][e(438)]()[e(414)](function(f, u) {
      f.translateWith(-a, -c);
    });
    let l = this;
    this._updateTimer = setTimeout(function() {
      l.update();
    }, 20), this[e(408)][e(438)]()[e(414)](function(f, u) {
      f.dirty = !![];
    }), this[e(408)][e(454)]();
  }
  [J(380)](x) {
    x[J(404)]();
  }
  [J(411)]() {
  }
  [J(430)]() {
    const x = J;
    this.inputSystem[x(443)] = null;
  }
}
const to = `.jtopo_popoupmenu{padding:10px;border-radius:5px;min-width:210px;background-color:#fff;border:1px solid;position:absolute;z-index:10000}.jtopo_popoupmenu .header{font-size:14px;height:24px;padding-bottom:3px}.jtopo_popoupmenu a{text-rendering:optimizeLegibility;font-family:Open Sans,Helvetica Neue,Helvetica,Arial,sans-serif;padding-left:20px;display:block;height:25px;color:#00000080;font-size:13px;cursor:pointer}.jtopo_popoupmenu a:hover{color:#000}.jtopo_iconsPanel{opacity:.8;padding-left:5px;position:absolute;background-color:#e8e8e8;top:90px;width:52px;height:425px;z-index:1000;border-radius:5px}.jtopo_iconsPanel .item{border:1px solid white;width:42px;height:42px;margin-top:10px}.jtopo_toolbar{border-bottom:1px dotted;padding-bottom:2px;border-color:#e0e0e0;width:100%;min-height:33px;background-color:#e8e8e8}.jtopo_toolbar .group{float:left;margin-right:5px}.jtopo_toolbar .item{float:left;width:32px;height:32px;stroke:gray;stroke-width:1;stroke-linecap:square;stroke-linejoin:miter;fill:none;font-size:12px;color:gray}.jtopo_toolbar .active{background-color:#d3d3d3;border:1px solid black}.jtopo_toolbar input[type=text]{font-size:12px;color:gray;float:left;width:120px;height:26px;border:1px solid white;margin:2px 2px 2px 4px}.jtopo_input_textfield{position:absolute;display:none;font-size:smaller;z-index:10000}.jtopo_tooltip{pointer-events:none;opacity:.9;min-width:30px;min-height:30px;padding:10px;border-radius:5px;background-color:#f8f8f8;border:1px solid;position:absolute;z-index:10000}.jtopo_historyPanel{position:absolute;left:0px;top:100%;width:879px;overflow-x:scroll;height:600px;z-index:1000}.jtopo_debugPanel{user-select:none;border:dashed 1px gray;padding:8px;position:absolute;left:0px;top:0%;width:300px;z-index:98;text-align:left;font-size:10px;color:gray}
`, $ = S0;
(function(n, x) {
  const t = S0, e = n();
  for (; []; )
    try {
      if (-parseInt(t(244)) / 1 + parseInt(t(260)) / 2 * (parseInt(t(251)) / 3) + parseInt(t(272)) / 4 + -parseInt(t(303)) / 5 + -parseInt(t(304)) / 6 * (-parseInt(t(307)) / 7) + parseInt(t(286)) / 8 * (-parseInt(t(282)) / 9) + parseInt(t(275)) / 10 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(mn, 107564);
function xo(n, x, t, e) {
  return t * n / e + x;
}
function eo(n, x, t, e) {
  return t * (n /= e) * n + x;
}
function no(n, x, t, e) {
  return -t * (n /= e) * (n - 2) + x;
}
function so(n, x, t, e) {
  return (n /= e / 2) < 1 ? t / 2 * n * n + x : -t / 2 * (--n * (n - 2) - 1) + x;
}
function io(n, x, t, e) {
  const s = S0;
  return -t * Math[s(279)](n / e * (Math.PI / 2)) + t + x;
}
function ro(n, x, t, e) {
  return t * Math.sin(n / e * (Math.PI / 2)) + x;
}
function oo(n, x, t, e) {
  const s = S0;
  return -t / 2 * (Math[s(279)](Math.PI * n / e) - 1) + x;
}
function ao(n, x, t, e) {
  const s = S0;
  return n == 0 ? x : t * Math[s(253)](2, 10 * (n / e - 1)) + x;
}
function co(n, x, t, e) {
  const s = S0;
  return n == 0 ? x : n == e ? x + t : (n /= e / 2) < 1 ? t / 2 * Math.pow(2, 10 * (n - 1)) + x : t / 2 * (-Math[s(253)](2, -10 * --n) + 2) + x;
}
function lo(n, x, t, e) {
  const s = S0;
  return -t * (Math[s(306)](1 - (n /= e) * n) - 1) + x;
}
function ho(n, x, t, e) {
  return t * Math[S0(306)](1 - (n = n / e - 1) * n) + x;
}
function fo(n, x, t, e) {
  const s = S0;
  return (n /= e / 2) < 1 ? -t / 2 * (Math[s(306)](1 - n * n) - 1) + x : t / 2 * (Math.sqrt(1 - (n -= 2) * n) + 1) + x;
}
function uo(n, x, t, e) {
  return t * (n /= e) * n * n + x;
}
function po(n, x, t, e) {
  return t * ((n = n / e - 1) * n * n + 1) + x;
}
function mn() {
  const n = ["continue", "pow", "animations", "times", "paused", "from", "delay", "setFrom", "26nMrihr", "idle", "anime_", "asin", "easeLinear", "cancel", "resolve", "alternate", "sin", "system", "stepAction", "alternate-reverse", "131084AczzJB", "number", "fillMode", "4607510jsMRpa", "add", "isArray", "length", "cos", "promise", "catch", "387ZrNsfk", "_getTickAction", "name", "set", "39464ibZujW", "setDuration", "normal", "now", "playedTimes", "abs", "update", "finished", "startTime", "tick", "onEnd", "running", "currentTime", "indexOf", "anime", "action", "effect", "231345UrQAQz", "42AfwOQR", "duration", "sqrt", "5572rclvac", "reject", "filter", "cancelAll", "remove", "156672jhitts", "reverse", "value format error.", "slice", "isPause", "playState", "direction", "5430WwzWKa"];
  return mn = function() {
    return n;
  }, mn();
}
function bo(n, x, t, e) {
  return (n /= e / 2) < 1 ? t / 2 * n * n * n + x : t / 2 * ((n -= 2) * n * n + 2) + x;
}
function go(n, x, t, e) {
  return t * (n /= e) * n * n * n + x;
}
function _o(n, x, t, e) {
  return -t * ((n = n / e - 1) * n * n * n - 1) + x;
}
function yo(n, x, t, e) {
  return (n /= e / 2) < 1 ? t / 2 * n * n * n * n + x : -t / 2 * ((n -= 2) * n * n * n - 2) + x;
}
function mo(n, x, t, e) {
  return t * (n /= e) * n * n * n * n + x;
}
function Io(n, x, t, e) {
  return t * ((n = n / e - 1) * n * n * n * n + 1) + x;
}
function wo(n, x, t, e) {
  return (n /= e / 2) < 1 ? t / 2 * n * n * n * n * n + x : t / 2 * ((n -= 2) * n * n * n * n + 2) + x;
}
function vo(n, x, t, e) {
  const s = S0;
  var o = 1.70158, i = 0, r = t;
  if (n == 0)
    return x;
  if ((n /= e) == 1)
    return x + t;
  if (i || (i = e * 0.3), r < Math[s(291)](t)) {
    r = t;
    var o = i / 4;
  } else
    var o = i / (2 * Math.PI) * Math[s(263)](t / r);
  return -(r * Math.pow(2, 10 * (n -= 1)) * Math[s(268)]((n * e - o) * (2 * Math.PI) / i)) + x;
}
function Po(n, x, t, e) {
  const s = S0;
  var o = 1.70158, i = 0, r = t;
  if (n == 0)
    return x;
  if ((n /= e) == 1)
    return x + t;
  if (i || (i = e * 0.3), r < Math.abs(t)) {
    r = t;
    var o = i / 4;
  } else
    var o = i / (2 * Math.PI) * Math[s(263)](t / r);
  return r * Math.pow(2, -10 * n) * Math[s(268)]((n * e - o) * (2 * Math.PI) / i) + t + x;
}
function ko(n, x, t, e) {
  const s = S0;
  var o = 1.70158, i = 0, r = t;
  if (n == 0)
    return x;
  if ((n /= e / 2) == 2)
    return x + t;
  if (i || (i = e * (0.3 * 1.5)), r < Math[s(291)](t)) {
    r = t;
    var o = i / 4;
  } else
    var o = i / (2 * Math.PI) * Math[s(263)](t / r);
  return n < 1 ? -0.5 * (r * Math[s(253)](2, 10 * (n -= 1)) * Math[s(268)]((n * e - o) * (2 * Math.PI) / i)) + x : r * Math[s(253)](2, -10 * (n -= 1)) * Math[s(268)]((n * e - o) * (2 * Math.PI) / i) * 0.5 + t + x;
}
function So(n, x, t, e, s) {
  return s == null && (s = 1.70158), t * (n /= e) * n * ((s + 1) * n - s) + x;
}
function Oo(n, x, t, e, s) {
  return s == null && (s = 1.70158), t * ((n = n / e - 1) * n * ((s + 1) * n + s) + 1) + x;
}
function Lo(n, x, t, e, s) {
  return s == null && (s = 1.70158), (n /= e / 2) < 1 ? t / 2 * (n * n * (((s *= 1.525) + 1) * n - s)) + x : t / 2 * ((n -= 2) * n * (((s *= 1.525) + 1) * n + s) + 2) + x;
}
function pi(n, x, t, e) {
  return t - r1(e - n, 0, t, e) + x;
}
function r1(n, x, t, e) {
  return (n /= e) < 1 / 2.75 ? t * (7.5625 * n * n) + x : n < 2 / 2.75 ? t * (7.5625 * (n -= 1.5 / 2.75) * n + 0.75) + x : n < 2.5 / 2.75 ? t * (7.5625 * (n -= 2.25 / 2.75) * n + 0.9375) + x : t * (7.5625 * (n -= 2.625 / 2.75) * n + 0.984375) + x;
}
function Co(n, x, t, e) {
  return n < e / 2 ? pi(n * 2, 0, t, e) * 0.5 + x : r1(n * 2 - e, 0, t, e) * 0.5 + t * 0.5 + x;
}
function S0(n, x) {
  const t = mn();
  return S0 = function(e, s) {
    return e = e - 240, t[e];
  }, S0(n, x);
}
let Eo = { easeLinear: xo, easeInQuad: eo, easeOutQuad: no, easeInOutQuad: so, easeInSine: io, easeOutSine: ro, easeInOutSine: oo, easeInExpo: ao, easeInOutExpo: co, easeInCirc: lo, easeOutCirc: ho, easeInOutCirc: fo, easeInCubic: uo, easeOutCubic: po, easeInOutCubic: bo, easeInQuart: go, easeOutQuart: _o, easeInOutQuart: yo, easeInQuint: mo, easeOutQuint: Io, easeInOutQuint: wo, easeInElastic: vo, easeOutElastic: Po, easeInOutElastic: ko, easeInBack: So, easeOutBack: Oo, easeInOutBack: Lo, easeInBounce: pi, easeOutBounce: r1, easeInOutBounce: Co };
class bi {
  constructor(x, t, e, s) {
    const i = S0;
    this.delay = 0, this.direction = i(288), this[i(274)] = "none", this[i(249)] = i(261), this[i(248)] = ![], this[i(293)] = ![], this.delayed = ![], this[i(255)] = 1, this[i(290)] = 0, this[i(302)] = i(264), this.from = x, this.to = t, this[i(305)] = e, this[i(301)] = s;
  }
  [$(285)](x, t, e, s) {
    const i = $;
    return this[i(257)] = x, this.to = t, this[i(305)] = e, this[i(301)] = s, this;
  }
  [$(259)](x) {
    const t = $;
    return this[t(257)] = x, this;
  }
  setTo(x) {
    return this.to = x, this;
  }
  [$(287)](x) {
    const t = $;
    return this[t(305)] = x, this;
  }
  onUpdate(x) {
    const t = $;
    return this[t(301)] = x, this;
  }
  [$(265)]() {
    const x = $;
    return this[x(269)] && this[x(269)][x(243)](this), this[x(240)] && (this[x(240)](), this[x(240)] = null), this[x(249)] = x(293), this;
  }
  pause() {
    const x = $;
    return this[x(249)] = x(256), this[x(248)] = !![], this;
  }
  [$(252)]() {
    const x = $;
    return this[x(294)] = Date.now() - this[x(298)], this[x(249)] = x(297), this[x(248)] = ![], this;
  }
  [$(295)](x) {
    const t = $;
    if (this[t(249)] != t(297))
      return ![];
    let e = x - this.startTime;
    return this[t(298)] = e, e >= this.duration ? (this.playState = "finished", this[t(269)].remove(this), this[t(270)](this.duration), this[t(290)] < this[t(255)] ? this.play() : (this.resolve(), this.resolve = null, this[t(296)] && this[t(296)]())) : this[t(270)](e), !![];
  }
  play() {
    const x = $;
    let t = this;
    this[x(269)].add(this), this[x(290)]++, this[x(248)] = ![], this[x(258)] != 0 && this.delayed == ![] ? (setTimeout(function() {
      const r = x;
      t[r(294)] = Date[r(289)](), t[r(249)] = "running";
    }, this[x(258)]), t.delayed = !![]) : (t[x(294)] = Date[x(289)](), t[x(249)] = x(297));
    const e = this;
    let s = this._getTickAction();
    this.stepAction = s;
    let i = this[x(280)];
    return i == null && (i = new Promise(function(r, o) {
      const a = x;
      e[a(266)] == null && (e.resolve = r, e[a(240)] = o);
    }), this[x(280)] = this[x(280)]), i[x(281)]((r) => {
    });
  }
  [$(283)]() {
    const x = $;
    let t = this[x(302)], e = this[x(257)], s = this.to, i = this.duration, r = this[x(301)], o = e, a = s;
    if (typeof e == x(273) && (o = [e], a = [s]), this[x(250)] == x(245) || this[x(250)] == x(271)) {
      let S = o;
      o = a, a = S;
    }
    let c = o[0];
    const l = Array[x(277)](e), f = typeof c == x(273), u = c.x != null || c.y != null;
    let y = o[x(247)](), m, p = Eo[t], k = this[x(250)] == x(267) || this.direction == x(271), w = this, O = this[x(305)] * 0.5;
    if (f)
      m = function(S) {
        const j = x;
        let z = S;
        k && (S > O ? z = w.duration * 2 - z * 2 : z = S * 2);
        for (let E0 = 0; E0 < o[j(278)]; E0++) {
          const H0 = o[E0], St = a[E0], it = St - H0;
          if (it == 0)
            y[E0] = H0;
          else {
            let wi = p(z, H0, it, i);
            y[E0] = wi;
          }
        }
        r(l ? y : y[0]);
      };
    else if (u)
      m = function(S) {
        for (let j = 0; j < o.length; j++) {
          const z = o[j], E0 = a[j], H0 = E0.x - z.x, St = E0.y - z.y;
          let it = { x: z.x, y: z.y };
          H0 != 0 && (it.x = p(S, z.x, H0, i)), St != 0 && (it.y = p(S, z.y, St, i)), y[j] = it;
        }
        r(l ? y : y[0]);
      };
    else
      throw new Error(x(246));
    return m;
  }
}
let Mo = 0;
class gi {
  constructor() {
    const x = $;
    this[x(254)] = [];
  }
  [$(276)](x) {
    const t = $;
    this[t(254)][t(299)](x) == -1 && this.animations.push(x);
  }
  [$(243)](x) {
    const t = $;
    Z[t(243)](this[t(254)], x);
  }
  [$(242)]() {
    const x = $;
    for (let t = 0; t < this.animations.length; t++)
      this[x(254)][t][x(265)]();
  }
  [$(295)](x) {
    const t = $;
    let e = ![];
    for (let s = 0; s < this[t(254)].length; s++)
      this[t(254)][s][t(295)](x) && e == ![] && (e = !![]);
    return this[t(254)] = this.animations[t(241)]((s) => s[t(249)] != t(293)), e;
  }
  [$(300)](x) {
    const t = $;
    x[t(305)] == null && (x[t(305)] = 1e3);
    let e = new bi(x[t(257)], x.to, x[t(305)], x[t(292)]);
    return e[t(269)] = this, e.direction = x[t(250)] || t(288), e[t(258)] = x[t(258)] || 0, e[t(284)] = x[t(284)] || t(262) + Mo++, e[t(296)] = x.onEnd, x[t(255)] != null && (e[t(255)] = x[t(255)]), x[t(302)] != null && (e.effect = x.effect), e;
  }
}
const M0 = vx;
(function(n, x) {
  const t = vx, e = n();
  for (; []; )
    try {
      if (-parseInt(t(348)) / 1 * (parseInt(t(353)) / 2) + -parseInt(t(365)) / 3 * (-parseInt(t(367)) / 4) + parseInt(t(350)) / 5 * (parseInt(t(374)) / 6) + -parseInt(t(352)) / 7 + parseInt(t(355)) / 8 * (parseInt(t(346)) / 9) + -parseInt(t(331)) / 10 * (parseInt(t(338)) / 11) + parseInt(t(336)) / 12 * (parseInt(t(337)) / 13) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(In, 534054);
function vx(n, x) {
  const t = In();
  return vx = function(e, s) {
    return e = e - 329, t[e];
  }, vx(n, x);
}
function In() {
  const n = ["780sWiSRp", "5615786aIWqnT", "merge", "_style", "css", "isDirty", "setTheme", "className", "stage", "7461wMryqy", "style", "6325tXdQIm", "defClass", "237685PvkSVA", "fromPojo", "1534218CSyYca", "276cKBpCo", "children", "1816XtOKLF", "stringify", "dirty", "getClass", "forEach", "update", "keys", "SelectArea", "flatten", "DefaultLight", "46353iuOaTt", "parse", "248MUCkNQ", "reset", "_preState", "styleClass", "_changed", "toPojo", "themeName", "30sWofCE", "Layer", "_computeLayer", "20rHdbxV", "_computeStyle", "selectedStyle", "handlerLayer", "length", "252660LHhjnA"];
  return In = function() {
    return n;
  }, In();
}
class To {
  constructor(x) {
    const t = vx;
    this[t(370)] = {}, this[t(373)] = t(364), this[t(333)] = "#009A93", this[t(345)] = x, this[t(343)](this[t(373)]);
  }
  [M0(372)]() {
    const x = M0;
    let t = JSON[x(356)](this[x(370)], (e, s) => {
      const i = x;
      if (!(e === "dirty" || e == i(369) || e == i(371)))
        return s;
    });
    return JSON[x(366)](t);
  }
  [M0(351)](x) {
    const t = M0;
    this[t(370)] = {}, Object.assign(this[t(370)], x);
  }
  [M0(349)](x, t) {
    const e = M0;
    if (t instanceof w0) {
      this.styleClass[x] = t;
      return;
    }
    let s = new w0();
    s[e(339)](t), this.styleClass[x] = s;
  }
  [M0(358)](x) {
    return this[M0(370)][x];
  }
  setTheme(x) {
    const t = M0;
    this[t(373)] = x;
    let e = dx[x];
    if (e == null)
      throw new Error("theme not exist.");
    e[t(362)] && this.stage && this[t(345)][t(334)].areaBox[t(341)](e[t(362)]);
    let s = Object[t(361)](e), i = this;
    s[t(359)]((o) => {
      i[t(349)](o, e[o]);
    }), this[t(345)][t(354)][t(359)]((o) => {
      i[t(330)](o);
    }), this[t(345)][t(360)]();
  }
  [M0(330)](x) {
    const t = M0;
    let e = dx[this.themeName], s = Object[t(361)](e), i = this;
    for (let o = 0; o < s[t(335)]; o++) {
      let a = s[o];
      a == t(329) && x[t(341)](e[a]), i[t(349)](a, e[a]);
    }
    let r = D[t(363)](x[t(354)]);
    for (let o = 0; o < r[t(335)]; o++) {
      let a = r[o];
      a.style[t(357)] = !![], i[t(332)](a);
    }
  }
  [M0(332)](x) {
    const t = M0;
    let e = this;
    if (!x[t(347)][t(342)]())
      return;
    x[t(340)][t(368)]();
    let s = e[t(358)](x[t(344)]);
    s != null && x[t(340)][t(339)](s);
    const i = x.classList;
    if (i.length > 0)
      for (let r = 0; r < i[t(335)]; r++) {
        let o = e[t(358)](i[r]);
        o != null && x[t(340)].merge(o);
      }
    x.style.updatePreState(), Object.assign(x[t(340)], x[t(347)][t(369)]), x[t(347)].dirty = ![];
  }
}
const Kt = Px;
function wn() {
  const n = ["804UpwRSh", "4481485HiIgPb", "18uIYTEu", "animationSystem", "behaviourSystem", "inputSystem", "visibilitychange", "render", "_dragDrawDelay", "isDraging", "mousedragHandler", "visible", "2979582cINhhf", "start", "_requestReapint", "destoryed", "15544kCMdic", "hidden", "_tickLayer", "tick", "21363JPcTmT", "53329nqIcbZ", "2259MvBoYP", "13929010JHCvQP", "stage", "stoped", "mode", "addEventListener", "children", "now", "requestTimer", "timeline", "renderLayer", "visibilityState", "length", "3544961RyRUgH"];
  return wn = function() {
    return n;
  }, wn();
}
function Px(n, x) {
  const t = wn();
  return Px = function(e, s) {
    return e = e - 257, t[e];
  }, Px(n, x);
}
(function(n, x) {
  const t = Px, e = n();
  for (; []; )
    try {
      if (parseInt(t(284)) / 1 * (-parseInt(t(265)) / 2) + -parseInt(t(283)) / 3 * (parseInt(t(263)) / 4) + parseInt(t(264)) / 5 + parseInt(t(275)) / 6 + parseInt(t(262)) / 7 + parseInt(t(279)) / 8 * (-parseInt(t(285)) / 9) + parseInt(t(286)) / 10 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(wn, 893243);
class Ao {
  constructor(x) {
    const t = Px;
    this[t(258)] = { currentTime: Date[t(292)]() }, this[t(287)] = x, this[t(276)](), document[t(290)](t(269), function() {
      const e = t;
      document[e(260)], e(280);
    });
  }
  [Kt(281)](x, t) {
    const e = Kt;
    let s = x[e(270)];
    if (!(x[e(274)] == ![] || x.destroyed || x[e(271)] && x[e(287)][e(268)][e(272)] || s[e(288)] || s[e(278)] == !![]) && x._paintPrepare() != ![]) {
      if (x._frames == 0) {
        x[e(277)] == !![] && (x._requestReapint = ![], s[e(259)](x));
        return;
      }
      s.renderLayer(x);
    }
  }
  pause() {
    cancelAnimationFrame(this[Kt(257)]);
  }
  [Kt(276)]() {
    const x = Kt, t = this[x(287)], e = this, s = t.handlerLayer, i = t[x(291)], r = this.timeline, o = t[x(266)], a = t[x(267)], c = this[x(287)][x(273)][x(289)] != null;
    function l() {
      const f = x;
      if (t[f(278)])
        return;
      let u = Date[f(292)]();
      r.currentTime = u, a[f(282)](u);
      let y = ![];
      !c && (y = o.tick(u)), y == !![] && (s[f(277)] = !![]), e[f(281)](s, u);
      for (let m = 0; m < i[f(261)]; m++) {
        let p = i[m];
        y && (p._requestReapint = !![]), e[f(281)](p, u);
      }
      e[f(257)] = requestAnimationFrame(l);
    }
    e.requestTimer = requestAnimationFrame(l);
  }
}
const T0 = kx;
(function(n, x) {
  const t = kx, e = n();
  for (; []; )
    try {
      if (-parseInt(t(244)) / 1 * (-parseInt(t(284)) / 2) + -parseInt(t(254)) / 3 * (parseInt(t(240)) / 4) + parseInt(t(248)) / 5 * (parseInt(t(265)) / 6) + parseInt(t(273)) / 7 + -parseInt(t(236)) / 8 + parseInt(t(271)) / 9 + -parseInt(t(239)) / 10 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(vn, 662878);
function kx(n, x) {
  const t = vn();
  return kx = function(e, s) {
    return e = e - 234, t[e];
  }, kx(n, x);
}
function vn() {
  const n = ["saveImageInfo", "195PtarpO", "click", "about:blank", "appendChild", "235945KHSTEq", "width", "context", "createEvent", "dispatchEvent", "createElement", "75wGelJV", "stage", "src", "children", "' alt='from canvas'/>", "render", "setSize", "getTime", "initMouseEvent", "_exportPaint", "download", "18syBUIf", "<img src='", "max", "jtopo_", "revokeObjectURL", "href", "11214495hiEcFO", "getAABB", "8638966aHKUaI", "translate", "write", "createObjectURL", "exportPaintObjects", "name", "saveDataAsFile", "toImage", "restore", "forEach", "MouseEvents", "4068OLzuRq", "body", "height", "2821448sOLlFC", "toFileJson", "save", "11553810usRwmv", "135592YRVMly", "http://www.w3.org/1999/xhtml", "toDataURL"];
  return vn = function() {
    return n;
  }, vn();
}
class jo {
  constructor(x) {
    const t = kx;
    this[t(255)] = x, this[t(259)] = new _n(x);
  }
  [T0(242)](x) {
    const t = T0;
    let e = Array.isArray(x) ? x : [x];
    return this[t(263)](e), this[t(259)][t(242)]();
  }
  [T0(280)](x) {
    const t = T0;
    let e = this[t(242)](x), s = new Image();
    return s[t(256)] = e, s;
  }
  saveAsLocalImage(x, t) {
    const e = T0;
    let s = this[e(242)](x);
    t == null && (t = e(268) + (/* @__PURE__ */ new Date())[e(261)]() + ".png"), this.saveDataAsFile(s, t);
  }
  [T0(243)](x) {
    const t = T0;
    let e = this[t(242)](x);
    window.open(t(246)).document[t(275)](t(266) + e + t(258));
  }
  [T0(264)](x, t = ![]) {
    const e = T0, i = this[e(255)][e(257)][0][e(237)](t), r = new File([i], x, { type: "text/json" });
    function o(a) {
      const c = e, l = document[c(253)]("a"), f = URL[c(276)](a);
      l[c(270)] = f, l[c(264)] = a[c(278)], document[c(234)][c(247)](l), l[c(245)](), document.body.removeChild(l), URL[c(269)](f);
    }
    o(r);
  }
  [T0(263)](x) {
    const t = T0;
    let e = this.render, s = null;
    x[t(282)](function(o, a) {
      let l = o[t(272)](!![], z0);
      s == null ? s = l : s = q.union(s, l);
    });
    let i = Math[t(267)](1, s[t(249)]), r = Math[t(267)](1, s[t(235)]);
    e[t(260)](i, r), e.context[t(238)](), e[t(250)][t(274)](-s.x, -s.y), x[t(282)](function(o) {
      e[t(277)]([o]);
    }), e[t(250)][t(281)]();
  }
  [T0(279)](x, t) {
    const e = T0;
    let s = document.createElementNS(e(241), "a");
    s[e(270)] = x, s.download = t;
    let i = document[e(251)](e(283));
    i[e(262)](e(245), !![], ![], window, 0, 0, 0, 0, 0, ![], ![], ![], ![], 0, null), s[e(252)](i);
  }
}
var d0 = kn;
(function(n, x) {
  for (var t = kn, e = n(); []; )
    try {
      var s = -parseInt(t(467)) / 1 + parseInt(t(457)) / 2 + parseInt(t(470)) / 3 + -parseInt(t(474)) / 4 * (-parseInt(t(451)) / 5) + -parseInt(t(466)) / 6 + parseInt(t(449)) / 7 + -parseInt(t(455)) / 8 * (parseInt(t(472)) / 9);
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Pn, 672633);
var zo = Object[d0(471)], Do = Object[d0(468)], Bo = (n, x, t, e) => {
  for (var s = e > 1 ? void 0 : e ? Do(x, t) : x, i = n.length - 1, r; i >= 0; i--)
    (r = n[i]) && (s = (e ? r(x, t, s) : r(s)) || s);
  return e && s && zo(x, t, s), s;
};
function Pn() {
  var n = ["cos", "3110622QXgnEw", "defineProperty", "1818MZhlUP", "getPoint", "1996RfAMuc", "sin", "4043403YpjpzL", "concat", "6295XZvXNO", "_radius", "Circle", "serializers", "34200DiTTib", "defineProperties", "1702970ylYdsF", "setRadius", "height", "shape", "className", "width", "prototype", "min", "radius", "1313736oxjMCd", "1339090AiXMDJ", "getOwnPropertyDescriptor"];
  return Pn = function() {
    return n;
  }, Pn();
}
function kn(n, x) {
  var t = Pn();
  return kn = function(e, s) {
    e = e - 449;
    var i = t[e];
    return i;
  }, kn(n, x);
}
class At extends E {
  constructor(x, t = 0, e = 0, s = 1, i = 1) {
    var r = d0;
    super(x, t, e, s, i), this[r(452)] = 1, this[r(460)] = R[r(453)], this._z = 2, this[r(458)](s / 2);
  }
  [d0(458)](x = 1) {
    var t = d0;
    this._radius = x, this[t(462)] = x * 2, this[t(459)] = x * 2, this.dirty = !![];
  }
  getRadius() {
    var x = d0;
    return this[x(465)];
  }
  [d0(473)](x) {
    var t = d0;
    let e = this[t(465)], s = x * (2 * Math.PI);
    return { x: this.x + e + e * Math[t(469)](s), y: this.y + e + e * Math[t(475)](s) };
  }
}
Bo([b("CircleNode")], At[d0(463)], d0(461), 2), Object[d0(456)](At[d0(463)], { radius: { get() {
  var n = d0;
  return this[n(452)] == null ? Math[n(464)](this[n(462)] * 0.5, this[n(459)] * 0.5) : this[n(452)];
}, set(n) {
  var x = d0;
  this[x(458)](n);
} } }), pt(At[d0(463)], { serializers: { value: E[d0(463)][d0(454)][d0(450)]([d0(465)]) } });
function Sn() {
  const n = ["_calcAZ", "1491740avlyAf", "getAnchorPoints", "165729hgQjZa", "centerOffset", "className", "end", "8622567ChyEoj", "resetOffset", "fold2Offset", "mergeClosestPoints", "prototype", "fold1", "absorb", "center", "serializers", "setCenterOffset", "beginOffsetGap", "646961xrQvad", "middle", "getFold2", "fold2", "assert failed getMid1AndMid2", "12APUYYV", "getMergedPoints", "getFold1Vec", "getAngle", "defineProperty", "toFixed", "mid1", "getFold2Vec", "length", "setFold2Offset", "fold1Offset", "getFold1", "endOffsetGap", "getOwnPropertyDescriptor", "looksSame", "_preAngle", "updatePoints", "1612624ohOmVI", "10099nOzETH", "8RhQlvY", "begin", "points", "abs", "concat", "getK", "setFold1Offset", "445722qRiDHz"];
  return Sn = function() {
    return n;
  }, Sn();
}
const A = On;
(function(n, x) {
  const t = On, e = n();
  for (; []; )
    try {
      if (-parseInt(t(204)) / 1 + -parseInt(t(212)) / 2 + parseInt(t(216)) / 3 + -parseInt(t(203)) / 4 + -parseInt(t(214)) / 5 + parseInt(t(236)) / 6 * (parseInt(t(231)) / 7) + parseInt(t(205)) / 8 * (parseInt(t(220)) / 9) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Sn, 263688);
function On(n, x) {
  const t = Sn();
  return On = function(e, s) {
    return e = e - 202, t[e];
  }, On(n, x);
}
var No = Object[A(240)], Ro = Object[A(249)], g1 = (n, x, t, e) => {
  for (var s = e > 1 ? void 0 : e ? Ro(x, t) : x, i = n.length - 1, r; i >= 0; i--)
    (r = n[i]) && (s = (e ? r(x, t, s) : r(s)) || s);
  return e && s && No(x, t, s), s;
};
class kt extends G {
  constructor(x, t, e, s, i) {
    const r = A;
    super(x, t, e, s, i), this[r(230)] = 15, this.endOffsetGap = 15, this[r(226)] = 3;
  }
  [A(247)](x, t) {
    const e = A;
    let s = this[e(230)], i = this[e(238)](x, t), r = { x: x.x + i[0] * s, y: x.y + i[1] * s }, o = this[e(246)];
    return o && (r.x += o.x, r.y += o.y), r;
  }
  [A(233)](x, t) {
    const e = A;
    let s = this[e(248)], i = this[e(243)](x, t), r = { x: t.x + i[0] * s, y: t.y + i[1] * s }, o = this[e(222)];
    return o && (r.x += o.x, r.y += o.y), r;
  }
  [A(238)](x, t) {
    let s = Fs(this[A(206)]);
    if (s == null) {
      let i = 0, r = 0;
      t.x > x.x ? i = 1 : i = -1, s = [i, r];
    }
    return s;
  }
  [A(243)](x, t) {
    let s = Fs(this[A(219)]);
    if (s == null) {
      let i = 0, r = -1;
      t.y > x.y ? r = -1 : r = 1, s = [i, r];
    }
    return s;
  }
  [A(202)]() {
    const x = A, t = this[x(213)](), e = t[0], s = t[1], i = this[x(226)];
    let r = this[x(238)](e, s);
    if (r[0] == 0 && Math[x(208)](e.x - s.x) < i) {
      let y = (e.x + s.x) * 0.5;
      e.x = y, s.x = y;
    }
    if (r[1] == 0 && Math.abs(e.y - s.y) < i) {
      let y = (e.y + s.y) * 0.5;
      e.y = y, s.y = y;
    }
    let o = this[x(247)](e, s), a = this.getFold2(e, s);
    const c = Ho(this, e, s, o, a);
    let l = c[0], f = c[1];
    {
      if (M[x(250)](l, f, 0.5) == ![]) {
        const p = Math[x(208)](M[x(239)](l, f))[x(241)](6);
        this[x(251)] != null && this._preAngle != p && (this[x(217)] = null), this[x(251)] = p;
      }
      let m = this[x(217)];
      m && (l.x += m.x, l.y += m.y, f.x += m.x, f.y += m.y);
    }
    let u = [e, o, l, f, a, s];
    return this[x(207)] = u, u;
  }
  [A(237)]() {
    const x = A;
    return M[x(223)](this[x(207)]);
  }
  [A(211)](x, t) {
    const e = A;
    let s = this[e(246)];
    s == null && (s = { x: 0, y: 0 }, this.fold1Offset = s), qx(this[e(210)](0, 0.5)) ? (s.y = 0, t = 0) : (s.x = 0, x = 0), s.x += x, s.y += t;
  }
  [A(245)](x, t) {
    const e = A;
    let s = this[e(222)];
    s == null && (s = { x: 0, y: 0 }, this[e(222)] = s), qx(this[e(210)](4, 0.5)) ? (s.y = 0, t = 0) : (s.x = 0, x = 0), s.x += x, s.y += t;
  }
  [A(229)](x, t) {
    const e = A;
    let s = this[e(217)];
    s == null && (s = { x: 0, y: 0 }, this[e(217)] = s), qx(this[e(210)](2, 0.5)) ? (s.x = 0, x = 0) : (s.y = 0, t = 0), s.x += x, s.y += t;
  }
  [A(221)]() {
    const x = A;
    this.centerOffset = void 0, this[x(246)] = null, this.fold2Offset = null;
  }
}
g1([b("AutoFoldLink")], kt[A(224)], A(218), 2), g1([b(G[A(224)][A(228)][A(209)](["beginOffsetGap", "endOffsetGap", A(246), A(222), "centerOffset"]))], kt[A(224)], A(228), 2);
const ot = {};
ot[L[A(206)]] = function() {
  return this[A(207)][0];
}, ot[L.fold1] = function() {
  return this[A(207)][1];
}, ot[L[A(242)]] = function() {
  return this.points[2];
}, ot[L.mid2] = function() {
  return this[A(207)][3];
}, ot[L[A(234)]] = function() {
  return this.points[4];
}, ot[L.end] = function() {
  return this.points[5];
}, ot[L[A(227)]] = function() {
  const n = A;
  return M[n(232)](this.points[2], this[n(207)][3]);
};
function Ln(n, x) {
  return Math[A(208)](x[0]) > Math.abs(x[1]) ? n.x * Math.sign(x[0]) : n.y * Math.sign(x[1]);
}
function _1(n, x, t) {
  let e = Ln(n, x);
  return Ln(t, x) - e;
}
function Ss(n, x, t, e) {
  let s = Ln(n, t), i = Ln(x, e), r = t[0] != 0;
  return s > i ? r ? { x: n.x, y: x.y } : { x: x.x, y: n.y } : r ? { x: x.x, y: n.y } : { x: n.x, y: x.y };
}
function Ho(n, x, t, e, s) {
  const i = A, r = n[i(238)](x, t), o = n[i(243)](x, t), a = F.dot(r, o);
  if (a == 1) {
    let u = Ss(e, s, r, o);
    return [u, u];
  }
  if (a == -1) {
    const u = M.middle(e, s);
    let y = Ss(e, u, r, r), m = Ss(s, u, o, o);
    return [y, m];
  }
  let c = Fe(x, e, t, s, !![]), l = _1(x, r, c), f = _1(t, o, c);
  if (l > 0 && f > 0)
    return [c, c];
  {
    const u = [-r[1], r[0]], y = { x: e.x + u[0], y: e.y + u[1] }, m = [-o[1], o[0]], p = { x: s.x + m[0], y: s.y + m[1] };
    let k = Fe(e, y, s, p, !![]);
    if (J0(k), k != null)
      return [k, k];
  }
  throw new Error(i(235));
}
pt(kt[A(224)], { DefaultPositions: { value: ot } }), kt[A(224)][A(215)] = function() {
  const n = A;
  let x = this.getMergedPoints(), t = x[n(244)];
  return t < 4 ? [n(206), n(219)] : t == 4 || t == 5 ? [n(206), n(219), n(225), n(234)] : [n(206), n(219), "fold1", n(234), n(227)];
};
const Q = Cn;
(function(n, x) {
  const t = Cn, e = n();
  for (; []; )
    try {
      if (parseInt(t(305)) / 1 + -parseInt(t(331)) / 2 * (parseInt(t(303)) / 3) + parseInt(t(324)) / 4 + parseInt(t(332)) / 5 * (-parseInt(t(313)) / 6) + parseInt(t(326)) / 7 + -parseInt(t(320)) / 8 * (-parseInt(t(322)) / 9) + -parseInt(t(329)) / 10 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(En, 254651);
var Fo = Object.defineProperty, Wo = Object[Q(310)], Os = (n, x, t, e) => {
  const s = Q;
  for (var i = e > 1 ? void 0 : e ? Wo(x, t) : x, r = n[s(304)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && Fo(x, t, i), i;
};
function Cn(n, x) {
  const t = En();
  return Cn = function(e, s) {
    return e = e - 303, t[e];
  }, Cn(n, x);
}
function En() {
  const n = ["8NDRwWM", "origin", "1345806ZWbwKr", "FlexionalLink", "732572GPfsoH", "end", "2948596Fgduda", "_calcAZ", "getFold1", "3882640jJGiDC", "begin", "77752GAPruo", "492140IPrqiM", "center", "6YUrZrn", "length", "65190RMHULN", "horizontal", "prototype", "offsetGap", "serializers", "getOwnPropertyDescriptor", "fold1", "getFold2", "6OxCAMJ", "updatePoints", "endArrow", "direction", "points", "concat", "className"];
  return En = function() {
    return n;
  }, En();
}
class wt extends G {
  constructor(x, t, e, s, i) {
    super(x, t, e, s, i);
  }
  [Q(328)](x, t) {
    const e = Q;
    let s = (t.y - x.y) / 2, i = (t.x - x.x) / 2;
    return this.direction == Nt[e(306)] ? { x: x.x + i, y: x.y } : { x: x.x, y: x.y + s };
  }
  [Q(312)](x, t) {
    const e = Q;
    let s = (t.y - x.y) / 2, i = (t.x - x.x) / 2;
    return this[e(316)] == Nt[e(306)] ? { x: t.x - i, y: t.y } : { x: t.x, y: t.y - s };
  }
  [Q(314)]() {
    const x = Q, t = this[x(327)](), e = t[0], s = t[1];
    let i = this[x(328)](e, s), r = this.getFold2(e, s), o = { x: (i.x + r.x) / 2, y: (i.y + r.y) / 2 };
    const a = [e, i, o, r, s];
    if (this[x(317)] = a, this.endArrow) {
      let c = a[x(304)] - 2;
      this[x(315)][x(321)][0] = c;
    }
    return a;
  }
}
Os([b(Q(323))], wt[Q(307)], Q(319), 2), Os([b(Nt[Q(306)])], wt.prototype, Q(316), 2), Os([b(44)], wt[Q(307)], Q(308), 2);
const Lt = {};
Lt[L[Q(330)]] = function() {
  return this[Q(317)][0];
}, Lt[L[Q(311)]] = function() {
  return this[Q(317)][1];
}, Lt[L[Q(333)]] = function() {
  return this[Q(317)][2];
}, Lt[L.fold2] = function() {
  return this.points[3];
}, Lt[L[Q(325)]] = function() {
  return this[Q(317)][4];
}, pt(wt[Q(307)], { DefaultPositions: { value: Lt }, serializers: { value: G[Q(307)][Q(309)][Q(318)]([Q(316), Q(308)]) } });
var C0 = Mn;
(function(n, x) {
  for (var t = Mn, e = n(); []; )
    try {
      var s = parseInt(t(201)) / 1 + -parseInt(t(200)) / 2 + parseInt(t(210)) / 3 + -parseInt(t(196)) / 4 + -parseInt(t(215)) / 5 + -parseInt(t(209)) / 6 * (parseInt(t(205)) / 7) + -parseInt(t(213)) / 8 * (-parseInt(t(198)) / 9);
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Tn, 124299);
var Yo = Object[C0(211)], Xo = Object[C0(193)], y1 = (n, x, t, e) => {
  for (var s = C0, i = e > 1 ? void 0 : e ? Xo(x, t) : x, r = n[s(208)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && Yo(x, t, i), i;
};
function Mn(n, x) {
  var t = Tn();
  return Mn = function(e, s) {
    e = e - 193;
    var i = t[e];
    return i;
  }, Mn(n, x);
}
class Sx extends G {
  constructor(x, t, e, s, i) {
    var r = C0;
    super(x, t, e, s, i), this[r(214)] = r(212);
  }
  [C0(195)]() {
    var x = C0;
    const t = this[x(204)](), e = t[0], s = t[1];
    let i;
    return e.x == s.x || e.y == s.y ? i = M.middle(e, s) : this[x(214)] == Nt[x(212)] ? i = { x: s.x, y: e.y } : i = { x: e.x, y: s.y }, this[x(194)] = [e, i, s], this.endArrow && (this.endArrow[x(207)][0] = 1), this[x(194)];
  }
}
function Tn() {
  var n = ["66468JTvvvL", "307188znTcgy", "defineProperty", "horizontal", "8nsRhlo", "direction", "1231955IetQwG", "getOwnPropertyDescriptor", "points", "updatePoints", "722584omhUMk", "serializers", "4292982ibpDmF", "concat", "336260jJrLSO", "195462hrqjWW", "className", "prototype", "_calcAZ", "35UnebUA", "FoldLink", "origin", "length"];
  return Tn = function() {
    return n;
  }, Tn();
}
y1([b(C0(206))], Sx[C0(203)], C0(202), 2), y1([b(G[C0(203)].serializers[C0(199)]([C0(214)]))], Sx[C0(203)], C0(197), 2);
const h0 = jn;
(function(n, x) {
  const t = jn, e = n();
  for (; []; )
    try {
      if (parseInt(t(540)) / 1 * (parseInt(t(492)) / 2) + parseInt(t(502)) / 3 + parseInt(t(491)) / 4 * (parseInt(t(537)) / 5) + -parseInt(t(531)) / 6 + parseInt(t(518)) / 7 + -parseInt(t(536)) / 8 * (parseInt(t(498)) / 9) + parseInt(t(545)) / 10 * (parseInt(t(539)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(An, 228685);
class xt {
  static [h0(497)](x, t = 1, e = 1) {
    const s = h0;
    let i = new E();
    return i[s(494)](R[s(525)](x)), i.resizeTo(t, e), i;
  }
  static getUnionRect(x) {
    const t = h0;
    let e = x[0][t(544)]();
    for (let s = 1; s < x.length; s++)
      e = q.union(e, x[s][t(544)]());
    return e;
  }
  static [h0(510)](x, t, e) {
    const s = h0;
    let i = x[s(513)];
    x.x += t, x.y += e;
    for (let r = 0; r < i[s(523)]; r++) {
      const o = i[r];
      o instanceof E && (o.x -= t, o.y -= e);
    }
  }
  static [h0(534)](x) {
    const t = h0;
    let e = x.getChildren();
    if (e[t(523)] == 0)
      return;
    let s = xt[t(508)](e);
    x.resizeTo(s.width, s.height), xt.setXYwithChildFixed(x, s.x + x[t(543)] / 2, s.y + x.height / 2);
  }
  static [h0(500)](x, t, e) {
    const s = h0;
    let i = { x: t, y: e }, r = [];
    r = r.concat(x);
    let o = xt[s(508)](r), a = o[s(517)](), c = i.x - a.x, l = i.y - a.y;
    r[s(501)]((f) => {
      f[s(519)](c, l);
    });
  }
  static [h0(503)](x, t, e, s) {
    const i = h0;
    if (s == null)
      s = [];
    else if (Z[i(520)](s, x))
      return null;
    if (t && t(x, e), s[i(547)](x), x instanceof E) {
      let o = x[i(542)];
      if (o != null)
        for (var r = 0; r < o[i(523)]; r++) {
          let a = o[r];
          xt[i(503)](a, t, x, s);
        }
    } else
      x instanceof G && x[i(509)][i(532)]() && xt[i(503)](x[i(509)][i(522)], t, e, s);
    return s;
  }
}
function An() {
  const n = ["translateWith", "hasChild", "resizeTo", "target", "length", "editable", "polygon", "segIndex", "text", "disconnect", "autoSize", "getMiddleOrigin", "2045850Ozontj", "isDisplayObjectTarget", "getBeginPoint", "sizeFitToChildren", "indexOf", "792NjhhNN", "1860sDkBKn", "inLinks", "88MTIjTm", "3hQWTje", "mouseEnabled", "outLinks", "width", "getRect", "183760xrcERV", "parent", "push", "3108nyYeNv", "10050QTrcXe", "connectable", "setShape", "removeChild", "endArrow", "createPologyNode", "32715UveEhr", "draggable", "translateObjectsCenterTo", "forEach", "1282512PGiGRr", "travel", "alignOriginToLink", "fromPoints", "getEndPoint", "label", "getUnionRect", "end", "setXYwithChildFixed", "addChild", "asLabel", "children", "Arrow", "beginArrow", "unlink", "getCenter", "356258PUzYae"];
  return An = function() {
    return n;
  }, An();
}
function jn(n, x) {
  const t = An();
  return jn = function(e, s) {
    return e = e - 491, t[e];
  }, jn(n, x);
}
class Ox {
  static [h0(528)](x, t) {
    const e = h0;
    if (x instanceof G) {
      x[e(516)]();
      return;
    }
    let s = x[e(538)];
    s != null && (s[e(501)]((r) => {
      const o = e;
      r[o(546)] != null && (t != null && t[o(535)](r) != -1 || r.setEnd(r[o(506)]()));
    }), x[e(538)] = []);
    let i = x[e(542)];
    i != null && (i.forEach((r) => {
      const o = e;
      r[o(546)] != null && (t != null && t[o(535)](r) != -1 || r.setBegin(r[o(533)]()));
    }), x[e(542)] = []);
  }
  static createLabel(x, t) {
    const e = h0;
    if (x.label == null) {
      const s = new dt(t);
      return s[e(524)] = ![], s.draggable = ![], s[e(493)] = ![], s[e(541)] = ![], s[e(529)] = !![], s[e(504)]("cb", 0, 0, 0.5), Ox.asLabel(x, s), s;
    }
    return x.label[e(527)] = t, x.label;
  }
  static [h0(512)](x, t) {
    const e = h0;
    x[e(507)] != null && x.removeChild(x[e(507)]), x[e(507)] = t, x[e(513)][e(535)](x[e(507)]) == -1 && x[e(511)](x[e(507)]);
    let s = Ox[e(530)](x);
    return t.setOrigin(s[e(526)], s.t), t;
  }
  static [h0(530)](x) {
    let t = 0, e = 0.5;
    return x instanceof Sx ? e = 1 : x instanceof wt ? t = 1 : x instanceof kt && (t = 2), { segIndex: t, t: e };
  }
  static createArrow(x, t = 10, e = 10) {
    const s = h0;
    let i = new E();
    return i[s(521)](t, e), x == null ? i.setShape(R[s(514)]) : i[s(494)](R[s(505)](x)), i[s(524)] = ![], i[s(499)] = ![], i[s(493)] = ![], i[s(541)] = ![], i;
  }
  static asBeginArrow(x, t) {
    const e = h0;
    return t[e(504)]("lm", 0, 0, 0), x[e(515)] != null && x[e(495)](x.beginArrow), x[e(513)].indexOf(t) == -1 && x[e(511)](t), x.beginArrow = t, t;
  }
  static asEndArrow(x, t) {
    const e = h0;
    let s = 1;
    x instanceof kt ? s = 5 : x instanceof Sx ? s = 2 : x instanceof wt && (s = 3);
    const i = s - 1;
    return t[e(504)]("lm", 0, i, 1), x[e(496)] != null && x.removeChild(x[e(496)]), x.children[e(535)](t) == -1 && x[e(511)](t), x[e(496)] = t, t;
  }
}
const o0 = Lx;
(function(n, x) {
  const t = Lx, e = n();
  for (; []; )
    try {
      if (-parseInt(t(232)) / 1 * (-parseInt(t(283)) / 2) + parseInt(t(276)) / 3 + -parseInt(t(233)) / 4 + -parseInt(t(231)) / 5 + -parseInt(t(239)) / 6 + parseInt(t(282)) / 7 + -parseInt(t(244)) / 8 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(zn, 330590);
function Lx(n, x) {
  const t = zn();
  return Lx = function(e, s) {
    return e = e - 222, t[e];
  }, Lx(n, x);
}
class _i {
  constructor(x, t) {
    this.objects = x, this.animationList = t;
  }
  [o0(255)]() {
    const x = o0;
    this[x(227)][x(237)]((t) => t[x(255)]()), this[x(223)][x(237)]((t, e) => {
      t[x(256)]();
    });
  }
  [o0(271)]() {
    const x = o0;
    this[x(223)].forEach((t, e) => {
      t[x(271)]();
    });
  }
}
class yi {
  constructor(x, t) {
    const e = o0;
    this[e(241)] = x, this[e(263)] = t;
  }
  [o0(264)](x, t = { x: 0, y: 0 }) {
    const e = o0;
    let s = t.x || 0, i = t.y || 0;
    return this[e(263)][e(234)]({ from: [x.x, x.y], to: [-s, -i], update: (o) => {
      x.x = o[0], x.y = o[1];
    }, effect: e(278) });
  }
  [o0(259)](x, t = {}) {
    const e = o0;
    let s = t.times || 3, i = t[e(247)] || 100;
    return this[e(263)][e(234)]({ from: [0], to: [1], update: (a) => {
      x[e(242)]({ globalAlpha: a[0] });
    }, times: s, effect: e(277), duration: i });
  }
  [o0(226)](x, t = {}) {
    const e = o0;
    let s = t[e(267)] || e(225), i = t.beginWidth || 0, r = t.beginHeight || 0, o = this.animationSystem, a = [i, r, x.x, x.y], c = [x.width, x[e(246)], x.x, x.y];
    return s == e(225) ? a = [i, r, x.x, x.y] : s == "lt" ? a = [i, r, x.x - x[e(269)] * 0.5, x.y - x[e(246)] * 0.5] : s == "rt" ? a = [i, r, x.x + x.width * 0.5, x.y - x[e(246)] * 0.5] : s == "lb" ? a = [i, r, x.x - x[e(269)] * 0.5, x.y + x[e(246)] * 0.5] : s == "rb" ? a = [i, r, x.x + x[e(269)] * 0.5, x.y + x[e(246)] * 0.5] : s == "ct" ? a = [x[e(269)], r, x.x, x.y - x[e(246)] * 0.5] : s == "cb" ? a = [x[e(246)], r, x.x, x.y + x[e(246)] * 0.5] : s == "lm" ? a = [i, x[e(246)], x.x - x[e(269)] * 0.5, x.y] : s == "rm" && (a = [i, x[e(246)], x.x + x[e(269)] * 0.5, x.y]), o[e(234)]({ from: a, to: c, update: (f) => {
      const u = e;
      x.scaleTo(f[0] / x[u(269)], f[1] / x[u(246)]), x[u(254)](f[2], f[3]);
    }, effect: e(281) });
  }
  [o0(240)](x, t = {}) {
    const e = o0;
    let s = t[e(267)] || e(225), i = t[e(248)] || 0, r = t.minHeight || 0, o = this.animationSystem, a = [x.width, x[e(246)], x.x, x.y], c = [i, r, x.x, x.y];
    return s == e(225) ? c = [i, r, x.x, x.y] : s == "lt" ? c = [i, r, x.x - x[e(269)] * 0.5, x.y - x[e(246)] * 0.5] : s == "rt" ? c = [i, r, x.x + x[e(269)] * 0.5, x.y - x[e(246)] * 0.5] : s == "lb" ? c = [i, r, x.x - x[e(269)] * 0.5, x.y + x[e(246)] * 0.5] : s == "rb" ? c = [i, r, x.x + x.width * 0.5, x.y + x[e(246)] * 0.5] : s == "ct" ? c = [i, r, x.x, x.y - x[e(246)] * 0.5] : s == "cb" ? c = [i, r, x.x, x.y + x[e(246)] * 0.5] : s == "lm" ? c = [i, r, x.x - x[e(269)] * 0.5, x.y] : s == "rm" && (c = [i, r, x.x + x.width * 0.5, x.y]), o[e(234)]({ from: a, to: c, update: (f) => {
      const u = e;
      x[u(245)](f[0] / x[u(269)], f[1] / x.height), x[u(254)](f[2], f[3]);
    }, effect: e(281) });
  }
  [o0(252)](x, t = {}) {
    const e = o0;
    let s = t.lineDash || [3, 2], i = t[e(274)] || e(222), r = i == e(222) ? 1 : -1, o = this[e(263)];
    return x[e(242)]({ lineDash: s }), o.anime({ from: [0], to: [300], update: (c) => {
      x[e(242)]({ lineDashOffset: -c[0] * r });
    }, times: 1 / 0, duration: 1e4 });
  }
  [o0(243)](x = {}) {
    const t = o0;
    let e = x[t(279)] || 50, s = x[t(230)] || "rgba(128,128,128,0.8)", i = x[t(265)] || 3, r = x.lineWidth || 8, o = this[t(263)], a = [], c = new At(null, 0, 0);
    c[t(236)] = ![], c[t(253)](e);
    for (let m = 0; m < i; m++) {
      let p = new At(null, 0, 0);
      p[t(236)] = ![], p[t(275)][t(235)] = s, p[t(253)](1), c[t(270)](p);
    }
    let l = c[t(228)], f = e / i, u = o[t(234)]({ from: [1], to: [e], update: (m) => {
      const p = t;
      let k = m[0];
      for (let w = 0; w < l[p(224)]; w++) {
        let O = l[w], S = k + w * f;
        S > e && (S = S % e);
        let j = S / e;
        O[p(253)](S), O[p(275)][p(266)] = j * r, O[p(275)].globalAlpha = 1 - j;
      }
    }, times: 1 / 0, duration: 2e3 });
    return a[t(273)](u), new _i([c], a);
  }
  [o0(262)](x, t) {
    const e = o0;
    let s = this[e(241)][e(251)][e(257)](x);
    s[e(261)] = () => {
      const i = e;
      s = ft.colorFilter(s, t), x[i(268)](s, !![]);
    };
  }
  imageFilter(x, t) {
    x.getImage((e) => {
      const s = Lx;
      if (e == null)
        return;
      let i = ft[s(262)](e, t);
      x[s(268)](i);
    });
  }
  [o0(229)](x, t = { color: o0(272) }) {
    const e = o0;
    let s = t[e(250)] || "❌️", i = new dt(s, 0, 0);
    i[e(260)] = ![], i[e(284)] = ![], i[e(249)] = ![], i[e(242)]({ textPosition: e(225), textBaseline: e(285), textAlign: "center", color: t[e(230)] || e(272) }), t.font != null && i[e(242)]({ font: t[e(238)] });
    let r = Ox.getMiddleOrigin(x);
    return i[e(258)](r[e(280)], r.t), x[e(270)](i), i;
  }
}
function zn() {
  const n = ["children", "linkMark", "color", "2883855LPrYmy", "1QHdHZa", "170408nwUbRC", "anime", "strokeStyle", "mouseEnabled", "forEach", "font", "924042hKNCMF", "unexpandScale", "stage", "css", "rippling", "57536mvkWWy", "scaleTo", "height", "duration", "minWidth", "connectable", "text", "exportSystem", "flow", "setRadius", "translateTo", "remove", "cancel", "toImage", "setOrigin", "flash", "draggable", "onload", "colorFilter", "animationSystem", "xyToCenter", "count", "lineWidth", "position", "setImage", "width", "addChild", "play", "red", "push", "direction", "style", "116754ZHMpru", "easeOutBounce", "easeInOutElastic", "radius", "segIndex", "easeOutCubic", "3598245bRHVaj", "1116418WdFZor", "editable", "middle", "clockwise", "animationList", "length", "center", "expandScale", "objects"];
  return zn = function() {
    return n;
  }, zn();
}
function Dn() {
  const n = ["argMap", "length", "update", "475215VfSFRj", "stoped", "4439160IcaNCu", "prototype", "defBehaviour", "behaviour already exist: ", "16365789RhmyON", "name", "remove", "regBehaviour", "6546zXtfFI", "567110ALoitP", "indexOf", "1947195nZuBss", "removeBehaviour", "behaviour name cannot be number:", "10uQwIBx", "set", "number", "assign", "keys", "behaviourMap", "tick", "2316WOErTK", "behaviours not exist:", "map", "12RNzGwR", "get", "push", "16dbTMKs", "first", "1504iBiUYE", "5999bFwqDv"];
  return Dn = function() {
    return n;
  }, Dn();
}
const A0 = Cx;
(function(n, x) {
  const t = Cx, e = n();
  for (; []; )
    try {
      if (-parseInt(t(377)) / 1 + parseInt(t(361)) / 2 * (parseInt(t(353)) / 3) + -parseInt(t(359)) / 4 * (parseInt(t(366)) / 5) + -parseInt(t(376)) / 6 * (parseInt(t(362)) / 7) + parseInt(t(368)) / 8 + -parseInt(t(379)) / 9 * (parseInt(t(346)) / 10) + parseInt(t(372)) / 11 * (parseInt(t(356)) / 12) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Dn, 524614);
function Cx(n, x) {
  const t = Dn();
  return Cx = function(e, s) {
    return e = e - 344, t[e];
  }, Cx(n, x);
}
class qo {
  constructor(x) {
    const t = Cx;
    this[t(355)] = /* @__PURE__ */ new Map(), this[t(363)] = /* @__PURE__ */ new WeakMap(), this[t(351)] = /* @__PURE__ */ new Map(), this[t(367)] = ![], this.stage = x;
  }
  [A0(352)](x) {
    const t = A0;
    if (this.stoped)
      return;
    let e = this[t(355)][t(350)]();
    for (let s of e)
      this.executeBehaviours(s, "update");
  }
  [A0(370)](x, t) {
    const e = A0;
    if (this[e(351)][e(357)](x) != null)
      throw new Error(e(371) + x);
    let s = new m1(x);
    return Object[e(349)](s, t), this.regBehaviour(s), s;
  }
  [A0(375)](x) {
    const t = A0;
    this.behaviourMap.set(x[t(373)], x);
  }
  addBehaviour(x, t, e) {
    const s = A0;
    let i = this[s(351)][s(357)](t);
    if (i == null)
      throw new Error(s(354) + t);
    let r = this.map.get(x);
    r == null ? (r = [], this[s(355)][s(347)](x, r), r[s(358)](i)) : r[s(378)](i) == -1 && r[s(358)](i), e != null && (r[t] = e), i[s(360)](x, e);
  }
  [A0(344)](x, t) {
    const e = A0;
    let s = this[e(355)][e(357)](x);
    if (s != null)
      for (let i = 0; i < s[e(364)]; i++) {
        let r = s[i];
        if (r[e(373)] == t) {
          Z[e(374)](s, r);
          return;
        }
      }
  }
  executeBehaviours(x, t) {
    const e = A0;
    let s = this[e(355)][e(357)](x);
    if (s != null)
      for (let i = 0; i < s[e(364)]; i++) {
        let r = s[i];
        if (t == e(365)) {
          let o = s[r[e(373)]];
          if (r.update !== m1[e(369)][e(365)] && r[e(365)](x, o) == ![])
            return ![];
        }
      }
    return null;
  }
}
class m1 {
  constructor(x) {
    const t = A0;
    if (typeof x == t(348) || !Number.isNaN(parseInt(x)))
      throw new Error(t(345) + x);
    this[t(373)] = x;
  }
  [A0(360)](x, t) {
  }
  [A0(365)](x, t) {
  }
}
function Ex(n, x) {
  const t = Bn();
  return Ex = function(e, s) {
    return e = e - 459, t[e];
  }, Ex(n, x);
}
const l0 = Ex;
(function(n, x) {
  const t = Ex, e = n();
  for (; []; )
    try {
      if (-parseInt(t(466)) / 1 + -parseInt(t(491)) / 2 * (-parseInt(t(483)) / 3) + -parseInt(t(468)) / 4 * (parseInt(t(472)) / 5) + parseInt(t(474)) / 6 * (parseInt(t(459)) / 7) + parseInt(t(464)) / 8 * (-parseInt(t(460)) / 9) + -parseInt(t(484)) / 10 * (parseInt(t(488)) / 11) + -parseInt(t(475)) / 12 * (-parseInt(t(476)) / 13) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Bn, 247498);
function Bn() {
  const n = ["flatten", "push", "51FcioLM", "10memaif", "translateWithRecursive", "getRect", "translateTo", "2323288brKIAQ", "length", "union", "51886IlPlNc", "height", "rect", "object", "1100323rcusqM", "882432ntHiCU", "children", "translateWith", "fromObject", "16bywIgb", "text", "358644YaDCTW", "join", "1695908xTneUH", "getChildrenRect", ": 	", "setObject", "5XJojBq", "concat", "6UiBDsI", "12PPfaAk", "10909639gilSuQ", "width", "parent", "getVNodeUnionRect", "addChild"];
  return Bn = function() {
    return n;
  }, Bn();
}
class jt {
  constructor(x = 0, t = 0, e = 1, s = 1) {
    const i = Ex;
    this.x = 0, this.y = 0, this.width = 1, this[i(492)] = 1, this[i(493)] = new q(0, 0, 1, 1), this[i(461)] = [], this[i(494)] = null, this.x = x, this.y = t, this[i(477)] = e, this[i(492)] = s;
  }
  [l0(463)](x) {
    const t = l0;
    this[t(494)] = x, this.x = x.x, this.y = x.y, this[t(477)] = x[t(477)], this[t(492)] = x[t(492)];
  }
  [l0(471)](x) {
    this.object = x;
  }
  [l0(486)](x = ![]) {
    const t = l0;
    return this[t(493)].setTo(this.x, this.y, this[t(477)], this[t(492)]), x ? q.union(this[t(493)], this[t(469)](!![])) : this[t(493)];
  }
  [l0(469)](x) {
    const t = l0;
    let e = this[t(461)], s = e[0].getRect(x);
    for (let i = 1; i < e.length; i++)
      s = q[t(490)](s, e[i].getRect(x));
    return s;
  }
  [l0(462)](x, t) {
    this.x += x, this.y += t;
  }
  [l0(487)](x, t) {
    this.x = x, this.y = t;
  }
  [l0(480)](x) {
    const t = l0;
    x[t(478)] = this, this[t(461)].push(x);
  }
  [l0(485)](x, t) {
    this[l0(462)](x, t);
    let s = this.children;
    for (var i = 0; i < s.length; i++)
      s[i].translateWithRecursive(x, t);
  }
  [l0(481)](x) {
    const t = l0;
    let e = [];
    for (var s = 0; s < this[t(461)][t(489)]; s++) {
      let i = this[t(461)][s];
      if ((x == null || x(i) == !![]) && (e[t(482)](i), i[t(461)] && i.children[t(489)] > 0)) {
        let r = jt[t(481)](i[t(461)], x);
        e = e[t(473)](r);
      }
    }
    return e;
  }
  toString() {
    const x = l0;
    return this.object[x(465)] + x(470) + jt[x(481)](this[x(461)]).map((e) => e.object[x(465)])[x(467)](",");
  }
  static [l0(479)](x) {
    const t = l0;
    let e = x[0][t(486)]();
    for (let s = 1; s < x[t(489)]; s++)
      e = q.union(e, x[s].getRect());
    return e;
  }
  static [l0(481)](x, t) {
    const e = l0;
    let s = [];
    for (var i = 0; i < x.length; i++) {
      let r = x[i];
      if ((t == null || t(r) == !![]) && (s[e(482)](r), r[e(461)] && r[e(461)].length > 0)) {
        let o = jt.flatten(r[e(461)], t);
        s = s[e(473)](o);
      }
    }
    return s;
  }
}
const F0 = Ft;
(function(n, x) {
  const t = Ft, e = n();
  for (; []; )
    try {
      if (-parseInt(t(282)) / 1 + -parseInt(t(300)) / 2 * (parseInt(t(276)) / 3) + -parseInt(t(299)) / 4 * (parseInt(t(291)) / 5) + -parseInt(t(271)) / 6 + parseInt(t(293)) / 7 + parseInt(t(284)) / 8 * (parseInt(t(269)) / 9) + -parseInt(t(290)) / 10 * (-parseInt(t(278)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Nn, 349816);
function Ft(n, x) {
  const t = Nn();
  return Ft = function(e, s) {
    return e = e - 269, t[e];
  }, Ft(n, x);
}
class Go {
  constructor(x) {
    const t = Ft;
    this[t(283)] = 0, this.root = x, this[t(272)] = x[t(298)](), this[t(275)] = [x][t(273)](this[t(272)]), this.allObjects = this[t(275)][t(270)]((e) => e[t(296)]), this[t(277)] = [], this[t(286)]();
  }
  [F0(286)]() {
    const x = F0;
    let t = [];
    const e = this;
    function s(i, r) {
      const o = Ft;
      e.deep < r && (e[o(283)] = r);
      let a = i[o(292)], c = t[r];
      c == null && (c = [], t[r] = c), c[o(287)](i);
      for (var l = 0; l < a[o(279)]; l++)
        s(a[l], r + 1);
    }
    s(this[x(294)], 0), this[x(277)] = t;
  }
  [F0(274)]() {
    const x = F0, t = this[x(294)][x(298)]();
    if (t[x(279)] == 0)
      throw new Error(x(285));
    let e = t[0].getRect();
    for (let s = 1; s < t[x(279)]; s++) {
      const i = t[s];
      e = q[x(281)](e, i[x(274)]());
    }
    return e;
  }
  [F0(289)](x, t) {
    const e = F0, s = this[e(275)];
    let i = this[e(294)][e(274)]();
    s.forEach((c) => {
      const l = e;
      i = q[l(281)](i, c[l(274)]());
    });
    let r = i[e(280)](), o = x - r.x, a = t - r.y;
    return s.forEach((c) => {
      c.translateWith(o, a);
    }), this;
  }
  [F0(295)](x, t) {
    const e = F0, s = this[e(275)];
    let i = this[e(294)].getRect();
    s[e(297)]((a) => {
      const c = e;
      i = q[c(281)](i, a[c(274)]());
    });
    let r = x - i.x, o = t - i.y;
    return s.forEach((a) => {
      a[e(288)](r, o);
    }), this;
  }
  [F0(288)](x, t) {
    const e = F0;
    return this[e(275)][e(297)]((i) => {
      i[e(288)](x, t);
    }), this;
  }
  getLeafs() {
    const x = F0;
    return this[x(277)][this[x(283)]];
  }
}
function Nn() {
  const n = ["2tmncLo", "85077FZRikH", "map", "2439444MJhrVS", "descendants", "concat", "getRect", "allVirtualNodes", "388758dwCqHb", "indexData", "4837382KLfadu", "length", "getCenter", "union", "513737gkiWrW", "deep", "104GfGWAJ", "getRect() in empty tree", "index", "push", "translateWith", "centerTo", "30UZTEGj", "292945gesTXd", "children", "2573627lueeqa", "root", "translateTo", "object", "forEach", "flatten", "28xDPxWa"];
  return Nn = function() {
    return n;
  }, Nn();
}
const B = Wt;
function Wt(n, x) {
  const t = Rn();
  return Wt = function(e, s) {
    return e = e - 473, t[e];
  }, Wt(n, x);
}
(function(n, x) {
  const t = Wt, e = n();
  for (; []; )
    try {
      if (parseInt(t(517)) / 1 * (-parseInt(t(511)) / 2) + parseInt(t(492)) / 3 * (parseInt(t(493)) / 4) + parseInt(t(478)) / 5 + parseInt(t(507)) / 6 + -parseInt(t(514)) / 7 * (parseInt(t(509)) / 8) + parseInt(t(504)) / 9 + -parseInt(t(508)) / 10 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Rn, 819783);
class zt {
  constructor() {
    const x = Wt;
    this[x(502)] = [], this[x(485)] = [];
  }
  [B(505)]() {
    return this.getInDegree() + this.getOutDegree();
  }
  [B(479)]() {
    const x = B;
    return this[x(502)][x(487)];
  }
  getOutDegree() {
    const x = B;
    return this.outputs[x(487)];
  }
  [B(489)]() {
    const x = B;
    let t = this[x(485)][x(518)]((s) => s.to), e = this.inputs[x(518)]((s) => s[x(483)]);
    return t[x(480)](e);
  }
}
class Gs {
  constructor(x, t) {
    const e = B;
    this.weight = 0, this[e(483)] = x, this.to = t, x[e(485)][e(499)](this), t[e(502)].push(this);
  }
  [B(476)]() {
    return this[B(483)] === this.to;
  }
  [B(516)](x) {
    const t = B;
    return this.from === x[t(483)] || this[t(483)] === x.to || this.to === x[t(483)] || this.to === x.to;
  }
}
class Uo {
  constructor(x) {
    const t = B;
    this[t(498)] = x;
  }
  [B(496)](x) {
    return ![];
  }
  [B(494)](x) {
    return ![];
  }
  [B(486)](x) {
    const t = B;
    return this[t(496)](x) && this[t(494)](x);
  }
  [B(503)](x) {
    return ![];
  }
  [B(481)](x) {
    const t = B;
    return this.isClose(x) && this[t(503)](x);
  }
}
class Mx {
  constructor(x, t) {
    const e = B;
    this.hasDirection = !![], this[e(498)] = x, this[e(497)] = t;
  }
  [B(500)]() {
    const x = B;
    return this[x(498)][x(487)] > 0 && this.edges[x(487)] == 0;
  }
  [B(490)]() {
    const x = B;
    return this[x(498)].length == 1 && this[x(497)][x(487)] == 0;
  }
  [B(513)](x, t = B(474), e = [], s = /* @__PURE__ */ new Set()) {
    const i = B;
    x == null && (x = this[i(498)][0]);
    let r = this;
    if (!s[i(491)](x) && (e.push(x), s[i(506)](x)), t == i(474))
      x[i(489)]()[i(484)]((a) => !s[i(491)](a))[i(518)]((a) => {
        const c = i;
        !s[c(491)](a) && (e[c(499)](a), s[c(506)](a)), r[c(513)](a, t, e, s);
      });
    else {
      let o = x[i(489)]()[i(484)]((a) => !s[i(491)](a));
      o[i(518)]((a) => {
        const c = i;
        e[c(499)](a), s[c(506)](a);
      }), o.map((a) => {
        r[i(513)](a, t, e, s);
      });
    }
    return e;
  }
  [B(519)]() {
    const x = B;
    let t = this[x(498)][0];
    for (let e = 1; e < this.vertexes[x(487)]; e++) {
      const s = this[x(498)][e];
      s[x(505)]() > t.getDegree() && (t = s);
    }
    return t;
  }
  getMinDegree() {
    const x = B;
    let t = this.vertexes[0].getDegree();
    for (let e = 1; e < this[x(498)][x(487)]; e++) {
      const s = this[x(498)][e];
      s[x(505)]() < t && (t = s[x(505)]());
    }
    return t;
  }
  [B(515)](x, t, e = /* @__PURE__ */ new Set()) {
    return [];
  }
  [B(475)]() {
    const x = B;
    return this.vertexes[x(487)];
  }
  [B(488)]() {
  }
  [B(477)](x) {
  }
  isTree() {
    const x = B;
    return this.vertexes[x(487)] != this.edges[x(487)] + 1 ? ![] : this[x(498)].length == 1 ? !![] : this[x(498)][x(484)]((e) => e[x(505)]() == 1)[x(487)] > 0;
  }
  [B(501)](x) {
    let t = [];
    function e(s) {
      const i = Wt;
      t.push(s);
      let r = s.outputs[i(518)]((o) => o.to);
      for (let o = 0; o < r[i(487)]; o++) {
        let a = r[o];
        if (a === x)
          return;
        e(a);
      }
    }
    return e(x), t;
  }
  [B(510)]() {
    const x = B;
    let t = this[x(498)][x(482)]();
    t[x(512)]((i) => {
      const r = x;
      i[r(502)] = i[r(502)].slice(), i.outputs = i[r(485)].slice();
    });
    let e = this[x(497)].slice(), s = new Mx(t, e);
    return s.hasDirection = this.hasDirection, s;
  }
  [B(473)]() {
    const x = B;
    let t = 0;
    this[x(498)].forEach((s) => t += s[x(505)]()), console[x(495)](t == this[x(497)][x(487)] * 2);
    let e = this[x(498)][x(484)]((s) => s.getDegree() % 2 != 0).length;
    console[x(495)](e % 2 == 0);
  }
}
function Rn() {
  const n = ["inputs", "isTrack", "11724228RSGCNC", "getDegree", "add", "6871542nwSTQY", "9466890rQfGrN", "5504urIApE", "clone", "11294FmZZuY", "forEach", "traverse", "16205EvxgOK", "getPathList", "isAdjacent", "59fJbyFL", "map", "getMaxDegreeVertext", "check", "depth", "getOrder", "isLoop", "isSubGraph", "3039510koUWSj", "getInDegree", "concat", "isCycle", "slice", "from", "filter", "outputs", "isCircuit", "length", "isBridge", "getAdjacentList", "isAlone", "has", "51GCZSCr", "149768gINRAy", "isTrace", "assert", "isClose", "edges", "vertexes", "push", "isZero", "travelNext"];
  return Rn = function() {
    return n;
  }, Rn();
}
const W0 = Tx;
(function(n, x) {
  const t = Tx, e = n();
  for (; []; )
    try {
      if (parseInt(t(349)) / 1 + -parseInt(t(363)) / 2 * (parseInt(t(384)) / 3) + -parseInt(t(380)) / 4 + parseInt(t(361)) / 5 + parseInt(t(381)) / 6 + -parseInt(t(356)) / 7 + parseInt(t(358)) / 8 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Hn, 625523);
function Hn() {
  const n = ["concat", "toGraphs", "fromObject", "begin", "push", "5634468PSYYDV", "addChild", "1814784WvQLPq", "travelVertext", "get", "3971415CtwAfn", "getInDegree", "20xPIXfV", "vertexes", "getNodes", "map", "inputs", "end", "sort", "createMinimalSpanningTree", "target", "forEach", "set", "edges", "isNodeTarget", "getOutDegree", "outputs", "has", "add", "740924pItMca", "13722WIlvRm", "from", "object", "167385RmvUML", "filter", "isTree", "1150210dCUlEP", "length"];
  return Hn = function() {
    return n;
  }, Hn();
}
function Tx(n, x) {
  const t = Hn();
  return Tx = function(e, s) {
    return e = e - 348, t[e];
  }, Tx(n, x);
}
class Yt {
  static [W0(370)](x) {
    const t = W0;
    let e = [], s = [], i = x[t(374)][t(369)]((a, c) => {
      const l = t;
      let f = a.weight - c.weight;
      return f == 0 && (f = a[l(382)].getInDegree() - c[l(382)][l(362)](), f == 0 && (f = c.to[l(376)]() - a.to[l(376)]())), f;
    }), r = /* @__PURE__ */ new WeakMap();
    for (let a = 0; a < i[t(350)]; a++) {
      const c = i[a];
      let l = c[t(382)], f = c.to, u = r[t(360)](l), y = r[t(360)](f);
      if (u != null && y != null)
        continue;
      u == null && (u = new zt(), u[t(383)] = l[t(383)], e[t(355)](u), r[t(373)](l, u)), y == null && (y = new zt(), y[t(383)] = f[t(383)], e[t(355)](y), r[t(373)](f, y));
      let m = new Gs(u, y);
      m.object = c[t(383)], s.push(m);
    }
    return new Mx(e, s);
  }
  [W0(365)](x) {
    const t = W0;
    return x.vertexes[t(366)]((e) => e[t(383)]);
  }
  getLinks(x) {
    const t = W0;
    return x[t(374)][t(366)]((e) => e.object);
  }
  objectsToGraphs(x) {
    const t = W0, e = x.filter((c) => c instanceof E);
    let s = x[t(385)]((c) => c instanceof G);
    s[t(385)]((c) => c[t(354)][t(375)]() && c[t(368)][t(375)]());
    const i = /* @__PURE__ */ new WeakMap(), r = e[t(366)]((c) => {
      const l = t, f = new zt();
      return f.object = c, i[l(373)](c, f), f;
    });
    s[t(385)]((c) => {
      const l = t;
      return i.get(c[l(354)][l(371)]) && i.get(c.end[l(371)]);
    });
    const o = s.map((c) => {
      const l = t;
      let f = i[l(360)](c[l(354)].target), u = i[l(360)](c[l(368)][l(371)]), y = new Gs(f, u);
      return y[l(383)] = c, y;
    });
    return this[t(352)](r, o);
  }
  [W0(352)](x, t) {
    const e = W0;
    let s = [];
    x.forEach((o) => {
      const a = Tx;
      let c = o[a(367)], l = o[a(377)];
      s = s.concat(c), s = s[a(351)](l);
    });
    let i = [], r = /* @__PURE__ */ new Set();
    for (let o = 0; o < x[e(350)]; o++) {
      const a = x[o];
      if (r[e(378)](a))
        continue;
      let c = [], l = [];
      this[e(359)](a, c, l, r);
      let f = new Mx(c, l);
      i[e(355)](f);
    }
    return i;
  }
  [W0(359)](x, t = [], e = [], s = /* @__PURE__ */ new Set()) {
    const i = W0;
    if (s[i(378)](x))
      return;
    t[i(355)](x), s.add(x);
    let r = x[i(367)].filter((c) => !s.has(c)), o = x.outputs.filter((c) => !s.has(c));
    r[i(372)]((c) => {
      const l = i;
      e[l(355)](c), s[l(379)](c);
    }), o[i(372)]((c) => {
      const l = i;
      e.push(c), s[l(379)](c);
    });
    let a = this;
    r.forEach((c) => {
      const l = i;
      a[l(359)](c[l(382)], t, e, s);
    }), o.forEach((c) => {
      a[i(359)](c.to, t, e, s);
    });
  }
  toTree(x) {
    const t = W0;
    !x[t(348)]() && (x = Yt[t(370)](x));
    let e = x[t(364)][t(385)]((c) => c[t(362)]() == 0)[0][t(383)], s = x[t(364)].map((c) => c[t(383)]), i = x[t(374)][t(366)]((c) => c.object);
    const r = /* @__PURE__ */ new WeakMap();
    let o = new jt();
    return o.fromObject(e), r[t(373)](e, o), s[t(372)]((c) => {
      const l = t;
      if (c === e)
        return;
      const f = new jt();
      f[l(353)](c), r[l(373)](c, f);
    }), i.forEach((c) => {
      const l = t;
      let f = r[l(360)](c.begin.target), u = r[l(360)](c[l(368)][l(371)]);
      f[l(357)](u);
    }), new Go(o);
  }
}
const $0 = Ax;
function Ax(n, x) {
  const t = Fn();
  return Ax = function(e, s) {
    return e = e - 117, t[e];
  }, Ax(n, x);
}
(function(n, x) {
  const t = Ax, e = n();
  for (; []; )
    try {
      if (parseInt(t(129)) / 1 * (-parseInt(t(132)) / 2) + parseInt(t(139)) / 3 * (parseInt(t(144)) / 4) + -parseInt(t(118)) / 5 + parseInt(t(127)) / 6 + -parseInt(t(123)) / 7 + parseInt(t(128)) / 8 + -parseInt(t(133)) / 9 * (-parseInt(t(126)) / 10) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Fn, 238898);
function Fn() {
  const n = ["map", "forEach", "scale", "height", "12HPdSsJ", "rotation", "objects", "rotate", "resizeTo", "1812740qhZhSl", "rotateNormaledPoints", "doLayout", "width", "anime", "1283023epqEPv", "positionNormals", "getPointsRect", "610OGzGSi", "768600KQYqae", "2201456YnIKvB", "1zWxGuN", "scaleY", "assign", "259158pYjFaG", "66987itDMcr", "play", "animationSystem", "scaleX", "translate", "getPointsNormalization", "57009QHhEhN"];
  return Fn = function() {
    return n;
  }, Fn();
}
class Zx {
  constructor(x, t) {
    const e = Ax;
    this.x = 0, this.y = 0, this[e(136)] = 1, this.scaleY = 1, this[e(121)] = 1, this[e(143)] = 1, this[e(145)] = 0, this.objects = x, this.positions = t, this[e(124)] = Z[e(138)](t);
    let s = Z[e(125)](t);
    this.width = s[e(121)], this[e(143)] = s.height;
  }
  [$0(117)](x, t) {
    const e = $0;
    this[e(121)] = x, this[e(143)] = t;
  }
  [$0(137)](x, t) {
    this.x = x, this.y = t;
  }
  [$0(142)](x, t) {
    const e = $0;
    this[e(136)] = x, this[e(130)] = t;
  }
  [$0(147)](x) {
    const t = $0;
    this[t(145)] = x;
  }
  [$0(120)](x) {
    const t = $0;
    let e = this, s = this[t(146)], i = this[t(124)];
    this[t(145)] != 0 && (i = Z[t(119)](this[t(124)], this[t(145)]));
    let r = (a) => {
      const c = t;
      return { x: e.x + e[c(121)] * a.x * e[c(136)], y: e.y + e.height * a.y * e.scaleY };
    };
    i = i[t(140)](r);
    function o(a) {
      a[t(141)]((l, f) => {
        s[f].setXY(l.x, l.y);
      });
    }
    if (x != null) {
      let a = s[t(140)]((l) => ({ x: l.x, y: l.y })), c = Object[t(131)]({ from: a, to: i, update: o }, x);
      this[t(135)][t(122)](c)[t(134)]();
    } else
      o(i);
    return this;
  }
}
(function(n, x) {
  const t = Wn, e = n();
  for (; []; )
    try {
      if (-parseInt(t(416)) / 1 + parseInt(t(417)) / 2 * (-parseInt(t(419)) / 3) + -parseInt(t(400)) / 4 + parseInt(t(408)) / 5 * (parseInt(t(406)) / 6) + parseInt(t(403)) / 7 + -parseInt(t(415)) / 8 * (parseInt(t(418)) / 9) + parseInt(t(405)) / 10 * (parseInt(t(411)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Yn, 273126);
function Wn(n, x) {
  const t = Yn();
  return Wn = function(e, s) {
    return e = e - 400, t[e];
  }, Wn(n, x);
}
function Zo(n) {
  const x = Wn;
  let t = n[x(414)], e = n[x(402)], s = n[x(410)](), i = 60, r = 80;
  for (let c = 0; c < s[x(404)]; c++) {
    let l = s[c], f = (c + 1) * i, u = e * r;
    l[x(409)](f, u);
  }
  for (let c = e - 1; c >= 0; c--) {
    let l = t[c];
    for (let f = 0; f < l.length; f++) {
      let u = l[f], y = u.children, m = u.x, p = c * r;
      if (y.length > 0 ? m = (y[0].x + y[y[x(404)] - 1].x) / 2 : f > 0 && (m = l[f - 1].x + l[f - 1][x(412)]), u.translateTo(m, p), f > 0 && u.x < l[f - 1].x + l[f - 1].width) {
        let k = l[f - 1].x + l[f - 1][x(412)], w = Math.abs(k - u.x);
        for (let O = f; O < l[x(404)]; O++)
          l[O].translateWithRecursive(w, 0);
      }
    }
  }
  let o = [];
  return n[x(407)][x(413)]((c) => {
    o[x(401)](c);
  }), o;
}
function Yn() {
  const n = ["64726YkAAWD", "27ALXmyf", "42hojbbZ", "911200cXFPfN", "push", "deep", "1989393dSrBxg", "length", "10luUGSU", "6RljiFn", "allVirtualNodes", "1927970jkoMIK", "translateTo", "getLeafs", "13636436QsjcCo", "width", "forEach", "indexData", "1126192AwQeZf", "533139xeBkBY"];
  return Yn = function() {
    return n;
  }, Yn();
}
const _t = Xt;
(function(n, x) {
  const t = Xt, e = n();
  for (; []; )
    try {
      if (parseInt(t(412)) / 1 * (-parseInt(t(405)) / 2) + parseInt(t(416)) / 3 * (parseInt(t(402)) / 4) + -parseInt(t(395)) / 5 + parseInt(t(410)) / 6 + -parseInt(t(415)) / 7 + -parseInt(t(397)) / 8 + parseInt(t(424)) / 9 * (parseInt(t(413)) / 10) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Xn, 913296);
function Xt(n, x) {
  const t = Xn();
  return Xt = function(e, s) {
    return e = e - 395, t[e];
  }, Xt(n, x);
}
function Xn() {
  const n = ["9lsOCdi", "object", "getAdjacentList", "update", "graph is not a tree", "startAngle", "travelTree", "circleLayout", "3437480wrxEGn", "toTree", "8727480argTLC", "filter", "points", "isTree", "createMinimalSpanningTree", "572rgzoWI", "length", "radius", "138NzRKvx", "radiusScale", "travelNext", "animationSystem", "endAngle", "10276422npwRqK", "cos", "9547EhLQoH", "12336860NyyTWD", "push", "9352840ETEKHR", "36507lhjFGv", "has", "vertexes", "map", "graphSystem", "traverse", "angleScale", "getCircleLayoutPositions"];
  return Xn = function() {
    return n;
  }, Xn();
}
class mi {
  constructor(x, t) {
    const e = Xt;
    this[e(408)] = x, this.graphSystem = t;
  }
  shapeLayout(x, t) {
    const e = Xt;
    let s = t;
    t instanceof R && (s = t[e(399)]);
    let i = new Zx(x, s);
    return i[e(408)] = this[e(408)], i;
  }
  [_t(431)](x, t = {}) {
    const e = _t;
    !x[e(400)]() && (x = Yt.createMinimalSpanningTree(x));
    let s = x[e(421)](null)[e(398)]((c) => c instanceof zt), i = s[0], r = this[e(423)](i, t), o = s[e(419)]((c) => c[e(425)]), a = new Zx(o, r);
    return a[e(408)] = this[e(408)], a;
  }
  treeLayout(x) {
    const t = _t;
    !x[t(400)]() && (x = Yt[t(401)](x));
    let e = x[t(421)](null)[t(398)]((a) => a instanceof zt), s = this[t(420)][t(396)](x), i = Zo(s), r = e[t(419)]((a) => a[t(425)]), o = new Zx(r, i);
    return o[t(408)] = this.animationSystem, o;
  }
  [_t(430)](x, t) {
    const e = _t;
    if (!x.isTree())
      throw new Error(e(428));
    return t == null && (t = x[e(418)][0]), x[e(407)](t);
  }
  [_t(423)](x, t = {}) {
    const e = _t;
    t.cx = t.cx || 0, t.cy = t.cy || 0, t[e(404)] = t[e(404)] || 200, t[e(429)] = t[e(429)] || 0, t[e(409)] = t.endAngle || 2 * Math.PI, t[e(406)] = t[e(406)] || 0.5, t[e(422)] = t.angleScale || 1, t[e(409)] > 2 * Math.PI && (t.endAngle = t[e(409)] % (2 * Math.PI));
    let s = [], i = /* @__PURE__ */ new Set(), r = [];
    function o(a, c, l, f, u, y, m) {
      const p = e;
      if (i[p(417)](a))
        return;
      r.push(a[p(425)].id), i.add(a), s[p(414)]({ x: c, y: l });
      let k = a[p(426)](), w = k[p(403)];
      if (m > 1 && (w -= 1), w <= 0)
        return;
      let O = u, S = y - u, j = S;
      S < 2 * Math.PI && (w -= 1), w != 0 && (j /= w), m > 1 && (S < 2 * Math.PI ? O -= S * 0.5 : S == 2 * Math.PI && w > 1 && w % 2 == 0 && (O += j * 0.5));
      for (let z = 0; z < k.length; z++) {
        let E0 = k[z], H0 = O + z * j, St = c + f * Math[p(411)](H0), it = l + f * Math.sin(H0);
        t.update && t[p(427)](t, x[p(425)], m), o(E0, St, it, f * t[p(406)], H0, H0 + S, m + 1);
      }
    }
    return t[e(427)] && t[e(427)](t, x[e(425)], 0), o(x, t.cx, t.cy, t[e(404)], t.startAngle, t[e(409)], 1), s;
  }
}
const g = qn;
(function(n, x) {
  const t = qn, e = n();
  for (; []; )
    try {
      if (-parseInt(t(429)) / 1 + parseInt(t(457)) / 2 + parseInt(t(415)) / 3 + -parseInt(t(468)) / 4 + parseInt(t(447)) / 5 * (parseInt(t(536)) / 6) + parseInt(t(555)) / 7 + -parseInt(t(437)) / 8 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Gn, 930605);
function qn(n, x) {
  const t = Gn();
  return qn = function(e, s) {
    return e = e - 365, t[e];
  }, qn(n, x);
}
let I1 = Date[g(428)](), w1 = ![], v1 = "localhost";
class Jo extends K0 {
  constructor(x) {
    const t = g;
    super(), this.version = Qs, this[t(423)] = [], this.visible = ![], this[t(495)] = "normal", this[t(459)] = ![], this[t(436)] = new hi(this), this[t(400)] = new n1(), this[t(381)] = new fi();
    {
      let e = t(376);
      if (e[t(409)] > 1 && location.hostname != "www.jtopo.com" && location.hostname != v1)
        return;
      this._history = e;
    }
    this._init(x), this[t(543)](), v1[t(502)](t(501)) && (this[t(391)] = new qo(this), this[t(389)] = new To(this), this[t(531)] = new gi(), this[t(387)] = new yi(this, this[t(531)]), this.graphSystem = new Yt(), this[t(368)] = new mi(this[t(531)], this[t(552)]), this[t(470)] = new Ao(this), this[t(432)] = new jo(this), this[t(532)] = new Tt(), V0[t(458)](t(369), () => this[t(380)]()));
  }
  injectCss() {
    const x = g;
    if (w1 == ![]) {
      w1 = !![];
      let t = document[x(433)] || document[x(435)](x(433))[0], e = document[x(370)]("style");
      e[x(422)] = to, t[x(401)](e);
    }
  }
  [g(544)](x) {
    const t = g;
    let e = this;
    document[t(367)] = function() {
      const r = t;
      return !e[r(400)][r(421)];
    }, e[t(527)] = ea(x);
    const s = document[t(370)](t(529));
    e[t(500)] = s, e[t(450)] = new Nr(e), Pt.isDebug && e[t(450)].show(), e.setToolbar(new li(e)), s[t(557)].add(t(412)), s[t(418)].position = t(477), s[t(418)][t(515)] = t(469), e[t(527)][t(401)](s), e[t(515)] = s.offsetWidth, e.height = s[t(460)];
    {
      const r = new Is(e);
      r.setRender(new _n(this, r)), e[t(481)] = r;
      const o = r[t(404)][t(553)];
      o[t(418)][t(443)] = "" + r[t(443)], this[t(500)].appendChild(o);
    }
    $o(e);
    let i = parseInt(t(471));
    Date[t(428)]() > i || e[t(400)][t(467)](e), e.on("dragover", function(r) {
      r[t(474)]();
    });
  }
  [g(537)]() {
    this[g(450)].show();
  }
  [g(379)]() {
    this[g(450)].hide();
  }
  [g(530)](x) {
    const t = g;
    let e = this;
    this[t(470)][t(372)][t(403)] > parseInt(t(471)) || (e.overview == null && (e[t(373)] = new $r(e)), e[t(373)][t(392)](x), e[t(373)][t(434)]());
  }
  [g(425)]() {
    const x = g;
    this[x(373)] != null && this[x(373)][x(380)]();
  }
  [g(417)]() {
    const x = g;
    this[x(373)] != null && this[x(373)].hide();
  }
  [g(456)]() {
    const x = g;
    return this[x(476)] == null ? 0 : this[x(476)][x(408)]();
  }
  [g(366)](x = 0.8) {
    return this.zoom(x, x), this;
  }
  zoomIn(x = 1.25) {
    return this[g(383)](x, x), this;
  }
  zoom(x, t, e, s) {
    const i = g;
    if (this[i(388)](j0[i(383)])) {
      let r = new Event(j0.zoom, { cancelable: !![] });
      if (this[i(385)](r), r.defaultPrevented == !![])
        return;
    }
    if (Ko(this, x, t, e, s), this[i(388)](j0[i(511)])) {
      let r = new Event(j0.zoomAfter, { cancelable: !![] });
      if (this[i(385)](r), r[i(448)] == !![])
        return;
    }
  }
  [g(393)]() {
    const x = g;
    this[x(397)]()[x(478)](function(t) {
      const e = x;
      t[e(393)](), t[e(380)]();
    });
  }
  [g(416)]() {
    ta(this);
  }
  [g(503)]() {
    const x = g;
    this[x(397)]()[x(478)](function(t) {
      t[x(453)]();
    });
  }
  [g(510)](x) {
    const t = g;
    x[t(404)] == null && x[t(394)](new _n(this, x)), x[t(443)] = this[t(423)][t(409)], x.stage = this, x.resizeTo(this.width, this[t(430)]), x[t(410)] = !![], x[t(504)] == null && (x[t(504)] = t(420) + x.zIndex), this[t(423)][t(463)](x);
    const e = x[t(404)][t(553)];
    e.style.zIndex = "" + x[t(443)], this.layersContainer[t(401)](e);
    const s = x[t(418)];
    s != null && (e[t(418)].background = s[t(411)], e[t(418)][t(512)] = s.backgroundPosition, e.style[t(384)] = s[t(384)]), this[t(389)]._computeLayer(x);
  }
  [g(397)]() {
    return this[g(423)];
  }
  removeChild(x) {
    const t = g;
    x[t(404)][t(553)].remove();
    let e = this.children[t(489)](x);
    return e == -1 ? this : (Z[t(534)](this[t(423)], e), x[t(455)] = null, this);
  }
  [g(434)]() {
    const x = g;
    this[x(449)] = !![], this[x(397)]()[x(478)](function(t) {
      t[x(434)]();
    }), this[x(496)]();
  }
  [g(486)]() {
    const x = g;
    this[x(449)] = ![], this[x(397)]()[x(478)](function(t) {
      t[x(486)]();
    });
  }
  [g(380)]() {
    const x = g;
    this[x(481)][x(380)](), this[x(397)]()[x(478)](function(t) {
      t[x(380)]();
    });
  }
  [g(496)]() {
    const x = g;
    this.handlerLayer.forceUpdate(), this[x(397)]()[x(478)](function(t) {
      t[x(496)]();
    });
  }
  [g(523)]() {
    const x = g;
    return this[x(432)][x(523)](this[x(423)]);
  }
  [g(554)]() {
    const x = g;
    return this.exportSystem.saveImageInfo(this[x(423)]);
  }
  [g(513)]() {
    const x = g;
    this.exportSystem[x(513)](this[x(423)]);
  }
  on(x, t) {
    const e = g;
    return this.on.index = I1, this[e(458)](x, t);
  }
  [g(520)]() {
    const x = g;
    if (this[x(388)](j0[x(520)])) {
      let t = new Event(j0.fullWindow, { cancelable: !![] });
      if (this[x(385)](t), t[x(448)] == !![])
        return;
    }
    Q0[x(520)](this.domElement);
  }
  [g(473)]() {
    const x = g;
    Q0[x(473)](this[x(527)]);
  }
  [g(507)]() {
    const x = g;
    if (this.toolbar == null)
      return;
    this.toolbar.show();
    let t = x(427) + this[x(456)]() + x(539);
    this.layersContainer.style[x(430)] = t;
  }
  [g(556)]() {
    const x = g;
    if (this.toolbar == null || I1 > parseInt(x(471)))
      return;
    this[x(476)][x(486)]();
    let t = x(427) + this.getToolbarHeight() + x(539);
    this.layersContainer.style[x(430)] = t;
  }
  [g(482)](x) {
    const t = g;
    this[t(476)] != null && this[t(476)].remove(), this[t(527)][t(401)](x[t(365)]());
    let e = t(427) + this[t(456)]() + t(539);
    this[t(500)].style[t(430)] = e, this[t(476)] = x;
  }
  setMode(x) {
    const t = g;
    if (this[t(388)](j0[t(548)])) {
      let e = new Event(j0[t(548)], { cancelable: !![] });
      if (e[t(495)] = x, this[t(385)](e), e.defaultPrevented == !![])
        return;
    }
    xa(this, x), x == D0[t(399)] ? this[t(541)](t(519)) : this[t(541)](t(494));
  }
  mousedownHandler(x) {
    const t = g, e = this[t(400)];
    if (this[t(495)] == D0[t(399)]) {
      this.setCursor("grabbing");
      return;
    }
    let s = this, i = s[t(439)]();
    s[t(400)][t(426)] = i;
    let r = s.mode == t(441) && i != null && (i[t(378)] == ![] || i.editable == ![]);
    if (i != null && !r) {
      Qo(s, e);
      return;
    }
    !(x[t(545)] || x[t(505)]) && s[t(381)].removeAll();
  }
  mousedragHandler(x) {
    const t = g, e = this[t(400)], s = this[t(481)], i = this[t(495)], r = this[t(400)][t(426)], o = this[t(381)], a = this[t(439)]();
    this[t(400)][t(405)] = a;
    const c = x[t(538)] == 2, l = e.isDragStart, f = r != null && r.mouseEnabled && r[t(483)], u = this[t(397)]();
    for (let y = 0; y < u[t(409)]; y++) {
      const m = u[y];
      if (m[t(378)]) {
        if (c || i == D0.drag) {
          l && this[t(541)](t(440)), m.dragHandle(e);
          continue;
        }
        if (f) {
          o.mousedragHandler(e);
          return;
        }
        i == D0[t(525)] || i == D0[t(441)] ? Vo(s, e) : m[t(508)](e);
      }
    }
  }
  [g(475)](x) {
    const t = g, e = this.inputSystem;
    let s = this;
    const i = this[t(397)](), r = e[t(492)]();
    for (let c = 0; c < i[t(409)]; c++) {
      const l = i[c];
      l[t(483)] && e.isDraging && l[t(528)]();
    }
    if (this[t(495)] == D0[t(399)]) {
      this[t(541)](t(519));
      return;
    }
    this[t(541)](t(494));
    let o = this[t(400)][t(426)], a = this[t(481)];
    a[t(452)].hide(), a[t(452)].resizeTo(0, 0), o && o.mouseEnabled && (e[t(487)] == t(509) ? o[t(475)](e) : e[t(487)] == t(526) && o[t(398)](e), e[t(499)][t(493)] && o.draggable && r == ![] && s.selectedGroup[t(444)](e));
  }
  [g(375)](x) {
    const t = g, e = this[t(400)];
    this[t(481)][t(375)](e), this.selectedGroup[t(375)](e);
  }
  clickHandler(x) {
    const t = g, e = this[t(400)];
    let s = e[t(426)];
    s && !e.previous[t(518)] && s.clickHandler(e);
  }
  [g(466)](x) {
    const t = g, e = this[t(400)];
    let s = e.pickedObject;
    s && !e[t(499)][t(518)] && s[t(466)](e);
  }
  mousemoveHandler(x) {
    const t = g;
    if (this.mode == D0[t(399)]) {
      this[t(541)](t(519));
      return;
    }
    const e = this[t(400)];
    let s = e[t(405)], i = this[t(439)]();
    s !== i && s != null && s.mouseoutHandler && s[t(375)](e), i != null && (s !== i ? i[t(497)] && i.mouseenterHandler(e) : i[t(461)] && i[t(461)](e)), e.mouseoverTarget = i;
  }
  mousewheelHandler(x) {
    const t = g, e = this[t(400)];
    if (e[t(395)] != !![])
      return;
    (x[t(445)] == null ? x[t(521)] : x.wheelDelta) > 0 ? this[t(383)](1.25, 1.25, e.x, e.y) : this[t(383)](0.8, 0.8, e.x, e.y);
  }
  [g(497)](x) {
  }
  touchstartHandler(x) {
    this[g(533)](x);
  }
  [g(424)](x) {
    this[g(451)](x);
  }
  [g(390)](x) {
  }
  [g(398)](x) {
    this.mouseupHandler(x);
  }
  [g(439)](x = ![]) {
    const t = g;
    let e = this[t(397)]();
    for (let s = e.length - 1; s >= 0; s--) {
      let i = e[s];
      if (!(i[t(449)] && i[t(378)]))
        continue;
      let r = i[t(517)](x);
      if (r != null)
        return r;
    }
    return null;
  }
  [g(371)]() {
    const x = g;
    return this[x(481)][x(404)][x(371)]();
  }
  setCursor(x) {
    const t = g;
    return this[t(481)].render[t(541)](x);
  }
  [g(546)](x, t = ![]) {
    const e = g;
    return this[e(432)][e(546)](x, t);
  }
  select(x) {
    const t = g;
    this.selectedGroup[t(465)](), this.selectedGroup[t(377)](x);
  }
  [g(491)]() {
    const x = g;
    return this[x(423)][x(516)]((t) => t[x(449)] == !![])[0];
  }
  [g(484)](x, t) {
    const e = g;
    return x == null && (x = -this.width * 0.5), t == null && (t = this[e(430)] * 0.5), Math[e(464)](Math[e(542)]() * (t - x) + x);
  }
  getAABB() {
    const x = g;
    let t = null;
    return this[x(397)]()[x(478)](function(e, s) {
      const i = x;
      let r = e[i(438)](!![]);
      t == null ? t = r : t = q[i(558)](t, r);
    }), t == null && (t = new q(0, 0, 0, 0)), t;
  }
  [g(419)](x) {
    const t = g;
    if (this[t(459)])
      throw new Error(t(535));
    this[t(459)] = !![], this[t(551)] && this[t(551)].disconnect(), this[t(382)] && clearInterval(this[t(382)]), this[t(481)][t(479)](), this.children[t(478)]((e) => {
      e[t(479)]();
    }), this.domElement[t(522)] = "", x != ![] && V0[t(549)]();
  }
}
function Vo(n, x) {
  const t = g;
  let e = n[t(455)], s = x.mouseDownX, i = x[t(472)], r = x.x, o = x.y, a = Math.min(s, r), c = Math[t(386)](i, o), l = Math[t(402)](s - r), f = Math.abs(i - o);
  const u = n.areaBox;
  u[t(434)](), u[t(442)](l, f), u[t(550)](a, c), u[t(485)](l * 0.5, f * 0.5);
  let y = new q(a, c, u[t(515)], u.height), m = n[t(455)].getChildren();
  for (var p = 0; p < m[t(409)]; p++) {
    let k = m[p];
    if (!k[t(446)]())
      continue;
    let w = k[t(454)](y), O = k[t(407)](w);
    e.selectedGroup.addAll(O);
  }
}
function Qo(n, x) {
  const t = g;
  let e = n[t(400)].pickedObject, s = x.event;
  x[t(487)] == t(396) ? e[t(533)].call(e, x) : s[t(487)] == "touchstart" && e.touchstartHandler[t(547)](e, x);
  const i = s[t(545)] || s[t(505)];
  n[t(381)][t(540)](e) ? i && n.selectedGroup.remove(e) : (!i && n.selectedGroup[t(465)](), n[t(381)][t(462)](e));
}
function P1(n, x, t) {
  const e = g;
  n[e(500)][e(418)].height = e(427) + n[e(456)]() + e(539), n[e(515)] = x, n[e(430)] = t, n[e(481)].updateSize(x, t), n[e(397)]()[e(478)](function(i) {
    i[e(413)](x, t);
  });
  let s = new Event(j0.resize);
  n[e(385)](s);
}
function Ko(n, x, t, e, s) {
  const i = g;
  (e == null || s == null) && (e = n[i(515)] / 2, s = n[i(430)] / 2), n[i(397)]()[i(478)](function(r) {
    const o = i;
    !r[o(378)] || !r[o(395)] || (r[o(383)](x, t, e, s), r[o(380)]());
  }), n[i(481)][i(380)]();
}
function $o(n) {
  const x = g, t = n[x(500)];
  if (t[x(418)][x(430)] = "calc(100% - " + n[x(456)]() + "px)", window[x(488)]) {
    const s = new ResizeObserver((i) => {
      const r = x, a = i[0][r(524)];
      ri("stage_resize", function() {
        P1(n, a[r(515)], a.height);
      }, 30);
    });
    s[x(414)](t), n[x(551)] = s;
    return;
  }
  let e = setInterval(function() {
    const s = x;
    let i = t[s(506)], r = t.offsetHeight;
    (n[s(515)] != i || n[s(430)] != r) && (t[s(418)][s(430)] = s(427) + n[s(456)]() + s(539), P1(n, i, r));
  }, 500);
  n[x(382)] = e;
}
function ta(n) {
  const x = g;
  let t = null;
  n[x(397)]()[x(478)](function(a) {
    const c = x;
    t == null ? t = a[c(438)](!![]) : t = q[c(558)](t, a[c(438)](!![]));
  });
  let e = n[x(515)] / t[x(515)], s = n[x(430)] / t.height, i = Math.min(e, s), r = 0, o = 0;
  n.zoom(i, i, r, o), n[x(503)]();
}
function xa(n, x) {
  const t = g;
  let e = n[t(495)];
  n[t(495)] = x;
  let s = { type: j0[t(548)], oldMode: e, newMode: x };
  n[t(385)](s);
}
function ea(n) {
  const x = g;
  if (typeof n == x(480) && (n = document[x(498)](n), n == null))
    throw new Error("the dom element id is not found id:" + n);
  if (n == null)
    throw new Error(x(514));
  return n[x(418)][x(490)] = x(477), n;
}
function Gn() {
  const n = ["now", "382262BnDNIP", "height", "context", "exportSystem", "head", "show", "getElementsByTagName", "keyboard", "4683560VdXCZQ", "getAABB", "pickUpViewLayers", "grabbing", "edit", "resizeTo", "zIndex", "mousedragEndHandler", "wheelDelta", "hasChildren", "1165CXHSHJ", "defaultPrevented", "visible", "debugPanel", "mousedragHandler", "areaBox", "centerBy", "toLayerRect", "stage", "getToolbarHeight", "299596EhtGST", "addEventListener", "destoryed", "clientHeight", "mousemoveHandler", "add", "push", "round", "removeAll", "dblclickHandler", "_initEvent", "5121692CxqHqF", "100%", "renderSystem", "1717171200000", "mouseDownY", "fullScreen", "preventDefault", "mouseupHandler", "toolbar", "relative", "forEach", "_destory", "string", "handlerLayer", "setToolbar", "draggable", "rand", "translateWith", "hide", "type", "ResizeObserver", "indexOf", "position", "getCurrentLayer", "isRightButton", "isDraging", "default", "mode", "forceUpdate", "mouseenterHandler", "getElementById", "previous", "layersContainer", "loca", "startsWith", "translateToCenter", "name", "metaKey", "offsetWidth", "showToolbar", "dragHandle", "mouseup", "addChild", "zoomAfter", "backgroundPosition", "saveAsLocalImage", "the dom element is null.", "width", "filter", "pickUpChild", "isDragEnd", "grab", "fullWindow", "detail", "innerHTML", "toDataURL", "contentRect", "select", "touchend", "domElement", "dragEndHandler", "div", "showOverview", "animationSystem", "serializerSystem", "mousedownHandler", "removeAt", "Stage has been destroyed already.", "41754lMYmuP", "showDebugPanel", "buttons", "px)", "has", "setCursor", "random", "injectCss", "_init", "ctrlKey", "download", "call", "modeChange", "clearCache", "translateTo", "_resizeObserver", "graphSystem", "canvas", "saveImageInfo", "8544949gPkdKS", "hideToolbar", "classList", "union", "getDom", "zoomOut", "oncontextmenu", "layoutSystem", "loaded", "createElement", "getCursor", "timeline", "overview", "getImageData", "mouseoutHandler", "#host#", "addAll", "mouseEnabled", "hideDebugPanel", "update", "selectedGroup", "_resizeTimer", "zoom", "backgroundSize", "dispatchEvent", "min", "effectSystem", "hasListener", "styleSystem", "touchwheelHandler", "behaviourSystem", "css", "cancelZoom", "setRender", "wheelZoom", "mousedown", "getChildren", "touchendHandler", "drag", "inputSystem", "appendChild", "abs", "currentTime", "render", "mouseoverTarget", "setMode", "pickUpByRect", "getHeigth", "length", "dirty", "background", "layer_container", "updateSize", "observe", "560349SjLjxK", "zoomFullStage", "hideOverview", "style", "destory", "Layer_", "isMouseOn", "textContent", "children", "touchmoveHandler", "_updateOverview", "pickedObject", "calc(100% - "];
  return Gn = function() {
    return n;
  }, Gn();
}
const U = Un;
(function(n, x) {
  const t = Un, e = n();
  for (; []; )
    try {
      if (-parseInt(t(256)) / 1 + parseInt(t(261)) / 2 * (-parseInt(t(276)) / 3) + -parseInt(t(275)) / 4 * (-parseInt(t(282)) / 5) + -parseInt(t(264)) / 6 + -parseInt(t(257)) / 7 + parseInt(t(253)) / 8 * (parseInt(t(259)) / 9) + -parseInt(t(271)) / 10 * (-parseInt(t(283)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Zn, 615459);
function Un(n, x) {
  const t = Zn();
  return Un = function(e, s) {
    return e = e - 251, t[e];
  }, Un(n, x);
}
var na = Object.defineProperty, sa = Object[U(263)], Ls = (n, x, t, e) => {
  const s = U;
  for (var i = e > 1 ? void 0 : e ? sa(x, t) : x, r = n[s(272)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && na(x, t, i), i;
};
function Zn() {
  const n = ["className", "end", "getCtrlPoint", "ctrlPoint", "20blCxoW", "95359mKIWwe", "interpolate", "translateWith", "2081440CMzTYv", "getPoints", "prototype", "757072spTRcn", "1817921NXoaHh", "resetCtrlPoint", "27aqAEjL", "_calcAZ", "4194TMtJfH", "serializers", "getOwnPropertyDescriptor", "4795434WWeXYQ", "getAnchorPoints", "updatePoints", "middle", "direction", "getPoint", "concat", "1970DXBDXg", "length", "begin", "horizontal", "1008416UOMJsf", "1524lrxEKx", "points"];
  return Zn = function() {
    return n;
  }, Zn();
}
class Dt extends G {
  constructor(x, t, e, s, i) {
    const r = U;
    super(x, t, e, s, i), this.direction = r(274);
  }
  [U(266)]() {
    const x = U;
    let t = this[x(260)](), e = t[0], s = t[1], i = this.getCtrlPoint(e, s);
    return this.points = [e, i, s], this[x(277)];
  }
  [U(252)](x, t) {
    const e = U;
    return super[e(252)](x, t), this[e(281)] != null && (this.ctrlPoint.x += x, this.ctrlPoint.y += t), this;
  }
  [U(280)](x, t) {
    const e = U;
    if (this.ctrlPoint != null)
      return this.ctrlPoint;
    let s = (x.x + t.x) / 2, i = (x.y + t.y) / 2;
    return this.direction == Nt[e(274)] ? i += (t.y - x.y) / 2 : i -= (t.y - x.y) / 2, { x: s, y: i };
  }
  [U(269)](x) {
    const t = U;
    let e = this[t(254)](), s = e[0], i = e[1], r = e[2], o = M[t(251)](s, i, x), a = M[t(251)](i, r, x);
    return M[t(251)](o, a, x);
  }
  [U(258)]() {
    const x = U;
    this[x(281)] = void 0;
  }
}
Ls([b("CurveLink")], Dt[U(255)], U(278), 2), Ls([b(R.Curve)], Dt[U(255)], "shape", 2), Ls([b(G[U(255)][U(262)][U(270)]([U(268), "ctrlPoint"]))], Dt[U(255)], "serializers", 2);
const $t = {};
$t[L.begin] = function() {
  return this.points[0];
}, $t[L[U(279)]] = function() {
  return this[U(277)][this.points.length - 1];
}, $t[L.center] = function() {
  const n = U;
  return M[n(267)](this[n(277)][0], this.points[1]);
}, $t[L[U(281)]] = function() {
  const n = U;
  return this[n(281)] != null ? this.ctrlPoint : this[n(280)](this[n(277)][0], this[n(277)][1]);
}, pt(Dt[U(255)], { DefaultPositions: { value: $t } }), Dt[U(255)][U(265)] = function() {
  const n = U;
  return [n(273), n(279), n(281)];
};
const at = qt;
(function(n, x) {
  const t = qt, e = n();
  for (; []; )
    try {
      if (-parseInt(t(305)) / 1 * (parseInt(t(283)) / 2) + parseInt(t(293)) / 3 + -parseInt(t(285)) / 4 + -parseInt(t(288)) / 5 * (parseInt(t(300)) / 6) + parseInt(t(281)) / 7 * (-parseInt(t(296)) / 8) + -parseInt(t(295)) / 9 * (-parseInt(t(284)) / 10) + parseInt(t(301)) / 11 * (parseInt(t(303)) / 12) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Jn, 661596);
function Jn() {
  const n = ["13156XTEZAp", "serializers", "27624DmsClh", "_textHeight", "1017pPmWIc", "_style", "553xcaLny", "length", "1888YMOefB", "1030EOjlBX", "4365000raratW", "width", "arrowsSize", "2296410JIQFci", "drawShape", "concat", "lineTo", "calcTextSize", "1729284bAMvhc", "height", "69057WDxqai", "95976UcPAna", "prototype", "_textWidth", "resizeTo", "6lWugAd"];
  return Jn = function() {
    return n;
  }, Jn();
}
var ia = Object.defineProperty, ra = Object.getOwnPropertyDescriptor, Cs = (n, x, t, e) => {
  const s = qt;
  for (var i = e > 1 ? void 0 : e ? ra(x, t) : x, r = n[s(282)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && ia(x, t, i), i;
};
class Jx extends dt {
  constructor(x, t = 0, e = 0, s = 1, i = 1) {
    super(x, t, e, s, i);
  }
  resizeToFitText() {
    const x = qt;
    super[x(292)]();
    let e = this[x(280)].calcGap();
    this[x(299)](this[x(298)] + e, this[x(304)] + e + this.arrowsSize);
  }
  [at(289)](x) {
    const t = at;
    let e = -this[t(286)] * 0.5, s = -this[t(294)] * 0.5, i = this[t(286)], r = this.arrowsSize, o = this[t(294)] - r, a = 0;
    x.moveTo(e, s), x[t(291)](e + i, s), x[t(291)](e + i, s + o), x[t(291)](a + (r - 2), s + o), x.lineTo(a, s + o + r), x[t(291)](a - (r - 2), s + o), x.lineTo(e, s + o), x[t(291)](e, s);
  }
}
function qt(n, x) {
  const t = Jn();
  return qt = function(e, s) {
    return e = e - 280, t[e];
  }, qt(n, x);
}
Cs([b("TipNode")], Jx[at(297)], "className", 2), Cs([b(8)], Jx.prototype, "arrowsSize", 2), Cs([b(dt[at(297)][at(302)][at(290)]([at(287)]))], Jx.prototype, at(302), 2);
var t0 = Vn;
(function(n, x) {
  for (var t = Vn, e = n(); []; )
    try {
      var s = parseInt(t(318)) / 1 * (-parseInt(t(326)) / 2) + parseInt(t(337)) / 3 + -parseInt(t(319)) / 4 + parseInt(t(301)) / 5 * (parseInt(t(324)) / 6) + parseInt(t(305)) / 7 + -parseInt(t(314)) / 8 + parseInt(t(306)) / 9;
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Qn, 692318);
function Vn(n, x) {
  var t = Qn();
  return Vn = function(e, s) {
    e = e - 298;
    var i = t[e];
    return i;
  }, Vn(n, x);
}
var oa = Object[t0(335)], aa = Object[t0(299)], ca = (n, x, t, e) => {
  for (var s = t0, i = e > 1 ? void 0 : e ? aa(x, t) : x, r = n[s(334)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && oa(x, t, i), i;
};
class Vx extends E {
  constructor(x, t = 0, e = 0, s = 1, i = 1) {
    var r = t0;
    super(), this[r(309)] = ![], this[r(304)] = !![], this.text = x, this.x = t || 0, this.y = e || 0, this.width = s || 0, this[r(321)] = i || 0;
  }
  [t0(331)]() {
    var x = t0;
    this[x(309)] = ![];
  }
  [t0(316)]() {
    var x = t0;
    this[x(309)] = !![], this[x(323)][x(316)]();
  }
  pause() {
    var x = t0;
    this[x(323)][x(329)]();
  }
  [t0(327)](x) {
    var t = t0;
    this[t(336)] = x, this.video = Q0[t(300)](x, function() {
    }), this[t(323)].width = this[t(330)], this.video[t(321)] = this.height;
  }
  onPlay(x) {
    var t = t0;
    this[t(323)][t(311)](t(316), x, ![]);
  }
  [t0(328)](x) {
    var t = t0;
    this.video[t(311)](t(329), x, ![]);
  }
  [t0(333)](x) {
    var t = t0;
    this[t(323)].addEventListener(t(325), x, ![]);
  }
  draw(x) {
    var t = t0;
    x[t(303)]();
    const e = -this[t(330)] * 0.5, s = -this[t(321)] * 0.5;
    if (x[t(315)](e, s, this[t(330)], this[t(321)]), this[t(323)] != null) {
      this[t(323)][t(330)] != this[t(330)] && (this.video[t(330)] = this[t(330)], this[t(323)].height = this.height);
      let i = this[t(309)] ? this[t(323)] : this[t(322)];
      i != null && x[t(302)](i, e, s, this[t(330)], this[t(321)]);
    } else
      x[t(308)]();
    this[t(307)](x), this[t(310)](x);
  }
}
ca([b(t0(320))], Vx[t0(317)], t0(313), 2), Object[t0(332)](Vx.prototype, { videoSrc: { get() {
  var n = t0;
  return this[n(336)];
}, set(n) {
  var x = t0;
  this[x(327)](n);
} } }), pt(Vx[t0(317)], { serializers: { value: E.prototype[t0(298)][t0(312)]([t0(309), "videoSrc"]) } });
function Qn() {
  var n = ["255500wxgTgd", "18293616SoeYfv", "mousePickupPath", "stroke", "isPlaying", "_paintText", "addEventListener", "concat", "className", "3582168VCNmQk", "rect", "play", "prototype", "1937njaGqH", "1838472PLlWGD", "VideoNode", "height", "image", "video", "6WSFnXz", "ended", "1340KdhHxd", "setVideo", "onPause", "pause", "width", "showCover", "defineProperties", "onEnded", "length", "defineProperty", "_videoSrc", "1357038qOzMHi", "serializers", "getOwnPropertyDescriptor", "createVideo", "1880135hrydwN", "drawImage", "beginPath", "dirty"];
  return Qn = function() {
    return n;
  }, Qn();
}
const e0 = $n;
function Kn() {
  const n = ["neighbors", "gravity", "frame_width", "frame_height", "calculate", "11755vIIOgf", "prototype", "initNodes", "2507094ccYsBO", "2928mzuZCP", "force", "addLink", "mass", "sqrt", "nodes", "push", "edges", "origin", "348586zVuDNa", "Error Adding Edge: ", "applyForce", "getLink", "length", "bounds", "speed", "originEdges", "repulsiveForce", "doLayout", "initialize", "addNode", "12050104VBMpZd", "2635980vgEUKA", "travel", "attractiveForce", "log", "selectedNode", "11253011LvGcbi", "setOriginEdgeWeight", "originForce", "maxForceDistance", "5150844MFHeMb"];
  return Kn = function() {
    return n;
  }, Kn();
}
(function(n, x) {
  const t = $n, e = n();
  for (; []; )
    try {
      if (-parseInt(t(154)) / 1 + parseInt(t(144)) / 2 + -parseInt(t(135)) / 3 + parseInt(t(167)) / 4 + -parseInt(t(141)) / 5 * (-parseInt(t(145)) / 6) + -parseInt(t(172)) / 7 + parseInt(t(166)) / 8 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(Kn, 892986);
var Us = function() {
};
function $n(n, x) {
  const t = Kn();
  return $n = function(e, s) {
    return e = e - 133, t[e];
  }, $n(n, x);
}
Us[e0(142)] = { calculate: function(n, x) {
  const t = e0;
  this.dx = n.x - x.x, this.dy = n.y - x.y, this.d2 = this.dx * this.dx + this.dy * this.dy, this.d = Math[t(149)](this.d2);
} };
class la {
  constructor(x, t, e) {
    const s = e0;
    this.originEdges = [], this[s(138)] = t, this[s(139)] = e, this[s(153)] = x, this.initialize(), this[s(143)](x);
  }
  [e0(143)](x) {
    const t = e0;
    let e = this;
    xt[t(168)](x, function(s, i) {
      const r = t;
      if (s.isNode && i != null) {
        let o = i, a = s;
        o == x && e[r(173)](a, e.originWeight);
        let c = a[r(148)] | 1;
        e[r(165)](a, c);
        let l = 30;
        e[r(147)](o, a, l);
      }
    });
  }
  [e0(164)]() {
    const x = e0;
    this.originWeight = 48, this.speed = 12, this[x(137)] = 50, this[x(134)] = 512, this[x(150)] = new Array(), this[x(152)] = new Array(), this[x(161)] = new Array();
  }
  [e0(133)](x, t) {
    const e = e0;
    if (this.originEdges[x.id]) {
      if (x.id != this[e(171)]) {
        let s = this[e(161)][x.id], i = (t.d - s) / s;
        x[e(146)].x += i * (t.dx / t.d), x[e(146)].y += i * (t.dy / t.d);
      }
    } else if (x.id != this[e(171)]) {
      let s = this[e(137)] * x[e(148)] * this[e(153)].mass / t.d2, i = this[e(134)] - t.d;
      i > 0 && (s *= Math.log(i)), s < 1024 && (x[e(146)].x -= s * t.dx / t.d, x[e(146)].y -= s * t.dy / t.d);
    }
  }
  [e0(169)](x, t, e) {
    const s = e0;
    let i = this[s(152)][x.id][t.id];
    if (i += 3 * (x.neighbors + t[s(136)]), i) {
      let r = (e.d - i) / i;
      x.id != this[s(171)] && (x.force.x -= r * e.dx / e.d, x[s(146)].y -= r * e.dy / e.d), t.id != this[s(171)] && (t[s(146)].x += r * e.dx / e.d, t[s(146)].y += r * e.dy / e.d);
    }
  }
  [e0(162)](x, t, e) {
    const s = e0;
    let i = this.gravity * x[s(148)] * t[s(148)] / e.d2, r = this.maxForceDistance - e.d;
    r > 0 && (i *= Math[s(170)](r)), i < 1024 && (x.force.x += i * e.dx / e.d, x[s(146)].y += i * e.dy / e.d);
  }
  [e0(163)]() {
    this[e0(156)]();
  }
  [e0(156)]() {
    const x = e0;
    for (var t = 0; t < this[x(150)][x(158)]; t++) {
      let s = this.nodes[t];
      for (var e = 0; e < this[x(150)][x(158)]; e++)
        if (t != e) {
          let r = this.nodes[e], o = new Us();
          o[x(140)](s, r), this[x(157)](s.id, r.id) != null && this[x(169)](s, r, o), t != this[x(171)] && this[x(162)](s, r, o);
        }
      let i = new Us();
      i[x(140)](this[x(153)], s), this.originForce(s, i), s[x(146)].x *= this[x(160)], s[x(146)].y *= this[x(160)], s.x += s[x(146)].x, s.y += s[x(146)].y, s[x(146)].x = 0, s[x(146)].y = 0;
    }
  }
  [e0(159)](x) {
    const t = e0;
    let e = 12, s = e * 2 + 4, i = x.x, r = x.x + s, o = x.y, a = x.y + s;
    i < 0 && (x.x = 0), o < 0 && (x.y = 0), r > this.frame_width && (x.x = this[t(138)] - s), a > this[t(139)] && (x.y = this[t(139)] - s);
  }
  [e0(173)](x, t) {
    const e = e0;
    this[e(161)][x.id] = t;
  }
  [e0(165)](x, t) {
    const e = e0;
    x[e(148)] = t | 1, x[e(136)] = x[e(136)] | 0, x[e(146)] = { x: 0, y: 0 }, this[e(150)][e(151)](x);
  }
  getLink(x, t) {
    let s = this[e0(152)][x];
    return s == null ? null : s[t];
  }
  [e0(147)](x, t, e) {
    const s = e0;
    !this[s(152)][x.id] && (this[s(152)][x.id] = new Object()), this[s(152)][x.id][t.id] = e;
    try {
      x[s(136)]++, t.neighbors++;
    } catch (i) {
      console[s(170)](s(155) + i);
    }
  }
}
const c0 = ts;
(function(n, x) {
  const t = ts, e = n();
  for (; []; )
    try {
      if (parseInt(t(129)) / 1 * (parseInt(t(120)) / 2) + -parseInt(t(146)) / 3 * (parseInt(t(121)) / 4) + parseInt(t(137)) / 5 + -parseInt(t(134)) / 6 + -parseInt(t(140)) / 7 + -parseInt(t(132)) / 8 * (parseInt(t(143)) / 9) + -parseInt(t(128)) / 10 * (-parseInt(t(127)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(xs, 781086);
var ha = Object[c0(145)], fa = Object[c0(131)], Yx = (n, x, t, e) => {
  const s = c0;
  for (var i = e > 1 ? void 0 : e ? fa(x, t) : x, r = n[s(126)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && ha(x, t, i), i;
};
function ts(n, x) {
  const t = xs();
  return ts = function(e, s) {
    return e = e - 117, t[e];
  }, ts(n, x);
}
function xs() {
  const n = ["6730661MZxZDv", "atan2", "Arc", "162XfiEHm", "serializers", "defineProperty", "519jabwao", "prototype", "updatePoints", "distancePoint", "136986rMbKqo", "13480OVabmF", "ArcLink", "clockwise", "anticlockwise", "concat", "length", "22CWrvnG", "9956740LwRRIX", "1MgQDdH", "getPoints", "getOwnPropertyDescriptor", "98040WGTeFg", "cos", "5558304uvGCIy", "className", "_calcPoint", "7063760LGGadT", "direction", "shape"];
  return xs = function() {
    return n;
  }, xs();
}
class nx extends G {
  constructor(x, t, e, s, i) {
    super(x, t, e, s, i);
  }
  getPoint(x, t = 0) {
    const e = c0;
    let s = this.getPoints(), i = s[0], r = s[s[e(126)] - 1];
    return this[e(136)](i, r, x);
  }
  [c0(136)](x, t, e) {
    const s = c0;
    let i = (x.x + t.x) / 2, r = (x.y + t.y) / 2, o = x.x - t.x, a = x.y - t.y, c = Math.sqrt(o * o + a * a) / 2, l = Math[s(141)](a, o), f = l + Math.PI * e;
    return this[s(138)] == s(124) && (f = l - Math.PI * e), { x: i + c * Math[s(133)](f), y: r + c * Math.sin(f) };
  }
  getShapeOrigin() {
    const x = c0;
    let t = this[x(130)](), e = t[0], s = t[t[x(126)] - 1];
    return { x: (e.x + s.x) * 0.5, y: (e.y + s.y) * 0.5 };
  }
  getSize() {
    const x = c0;
    let t = this.getPoints(), e = t[0], s = t[t[x(126)] - 1];
    return M[x(119)](e, s);
  }
  [c0(118)]() {
    let x = this._calcAZ(), t = x[0], e = x[1], s = this._calcPoint(t, e, 0.5);
    return [t, s, e];
  }
}
Yx([b(c0(122))], nx[c0(117)], c0(135), 2), Yx([b(R[c0(142)])], nx[c0(117)], c0(139), 2), Yx([b(G[c0(117)].serializers[c0(125)](["direction"]))], nx[c0(117)], c0(144), 2), Yx([b(c0(123))], nx[c0(117)], "direction", 2);
const Y = ns;
(function(n, x) {
  const t = ns, e = n();
  for (; []; )
    try {
      if (parseInt(t(512)) / 1 + parseInt(t(521)) / 2 + parseInt(t(515)) / 3 * (parseInt(t(502)) / 4) + parseInt(t(522)) / 5 + parseInt(t(506)) / 6 + parseInt(t(517)) / 7 + -parseInt(t(507)) / 8 * (parseInt(t(508)) / 9) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(es, 115343);
var ua = Object[Y(511)], da = Object.getOwnPropertyDescriptor, Es = (n, x, t, e) => {
  const s = Y;
  for (var i = e > 1 ? void 0 : e ? da(x, t) : x, r = n[s(519)] - 1, o; r >= 0; r--)
    (o = n[r]) && (i = (e ? o(x, t, i) : o(i)) || i);
  return e && i && ua(x, t, i), i;
};
function es() {
  const n = ["shape", "end", "center", "_calcAZ", "begin", "resetCtrlPoint", "getAnchorPoints", "className", "BezierLink", "5948cUyfeb", "concat", "calcCtrlPoint2", "atan2", "1061676gyZLZF", "8hZjgFQ", "4310973lrdaBo", "interpolate", "translateWith", "defineProperty", "17854dyLCkg", "cos", "updatePoints", "21ihjRXy", "ctrlPoint2", "1379903TJriXQ", "prototype", "length", "ctrlPoint1", "138114WjMvXm", "614725PwKTEM", "calcCtrlPoint1", "points", "serializers"];
  return es = function() {
    return n;
  }, es();
}
function ns(n, x) {
  const t = es();
  return ns = function(e, s) {
    return e = e - 493, t[e];
  }, ns(n, x);
}
class Bt extends G {
  constructor(x, t, e, s, i) {
    super(x, t, e, s, i);
  }
  translateWith(x, t) {
    const e = Y;
    return super[e(510)](x, t), this.ctrlPoint1 != null && (this[e(520)].x += x, this.ctrlPoint1.y += t), this[e(516)] != null && (this[e(516)].x += x, this[e(516)].y += t), this;
  }
  calcCtrlPoint1(x, t, e) {
    return this[Y(520)] != null ? this.ctrlPoint1 : (e == null && (e = { x: (x.x + t.x) / 2, y: (x.y + t.y) / 2 }), k1(x, e));
  }
  [Y(504)](x, t, e) {
    const s = Y;
    return this[s(516)] != null ? this[s(516)] : (e == null && (e = { x: (x.x + t.x) / 2, y: (x.y + t.y) / 2 }), k1(t, e));
  }
  [Y(498)]() {
    const x = Y;
    this[x(520)] = void 0, this[x(516)] = void 0;
  }
  getPoint(x, t) {
    const e = Y;
    let s = this.getPoints(), i = s[0], r = s[1];
    s[2];
    let o = s[3], a = s[4], c = r, l = o, f = M.interpolate(i, c, x), u = M.interpolate(c, l, x), y = M[e(509)](l, a, x), m = M[e(509)](f, u, x), p = M.interpolate(u, y, x);
    return M[e(509)](m, p, x);
  }
  [Y(514)]() {
    const x = Y, t = this[x(496)](), e = t[0], s = t[1];
    let i = { x: (e.x + s.x) / 2, y: (e.y + s.y) / 2 }, r = this[x(523)](e, s, i), o = this[x(504)](e, s, i);
    return [e, r, i, o, s];
  }
}
Es([b(Y(501))], Bt[Y(518)], Y(500), 2), Es([b(R.BezierCurve)], Bt[Y(518)], Y(493), 2), Es([b(G[Y(518)][Y(525)][Y(503)]([Y(520), Y(516)]))], Bt[Y(518)], Y(525), 2);
const Ct = {};
Ct[L[Y(497)]] = function() {
  return this[Y(524)][0];
}, Ct[L.end] = function() {
  const n = Y;
  return this.points[this[n(524)].length - 1];
}, Ct[L[Y(495)]] = function() {
  return this.getPoint(0.5, 0);
}, Ct[L[Y(520)]] = function() {
  const n = Y;
  return this[n(520)] != null ? this[n(520)] : this[n(524)][1];
}, Ct[L.ctrlPoint2] = function() {
  const n = Y;
  return this.ctrlPoint2 != null ? this.ctrlPoint2 : (this[n(524)][n(519)] - 1, this.points[3]);
}, pt(Bt[Y(518)], { DefaultPositions: { value: Ct } }), Bt.prototype[Y(499)] = function() {
  const n = Y;
  return [n(497), n(494), n(520), n(516)];
};
function k1(n, x) {
  const t = Y;
  let e = x.x - n.x, s = x.y - n.y, i = (x.x + n.x) / 2, r = (x.y + n.y) / 2, o = Math.sqrt(e * e + s * s) / 2, a = Math[t(505)](s, e) + Math.PI / 2;
  return { x: i + o * Math[t(513)](a), y: r + o * Math.sin(a) };
}
const g0 = ss;
(function(n, x) {
  const t = ss, e = n();
  for (; []; )
    try {
      if (-parseInt(t(384)) / 1 * (-parseInt(t(391)) / 2) + -parseInt(t(398)) / 3 * (parseInt(t(390)) / 4) + parseInt(t(401)) / 5 * (-parseInt(t(392)) / 6) + parseInt(t(407)) / 7 * (-parseInt(t(388)) / 8) + parseInt(t(396)) / 9 + -parseInt(t(395)) / 10 + -parseInt(t(411)) / 11 * (-parseInt(t(400)) / 12) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(is, 920737);
function ss(n, x) {
  const t = is();
  return ss = function(e, s) {
    return e = e - 383, t[e];
  }, ss(n, x);
}
function is() {
  const n = ["#2474b5", "#2bae85", "length", "14609PSwGVM", "#248067", "#EE3f4d", "#5e5314", "22puTdxd", "#7e2065", "5LFTXFZ", "#C06f98", "#C02c38", "#475164", "5432PcHkcy", "#2d2e36", "8ZooDbZ", "492970dPKQqe", "498CxchbI", "#FED71A", "#1ba784", "18052080nPhAyW", "12832101VONjzE", "#681752", "778731YGhWFo", "#12A182", "16134240BVlDBz", "41270EgYtot", "#346c9c", "#4E7ca1"];
  return is = function() {
    return n;
  }, is();
}
const S1 = [g0(387), g0(389), "#FA7E23", "#FF9900", g0(393), g0(405), g0(408), g0(399), g0(410), g0(394), "#0f1423", g0(403), g0(404), "#2775B6", g0(402), "#61649f", g0(385), g0(383), g0(397), g0(409), g0(386)];
function pa() {
  const n = g0;
  let x = Math.random() * S1[n(406)] | 0;
  return S1[x];
}
const H = jx;
(function(n, x) {
  const t = jx, e = n();
  for (; []; )
    try {
      if (-parseInt(t(285)) / 1 + -parseInt(t(289)) / 2 + parseInt(t(271)) / 3 * (parseInt(t(290)) / 4) + -parseInt(t(302)) / 5 * (-parseInt(t(300)) / 6) + parseInt(t(308)) / 7 * (-parseInt(t(274)) / 8) + parseInt(t(273)) / 9 * (parseInt(t(310)) / 10) + parseInt(t(282)) / 11 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(rs, 381927);
function jx(n, x) {
  const t = rs();
  return jx = function(e, s) {
    return e = e - 271, t[e];
  }, jx(n, x);
}
const sx = class {
  constructor() {
    const n = jx;
    this.position = { x: 0, y: 0 }, this[n(280)] = 0, this[n(311)] = 1, this.dx = 1, this.dy = 1, this.init();
  }
  [H(275)]() {
    const n = H;
    return this._position = { x: 0, y: 0 }, this[n(297)] = [], this[n(301)] = {}, this;
  }
  [H(286)](n, x) {
    const t = H;
    let e = { name: n, args: x };
    return this[t(297)][t(303)](e), this;
  }
  [H(287)](n) {
    const x = H;
    if (n == null)
      throw new Error(x(305));
    return this.marks[n] = { x: this[x(281)].x, y: this[x(281)].y }, this;
  }
  [H(272)](n) {
    return this.marks[n];
  }
  faceToMark(n) {
    const x = H;
    let t = this[x(272)](n);
    return this[x(306)](t);
  }
  [H(298)](n) {
    const x = H;
    let t = this[x(272)](n);
    return this[x(288)](t);
  }
  [H(296)](n) {
    const x = H;
    let t = this[x(272)](n);
    return this[x(276)](t);
  }
  [H(293)](n) {
    const x = H;
    for (let t = 0; t < n.length; t++) {
      const e = n[t], s = this[x(272)](e);
      this.forwardTo(s);
    }
    return this;
  }
  [H(284)]() {
    const n = H;
    let x = this[n(281)], t = this[n(307)], e = this[n(295)], s = x.x + e * Math[n(294)](t), i = x.y + e * Math[n(299)](t);
    return this.dx = s - x.x, this.dy = i - x.y, this;
  }
  faceTo(n) {
    const x = H, t = n.x, e = n.y;
    return this[x(307)] = Math[x(278)](e - this[x(281)].y, t - this._position.x), this[x(284)](), this;
  }
  forward(n) {
    const x = H;
    return this[x(277)](n), this[x(281)].x += this.dx, this[x(281)].y += this.dy, this[x(286)](sx.OP[x(292)], [this[x(281)].x, this._position.y]), this;
  }
  [H(304)](n) {
    const x = H;
    n == null && (n = 1);
    for (var t = 0; t < n; t++)
      this[x(281)].x += this.dx, this[x(281)].y += this.dy, this[x(286)](sx.OP.jump, [this[x(281)].x, this[x(281)].y]);
    return this;
  }
  [H(288)](n) {
    const x = H, t = n.x, e = n.y;
    return this[x(281)].x = t, this[x(281)].y = e, this[x(286)](sx.OP.moveTo, [this._position.x, this[x(281)].y]), this;
  }
  [H(291)](n, x) {
    const t = H;
    let e = { x: (n.x + x.x) / 2, y: (n.y + x.y) / 2 };
    return this[t(288)](e);
  }
  [H(276)](n) {
    const x = H, t = n.x, e = n.y;
    return this[x(281)].x = t, this._position.y = e, this[x(286)](sx.OP.forwardTo, [this._position.x, this[x(281)].y]), this;
  }
  [H(309)](n) {
    const x = H;
    return n == null && (n = Math.PI / 2), this[x(307)] = this._direction - n, this[x(284)](), this;
  }
  turnRight(n) {
    const x = H;
    return n == null && (n = -Math.PI / 2), this[x(307)] = this[x(307)] + n, this[x(284)](), this;
  }
  [H(277)](n) {
    const x = H;
    return this[x(295)] = n, this[x(284)](), this;
  }
  sizeBy(n) {
    return this._stepSize *= n, this.updateDxy(), this;
  }
  sizeWith(n) {
    const x = H;
    return this[x(295)] += n, this[x(284)](), this;
  }
  [H(283)](n) {
    const x = H, t = n.x, e = n.y;
    let s = t - this[x(281)].x, i = e - this[x(281)].y;
    return Math[x(279)](s * s + i * i);
  }
  getAngle(n) {
    const x = H, t = n.x, e = n.y;
    return Math[x(278)](e - this[x(281)].y, t - this[x(281)].x);
  }
};
let Ii = sx;
Ii.OP = { forward: H(292), forwardTo: H(276), moveTo: H(288), jump: "jump" };
function rs() {
  const n = ["_direction", "161ZMNROJ", "turnLeft", "80elSlRZ", "stepSize", "2454BIeLCP", "getMark", "16938SpdNos", "42536ceRAUh", "init", "forwardTo", "size", "atan2", "sqrt", "direction", "_position", "8229683rLaFmO", "getDistance", "updateDxy", "725219zEJOuE", "addAction", "mark", "moveTo", "899214eaHNPf", "1252EkWtfv", "moveToMiddle", "forward", "forwardToMarks", "cos", "_stepSize", "forwardToMark", "_actions", "moveToMark", "sin", "6mjgsNu", "marks", "3299005rJwPhq", "push", "jump", "mark's name is required.", "faceTo"];
  return rs = function() {
    return n;
  }, rs();
}
const n0 = as;
(function(n, x) {
  const t = as, e = n();
  for (; []; )
    try {
      if (-parseInt(t(168)) / 1 + -parseInt(t(139)) / 2 * (parseInt(t(162)) / 3) + parseInt(t(157)) / 4 * (parseInt(t(154)) / 5) + -parseInt(t(147)) / 6 * (parseInt(t(159)) / 7) + -parseInt(t(160)) / 8 + -parseInt(t(141)) / 9 + parseInt(t(152)) / 10 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(os, 761492);
function os() {
  const n = ["toCmds", "path", "7288etBqBa", "toPath2D", "7ZIzHND", "3220632sDmQgf", "toFunction", "6VcJkKA", "addAction", "_position", "length", "_actions", "toCmd", "34278sfbgHN", "stroke", "moveTo", "path.", "join", "push", "forwardTo", "restore", "string", `var path = new Path2D();
`, "name", "1143658bWUCQD", `
 return path;`, "1572687xGzIdU", "();", "style", "save", "applyTo's target has no method:", "text", "4609998pOESGK", "beginPath", "args", "applyTo", "fill", "30773750flyFbF", "apply", "570impizm"];
  return os = function() {
    return n;
  }, os();
}
function as(n, x) {
  const t = os();
  return as = function(e, s) {
    return e = e - 139, t[e];
  }, as(n, x);
}
var O1 = { forward: "lineTo", forwardTo: "lineTo", moveTo: "moveTo", jump: n0(170) };
class ba extends Ii {
  constructor() {
    super();
  }
  [n0(150)](x) {
    const t = n0;
    let e = this[t(166)];
    for (let s = 0; s < e[t(165)]; s++) {
      const i = e[s];
      let r = O1[i[t(178)]];
      const o = i[t(149)];
      r == null && (r = i[t(178)]);
      let a = x[r];
      if (a == null)
        throw new Error(t(145) + r);
      if (o == null) {
        a[t(153)](x, []);
        continue;
      }
      o[t(165)] ? a[t(153)](x, o) : x[r] = o;
    }
    return this;
  }
  [n0(161)]() {
    let t = this[n0(167)]();
    return new Function("ctx", t);
  }
  [n0(158)]() {
    const x = n0;
    let t = this[x(167)](x(171));
    return t = x(177) + t, t = t + x(140), new Function(x(156), t)();
  }
  [n0(167)](x) {
    const t = n0;
    return this[t(155)](x)[t(172)](`
`);
  }
  [n0(155)](x) {
    const t = n0;
    let e = this[t(166)], s = [];
    x == null && (x = "ctx.");
    for (let i = 0; i < e[t(165)]; i++) {
      const r = e[i];
      let o = O1[r[t(178)]];
      const a = r[t(149)];
      if (o == null && (o = r[t(178)]), a == null) {
        s[t(173)](x + o + t(142));
        continue;
      }
      a[t(165)] ? s[t(173)](x + o + "(" + L1(a) + ");") : s.push(x + o + "=" + L1(a) + ";");
    }
    return s;
  }
  circle(x) {
    const t = n0;
    return this[t(163)]("arc", [this[t(164)].x, this._position.y, x, 0, Math.PI * 2]), this;
  }
  [n0(143)](x, t) {
    return this.addAction(x, t), this;
  }
  [n0(146)](x) {
    const t = n0;
    return this.addAction("fillText", [x, this[t(164)].x, this._position.y]), this;
  }
  lineTo(x) {
    return this[n0(174)](x), this;
  }
  [n0(148)]() {
    return this[n0(163)]("beginPath"), this;
  }
  stroke() {
    const x = n0;
    return this[x(163)](x(169)), this;
  }
  [n0(151)]() {
    return this[n0(163)]("fill"), this;
  }
  [n0(144)]() {
    const x = n0;
    return this[x(163)](x(144)), this;
  }
  [n0(175)]() {
    const x = n0;
    return this[x(163)](x(175)), this;
  }
}
function L1(n) {
  const x = n0;
  if (!Array.isArray(n) && typeof n == x(176))
    return '"' + n + '"';
  let t = "";
  for (let e = 0; e < n[x(165)]; e++) {
    let s = n[e];
    typeof s == "string" ? t += '"' + s + '"' : t += "" + s, e + 1 < n[x(165)] && (t += ",");
  }
  return t;
}
const k0 = ls;
function cs() {
  const n = ["padding", "mousePickupPath", "prototype", "draw", "className", "right", "direction", "13203ajJlRS", "getOwnPropertyDescriptor", "fillStyle", "beginPath", "defineProperty", "height", "Unknow RatioNode's direction:", "down", "strokeAndFill", "ratio", "2351181iZdnLu", "365499dyUjLc", "347600JCZIdf", "2623206Xbjjxb", "1299856RtPENF", "_style", "52dOiVqA", "serializers", "RatioNode", "width", "rect", "58941WTmIIj", "concat", "5ocWcDT"];
  return cs = function() {
    return n;
  }, cs();
}
(function(n, x) {
  const t = ls, e = n();
  for (; []; )
    try {
      if (-parseInt(t(399)) / 1 + parseInt(t(404)) / 2 * (parseInt(t(388)) / 3) + -parseInt(t(400)) / 4 + parseInt(t(380)) / 5 * (parseInt(t(401)) / 6) + parseInt(t(398)) / 7 + -parseInt(t(402)) / 8 + -parseInt(t(378)) / 9 === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(cs, 266080);
var ga = Object[k0(392)], _a = Object[k0(389)], ya = (n, x, t, e) => {
  for (var s = e > 1 ? void 0 : e ? _a(x, t) : x, i = n.length - 1, r; i >= 0; i--)
    (r = n[i]) && (s = (e ? r(x, t, s) : r(s)) || s);
  return e && s && ga(x, t, s), s;
};
function ls(n, x) {
  const t = cs();
  return ls = function(e, s) {
    return e = e - 378, t[e];
  }, ls(n, x);
}
class Zs extends E {
  constructor(x, t = 0, e = 0, s = 1, i = 1) {
    const r = k0;
    super(x, t, e, s, i), this[r(397)] = 0.5, this[r(387)] = L[r(386)];
  }
  [k0(384)](x) {
    const t = k0;
    let e = this[t(403)], s = e[t(390)];
    e[t(390)] = null, this[t(396)](x), this[t(382)](x), e[t(390)] = s, x[t(391)](), x[t(390)] = s;
    let i = e.borderWidth || 0, r = e[t(381)] || 0, o = r * 2 + i * 2, a = -this[t(407)] * 0.5 + i + r, c = -this[t(393)] * 0.5 + i + r, l = (this[t(407)] - o) * this[t(397)], f = (this[t(393)] - o) * this[t(397)];
    if (this[t(387)] == L[t(386)])
      f = this[t(393)] - o;
    else if (this[t(387)] == L[t(395)])
      l = this[t(407)] - o;
    else if (this[t(387)] == L.left)
      a = -this.width * 0.5 + this.width - i - r - l, f = this[t(393)] - o;
    else if (this[t(387)] == L.up)
      c = -this.height * 0.5 + this[t(393)] - i - r - f, l = this[t(407)] - o;
    else
      throw new Error(t(394) + this[t(387)]);
    x[t(408)](a, c, l, f), x.fill(), this._paintText(x);
  }
}
ya([b(k0(406))], Zs[k0(383)], k0(385), 2), pt(Zs[k0(383)], { serializers: { value: E[k0(383)][k0(405)][k0(379)]([k0(397), k0(381), k0(387)]) } });
function hs() {
  const n = ["initEvent", "domElement", "hide", "744dszoeY", "appendChild", "remove", "display", "setHtml", "475012RgsJxE", "3615696TQCbZV", "3yTQEBE", "1420ipItWt", "click", "offsetWidth", "offsetHeight", "top", "height", "11641ORVBjl", "width", "add", "81027qQUSBH", "jtopo_popoupmenu", "stage", "addEventListener", "querySelectorAll", "layersContainer", "none", "style", "1005248hdzpvx", "dispatchEvent", "block", "select", "250690CjZOaY", "179990sWlBzy", "createElement", "defaultPrevented"];
  return hs = function() {
    return n;
  }, hs();
}
const tt = zx;
(function(n, x) {
  const t = zx, e = n();
  for (; []; )
    try {
      if (parseInt(t(220)) / 1 + parseInt(t(232)) / 2 * (parseInt(t(234)) / 3) + -parseInt(t(233)) / 4 + parseInt(t(221)) / 5 + parseInt(t(227)) / 6 * (-parseInt(t(241)) / 7) + -parseInt(t(216)) / 8 + parseInt(t(208)) / 9 * (parseInt(t(235)) / 10) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(hs, 566828);
function zx(n, x) {
  const t = hs();
  return zx = function(e, s) {
    return e = e - 206, t[e];
  }, zx(n, x);
}
class ma extends K0 {
  constructor(x, t) {
    const e = zx;
    super(), this[e(210)] = x, this[e(225)] = this.setHtml(t);
  }
  [tt(229)]() {
    const x = tt;
    this[x(225)] != null && this[x(225)][x(229)]();
  }
  [tt(231)](x) {
    const t = tt;
    this.html = x, this[t(229)]();
    let e = document[t(222)]("div");
    return e.classList[t(207)](t(209)), this.stage[t(213)][t(228)](e), e.innerHTML = x, this.initEvent(e), this[t(225)] = e, this[t(226)](), e;
  }
  [tt(224)](x) {
    const t = tt;
    let e = this;
    x[t(212)]("a").forEach(function(i) {
      const r = t;
      i[r(211)](r(236), function(o) {
        const a = r;
        let c = new Event(a(219), { cancelable: !![] });
        c.item = this.innerHTML, e[a(217)](c), !c[a(223)] && e[a(226)]();
      });
    });
  }
  showAt(x, t) {
    const e = tt;
    this[e(225)].style[e(230)] = e(218), t + this[e(225)][e(238)] >= this[e(210)][e(240)] && t > this[e(210)][e(240)] / 2 && (t -= this[e(225)][e(238)]), x + this.domElement.offsetWidth >= this[e(210)].width && x > this.stage[e(206)] / 2 && (x -= this[e(225)][e(237)]), this[e(225)][e(215)].left = x + "px", this[e(225)].style[e(239)] = t + "px";
  }
  [tt(226)]() {
    const x = tt;
    this.domElement[x(215)].display = x(214);
  }
}
const Y0 = Gt;
(function(n, x) {
  const t = Gt, e = n();
  for (; []; )
    try {
      if (-parseInt(t(483)) / 1 * (parseInt(t(463)) / 2) + -parseInt(t(479)) / 3 + -parseInt(t(490)) / 4 + -parseInt(t(478)) / 5 + -parseInt(t(486)) / 6 + parseInt(t(477)) / 7 * (parseInt(t(489)) / 8) + parseInt(t(474)) / 9 * (parseInt(t(488)) / 10) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(fs, 779597);
function fs() {
  const n = ["hide", "30717279MIxhmR", "remove", "0.9", "4837QtnoDa", "3459110aujheh", "4007844ZkrFHN", "jtopo_tooltip", "mousemove", "fadeOut", "761417ZtEqks", "mouseup", "createElement", "726222dXMsfg", "none", "10xQTVnH", "5744ihRzxW", "877392ZjczDc", "mouseoverTarget", "opacity", "domElement", "fadeoutTimer", "setHtml", "appendChild", "block", "style", "layersContainer", "enabled", "stopFade", "div", "top", "2HBSGYQ", "mousedown", "display", "parentNode", "stage", "inputSystem", "innerHTML", "initEvent", "classList", "left"];
  return fs = function() {
    return n;
  }, fs();
}
class Ia extends K0 {
  constructor(x) {
    const t = Gt;
    super(), this[t(467)] = x, this[t(493)] = document[t(485)](t(461)), this.domElement[t(471)].add(t(480)), this[t(467)].layersContainer[t(496)](this.domElement), this[t(470)](), this[t(473)]();
  }
  disable() {
    const x = Gt;
    this[x(493)] && this[x(493)][x(475)]();
  }
  [Y0(459)]() {
    const x = Y0;
    this[x(493)] && this.domElement[x(466)] == null && this[x(467)][x(499)].appendChild(this[x(493)]);
  }
  [Y0(495)](x) {
    const t = Y0;
    return this.domElement[t(469)] = x, this[t(493)];
  }
  [Y0(470)]() {
    const x = Y0, t = this, e = this.stage[x(468)];
    e.on(x(464), function() {
      t[x(473)]();
    }), e.on(x(484), function() {
      t[x(473)]();
    }), e.on(x(481), function() {
      const s = x;
      e[s(491)] == null && t[s(482)]();
    });
  }
  showAt(x, t) {
    const e = Y0;
    this[e(460)](), this.domElement.style.display = e(497), this[e(493)][e(498)][e(472)] = x + "px", this[e(493)][e(498)][e(462)] = t + "px", this[e(493)][e(498)][e(492)] = e(476);
  }
  hide() {
    const x = Y0;
    this[x(460)](), this[x(493)].style[x(465)] = x(487);
  }
  stopFade() {
    const x = Y0;
    this[x(494)] != null && (clearInterval(this[x(494)]), this[x(494)] = null);
  }
  [Y0(482)](x = 50) {
    const t = Y0;
    if (this[t(494)] != null)
      return;
    let e = this;
    this[t(494)] = setInterval(function() {
      const s = t;
      e[s(493)][s(498)][s(492)] -= 0.1, e[s(493)][s(498)][s(492)] <= 0.1 && e[s(473)]();
    }, x);
  }
}
function Gt(n, x) {
  const t = fs();
  return Gt = function(e, s) {
    return e = e - 459, t[e];
  }, Gt(n, x);
}
const X0 = Dx;
function us() {
  const n = ["add", "Enter", "inputSystem", "appendChild", "textarea", "1343903MHvlZK", "show", "ctrlKey", "attachTo", "value", "positionToLocalPoint", "height", "text", "block", "layersContainer", "452386wjIpAP", "none", "createElement", "onkeydown", "isLink", "stage", "313164RWuGBz", "style", "setSize", "201982elsMDg", "jtopo_input_textfield", "1352790mJlbRh", "104DTmGYw", "isNode", "hide", "top", "70WmWTBJ", "7DiZhJL", "display", "15BazXhk", "2968458UdQTnE", "metaKey", "1066980Zlonpt", "max", "width", "setValue", "pickedObject"];
  return us = function() {
    return n;
  }, us();
}
(function(n, x) {
  const t = Dx, e = n();
  for (; []; )
    try {
      if (parseInt(t(527)) / 1 + parseInt(t(494)) / 2 * (parseInt(t(504)) / 3) + -parseInt(t(507)) / 4 + -parseInt(t(496)) / 5 + parseInt(t(505)) / 6 * (-parseInt(t(502)) / 7) + -parseInt(t(497)) / 8 * (parseInt(t(491)) / 9) + -parseInt(t(501)) / 10 * (-parseInt(t(517)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(us, 328158);
function Dx(n, x) {
  const t = us();
  return Dx = function(e, s) {
    return e = e - 489, t[e];
  }, Dx(n, x);
}
class wa {
  constructor(x) {
    const t = Dx;
    this.editor = x, this[t(490)] = x[t(490)];
    let e = document[t(529)](t(516));
    e.classList[t(512)](t(495)), this[t(490)][t(526)][t(515)](e);
    let s = this;
    e.onkeydown = function(i) {
      s[t(530)](i);
    }, this[t(516)] = e;
  }
  [X0(520)](x, t) {
    const e = X0;
    let s = { x: t.x - 50, y: t.y };
    if (x[e(498)]) {
      let i = x[e(522)](L.lt);
      s = x.toStageXY(i.x, i.y);
      let r = qs(x[e(509)], 60, 100), o = qs(x[e(523)], 60, 100);
      this[e(493)](r, o);
    } else if (x[e(489)])
      return;
    this[e(510)](x.text), this.show(s.x, s.y);
  }
  setValue(x) {
    const t = X0;
    this[t(516)][t(521)] = x;
  }
  [X0(493)](x, t) {
    const e = X0;
    this.textarea.style.width = x + "px", this.textarea[e(492)][e(523)] = t + "px";
  }
  [X0(518)](x, t) {
    const e = X0;
    this.textarea.style.display = e(525), this[e(516)].focus(), x != null && (x = Math[e(508)](0, x), t = Math[e(508)](0, t), this[e(516)][e(492)].left = x, this[e(516)][e(492)][e(500)] = t);
  }
  [X0(499)]() {
    const x = X0;
    this[x(516)][x(492)][x(503)] = x(528);
  }
  [X0(530)](x) {
    const t = X0;
    let e = this.textarea;
    if (x.key == t(513) && (x[t(519)] || x[t(506)])) {
      let s = this[t(490)][t(514)][t(511)];
      if (s == null)
        return;
      s[t(524)] = e[t(521)], e[t(492)].display = t(528), this[t(499)]();
    }
  }
}
(function(n, x) {
  for (var t = Js, e = n(); []; )
    try {
      var s = -parseInt(t(134)) / 1 * (parseInt(t(132)) / 2) + -parseInt(t(135)) / 3 + -parseInt(t(138)) / 4 + parseInt(t(131)) / 5 + parseInt(t(136)) / 6 + parseInt(t(137)) / 7 + -parseInt(t(130)) / 8 * (-parseInt(t(133)) / 9);
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(ds, 308898);
function ds() {
  var n = ["1602972iivbIY", "1aJxglj", "1087302ufQLeh", "1528002EFLDaX", "1777615LnsqqL", "1653460YZwRXb", "24vIMizW", "586890yEEKLN", "151234sRhKVr"];
  return ds = function() {
    return n;
  }, ds();
}
function Js(n, x) {
  var t = ds();
  return Js = function(e, s) {
    e = e - 130;
    var i = t[e];
    return i;
  }, Js(n, x);
}
(function(n, x) {
  for (var t = Vs, e = n(); []; )
    try {
      var s = parseInt(t(432)) / 1 + parseInt(t(428)) / 2 + -parseInt(t(424)) / 3 + -parseInt(t(425)) / 4 * (parseInt(t(426)) / 5) + -parseInt(t(429)) / 6 + -parseInt(t(433)) / 7 * (parseInt(t(430)) / 8) + -parseInt(t(431)) / 9 * (-parseInt(t(427)) / 10);
      if (s === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(ps, 856771);
function ps() {
  var n = ["4386123AQeUUz", "92VQUPdw", "185975twvgpP", "32810760XGpcfF", "2241884UNlKzd", "9982710konXzv", "152LcHbIk", "9VVZYda", "1691907YqHTuw", "462679VzeIdZ"];
  return ps = function() {
    return n;
  }, ps();
}
function Vs(n, x) {
  var t = ps();
  return Vs = function(e, s) {
    e = e - 424;
    var i = t[e];
    return i;
  }, Vs(n, x);
}
const va = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AENode: _i,
  Animation: bi,
  AnimationSystem: gi,
  ArcLink: nx,
  ArcShape: Ns,
  ArrowShape: tx,
  AutoFoldLink: kt,
  BezierCurveShape: Bs,
  BezierLink: Bt,
  CircleNode: At,
  CircleShape: As,
  Collection: Z,
  Config: A1,
  CoordinateSystem: s1,
  Cursor: Ci,
  CurveLink: Dt,
  CurveShape: Ds,
  Debug: Pt,
  DefaultZIndexs: Bx,
  Direction: Nt,
  DisplayObject: D,
  DomUtil: Q0,
  Edge: Gs,
  EffectSystem: yi,
  EllipseShape: js,
  Endpoint: nt,
  EndpointFixedName: N0,
  EndpointFixedPoint: Z0,
  EndpointFunction: Nx,
  EndpointNearest: vt,
  EndpointSegment: ht,
  EventNames: j0,
  EventTarget: K0,
  FlexionalLink: wt,
  FoldLink: Sx,
  FontInfo: yt,
  FontUtil: Ws,
  ForceDirectLayout: la,
  GeometricCoordinateSystem: ui,
  Graph: Mx,
  GraphSystem: Yt,
  HandlerLayer: Is,
  HtmlImage: si,
  ImageUtil: ft,
  InputEvent: v0,
  InputSystem: n1,
  InputTextfield: wa,
  Intersect: ms,
  Keyboard: hi,
  Layer: ut,
  LayerLocalDeep: z0,
  LayoutBase: Zx,
  LayoutSystem: mi,
  LineShape: zs,
  LinearGradient: sr,
  Link: G,
  LinkCoordinateSystem: di,
  LinkHelper: Ox,
  Node: E,
  NodeHelper: xt,
  OBB: Mt,
  PI2: rx,
  Path: Uo,
  Pattern: or,
  Point: M,
  PopupMenu: ma,
  Position: L,
  PositionInvertMap: Ei,
  RadialGradient: ir,
  RatioNode: Zs,
  RectDefaultPositions: lt,
  RectShape: Xx,
  Rectangle: q,
  ResourceLoader: V0,
  SelectedGroup: fi,
  SerializerSystem: Tt,
  Shape: R,
  Stage: Jo,
  StageLocalDeep: z1,
  StageMode: D0,
  Style: w0,
  TextNode: dt,
  Theme: dx,
  TipNode: Jx,
  Toolbar: li,
  Tooltip: Ia,
  TopoEvent: H1,
  TopoPainter: ba,
  Transform: _s,
  VERSION: Qs,
  Vertext: zt,
  VideoNode: Vx,
  assertEquals: Mi,
  assertNotNull: J0,
  assertTrue: j1,
  clickEvent: Z1,
  copyKeyboardEvent: Ys,
  copyMouseEvent: ar,
  dblclickEvent: J1,
  delayRun: ri,
  getArrowDIR: ln,
  getCS: i1,
  getChildrenAABB: ei,
  getClass: $s,
  getEndpointNormal: Fs,
  getLineIntersectPoint: Fe,
  getLineIntersectPoints: ni,
  getNearestAnchorOnObjects: wr,
  getNearestPointOnLines: x1,
  getNearestPointOnObjectsOBB: Ir,
  getNearestPositionName: vr,
  getParallelLine: br,
  getParallelLines: pr,
  getPointByEndpoint: mx,
  getRectPositionDirection: t1,
  getRectPositionRotate: D1,
  isHorizontal: qx,
  jtopo: y0,
  mousedownEvent: X1,
  mousedragEndEvent: $1,
  mousedragEvent: K1,
  mouseenterEvent: V1,
  mousemoveEvent: G1,
  mouseoutEvent: Q1,
  mouseoverEvent: U1,
  mouseupEvent: q1,
  newEndpoint: Hs,
  pointProjectToLine: _r,
  randomColor: pa,
  range: qs,
  regClass: Ai,
  removeEvent: Xs,
  selectedEvent: ti,
  setProto: b,
  touchendEvent: Y1,
  touchmoveEvent: W1,
  touchstartEvent: F1,
  unselectedEvent: xi,
  util: ct,
  vec2: F
}, Symbol.toStringTag, { value: "Module" })), C1 = bs;
function bs(n, x) {
  const t = gs();
  return bs = function(e, s) {
    return e = e - 290, t[e];
  }, bs(n, x);
}
(function(n, x) {
  const t = bs, e = n();
  for (; []; )
    try {
      if (parseInt(t(292)) / 1 * (parseInt(t(300)) / 2) + -parseInt(t(298)) / 3 + -parseInt(t(293)) / 4 + parseInt(t(291)) / 5 + -parseInt(t(290)) / 6 * (parseInt(t(295)) / 7) + -parseInt(t(294)) / 8 * (parseInt(t(297)) / 9) + parseInt(t(301)) / 10 * (-parseInt(t(302)) / 11) === x)
        break;
      e.push(e.shift());
    } catch {
      e.push(e.shift());
    }
})(gs, 988904);
function gs() {
  const n = ["1196499TNtblY", "assign", "562ZZpHtc", "12010akUCKv", "1463BwhAAx", "30zxQXQD", "9706930GFBcSE", "5279nYLMOa", "4091952uTSAUB", "6784ZrFJVt", "716429dGhbBu", "jtopo", "3636dvZfyM"];
  return gs = function() {
    return n;
  }, gs();
}
let E1 = y0;
Object[C1(299)](E1, va), delete E1[C1(296)];
export {
  _i as AENode,
  bi as Animation,
  gi as AnimationSystem,
  nx as ArcLink,
  Ns as ArcShape,
  tx as ArrowShape,
  kt as AutoFoldLink,
  Bs as BezierCurveShape,
  Bt as BezierLink,
  At as CircleNode,
  As as CircleShape,
  Z as Collection,
  A1 as Config,
  s1 as CoordinateSystem,
  Ci as Cursor,
  Dt as CurveLink,
  Ds as CurveShape,
  Pt as Debug,
  Bx as DefaultZIndexs,
  Nt as Direction,
  D as DisplayObject,
  Q0 as DomUtil,
  Gs as Edge,
  yi as EffectSystem,
  js as EllipseShape,
  nt as Endpoint,
  N0 as EndpointFixedName,
  Z0 as EndpointFixedPoint,
  Nx as EndpointFunction,
  vt as EndpointNearest,
  ht as EndpointSegment,
  j0 as EventNames,
  K0 as EventTarget,
  wt as FlexionalLink,
  Sx as FoldLink,
  yt as FontInfo,
  Ws as FontUtil,
  la as ForceDirectLayout,
  ui as GeometricCoordinateSystem,
  Mx as Graph,
  Yt as GraphSystem,
  Is as HandlerLayer,
  si as HtmlImage,
  ft as ImageUtil,
  v0 as InputEvent,
  n1 as InputSystem,
  wa as InputTextfield,
  ms as Intersect,
  hi as Keyboard,
  ut as Layer,
  z0 as LayerLocalDeep,
  Zx as LayoutBase,
  mi as LayoutSystem,
  zs as LineShape,
  sr as LinearGradient,
  G as Link,
  di as LinkCoordinateSystem,
  Ox as LinkHelper,
  E as Node,
  xt as NodeHelper,
  Mt as OBB,
  rx as PI2,
  Uo as Path,
  or as Pattern,
  M as Point,
  ma as PopupMenu,
  L as Position,
  Ei as PositionInvertMap,
  ir as RadialGradient,
  Zs as RatioNode,
  lt as RectDefaultPositions,
  Xx as RectShape,
  q as Rectangle,
  V0 as ResourceLoader,
  fi as SelectedGroup,
  Tt as SerializerSystem,
  R as Shape,
  Jo as Stage,
  z1 as StageLocalDeep,
  D0 as StageMode,
  w0 as Style,
  dt as TextNode,
  dx as Theme,
  Jx as TipNode,
  li as Toolbar,
  Ia as Tooltip,
  H1 as TopoEvent,
  ba as TopoPainter,
  _s as Transform,
  Qs as VERSION,
  zt as Vertext,
  Vx as VideoNode,
  Mi as assertEquals,
  J0 as assertNotNull,
  j1 as assertTrue,
  Z1 as clickEvent,
  Ys as copyKeyboardEvent,
  ar as copyMouseEvent,
  J1 as dblclickEvent,
  ri as delayRun,
  ln as getArrowDIR,
  i1 as getCS,
  ei as getChildrenAABB,
  $s as getClass,
  Fs as getEndpointNormal,
  Fe as getLineIntersectPoint,
  ni as getLineIntersectPoints,
  wr as getNearestAnchorOnObjects,
  x1 as getNearestPointOnLines,
  Ir as getNearestPointOnObjectsOBB,
  vr as getNearestPositionName,
  br as getParallelLine,
  pr as getParallelLines,
  mx as getPointByEndpoint,
  t1 as getRectPositionDirection,
  D1 as getRectPositionRotate,
  qx as isHorizontal,
  y0 as jtopo,
  X1 as mousedownEvent,
  $1 as mousedragEndEvent,
  K1 as mousedragEvent,
  V1 as mouseenterEvent,
  G1 as mousemoveEvent,
  Q1 as mouseoutEvent,
  U1 as mouseoverEvent,
  q1 as mouseupEvent,
  Hs as newEndpoint,
  _r as pointProjectToLine,
  pa as randomColor,
  qs as range,
  Ai as regClass,
  Xs as removeEvent,
  ti as selectedEvent,
  b as setProto,
  Y1 as touchendEvent,
  W1 as touchmoveEvent,
  F1 as touchstartEvent,
  xi as unselectedEvent,
  ct as util,
  F as vec2
};
