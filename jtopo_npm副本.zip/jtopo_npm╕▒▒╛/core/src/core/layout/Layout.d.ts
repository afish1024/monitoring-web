import { AnimationSystem, EasingNames } from '../Animation';
import { PointLike } from '../jtopo_type';
import { Node } from '../Node';
export type LayoutAnimationOption = {
    name?: string;
    duration?: number;
    onEnd?: Function;
    effect?: EasingNames;
    times?: number;
    delay?: number;
    direction?: 'normal' | 'reverse' | 'alternate' | 'alternate-reverse' | 'normal';
};
export declare class LayoutBase {
    animationSystem: AnimationSystem;
    objects: Array<Node>;
    positions: Array<PointLike>;
    positionNormals: Array<PointLike>;
    x: number;
    y: number;
    scaleX: number;
    scaleY: number;
    width: number;
    height: number;
    rotation: number;
    constructor(objects: Array<Node>, positions: Array<PointLike>);
    resizeTo(width: number, height: number): void;
    translate(x: number, y: number): void;
    scale(sx: number, sy: number): void;
    rotate(rotation: number): void;
    doLayout(animationOption: LayoutAnimationOption): this;
}
