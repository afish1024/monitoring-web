import Intersect from '../geom/Intersect';
import { PointLike } from '../jtopo_type';
import { DisplayObject } from '../DisplayObject';
declare function getParallelLines(p1: PointLike, p2: PointLike, count: number, gap: number): PointLike[][];
declare function getParallelLine(p1: PointLike, p2: PointLike, gap: number): PointLike[];
declare function pointProjectToLine(p: PointLike, p1: PointLike, p2: PointLike): Intersect;
declare function getNearestPointOnLines(p: PointLike, points: Array<PointLike>): Intersect;
declare function getLineIntersectPoint(p1: PointLike, p2: PointLike, m1: PointLike, m2: PointLike, isLine?: boolean): {
    x: number;
    y: number;
};
declare function getLineIntersectPoints(p1: PointLike, p2: PointLike, points: Array<PointLike>, isLine?: boolean): any[];
declare function getNearestPointOnObjectsOBB(layer: any, mouseInStagePoint: any, nodeOrLinks: any, minDist: any): any;
export type NearestInfo = {
    object: any;
    anchorName: string;
};
export declare function getNearestAnchorOnObjects(mouseInStagePoint: PointLike, nodeOrLinks: Array<DisplayObject>, minDist: number): NearestInfo;
declare function getNearestPositionName(intersectInStage: any, minDist: any): string;
export declare function isHorizontal(k: any): boolean;
export declare function range(value: any, min: any, max: any): any;
export { getNearestPositionName, getNearestPointOnObjectsOBB, getNearestPointOnLines, getLineIntersectPoint, getLineIntersectPoints, getParallelLine, getParallelLines, pointProjectToLine };
