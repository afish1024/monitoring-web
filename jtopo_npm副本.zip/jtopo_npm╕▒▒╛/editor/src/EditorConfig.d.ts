export declare const EditorConfig: {
    anchorBox: {
        anchorDist: number;
        nodeDist: number;
    };
    anchorPoint: {
        width: number;
        height: number;
        activeStyle: {
            fillStyle: string;
        };
        unActiveStyle: {
            strokeStyle: string;
            fillStyle: string;
        };
    };
    nodeResizePoint: {
        width: number;
        height: number;
        style: {
            border: string;
            backgroundColor: string;
        };
    };
    nodeRotatePoint: {
        width: number;
        height: number;
        style: {
            lineWidth: number;
            strokeStyle: string;
            fillStyle: string;
        };
        rotateLineStyle: {
            strokeStyle: string;
        };
        rotateLineLength: number;
    };
    guildLine: {
        styleW: {
            strokeStyle: string;
            lineDash: number[];
        };
        styleS: {
            strokeStyle: string;
            lineDash: number[];
        };
    };
    linkCtrlPoint: {
        style: {
            lineWidth: number;
            strokeStyle: string;
            fillStyle: string;
        };
        activeStyle: {
            strokeStyle: string;
            fillStyle: string;
        };
        unactiveStyle: {
            strokeStyle: string;
            fillStyle: string;
        };
        adjustStyle: {
            strokeStyle: string;
            fillStyle: string;
        };
        ctrlLinkStyle: {
            lineDash: number[];
        };
    };
    dropBox: {
        style: {
            border: string;
            lineDash: number[];
        };
    };
};
