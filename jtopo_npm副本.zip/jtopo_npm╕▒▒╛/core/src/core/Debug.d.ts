export declare let Debug: {
    isDebug: boolean;
    showFPS: boolean;
    paintAABB: boolean;
    debugInfo: any;
    debugMode: () => void;
};
export { Debug as default };
