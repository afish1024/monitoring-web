declare const css: {
    load: (url: any, indoc: any) => void;
    inject: (cssContent: any, indoc: any) => void;
    insertStyle: (css: any) => any;
};
export default css;
