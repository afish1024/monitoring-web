export declare let Icons: any;
