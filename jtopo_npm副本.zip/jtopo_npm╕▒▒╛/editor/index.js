import { EventTarget as Ae, Theme as He, LinkHelper as S0, getClass as _e, Link as U, Node as r0, Position as u, PositionInvertMap as Te, CircleNode as we, DefaultZIndexs as he, Cursor as M, AutoFoldLink as a0, isHorizontal as be, CurveLink as Oe, BezierLink as Me, Style as ze, assertNotNull as Fe, EndpointSegment as De, EndpointFixedName as Le, EndpointFunction as Ne, PI2 as je, getNearestPointOnObjectsOBB as Ge, getNearestAnchorOnObjects as Re, PopupMenu as We, DisplayObject as ge, LayerLocalDeep as k0, ResourceLoader as ke, EventNames as C0, StageMode as Ye, NodeHelper as qe, Shape as Ve, InputTextfield as Ke, Tooltip as Ue } from "@jtopo/core";
const h0 = x0;
(function(r, x) {
  const e = x0, t = r();
  for (; []; )
    try {
      if (parseInt(e(148)) / 1 * (parseInt(e(150)) / 2) + -parseInt(e(151)) / 3 * (parseInt(e(157)) / 4) + parseInt(e(168)) / 5 + -parseInt(e(165)) / 6 + parseInt(e(175)) / 7 + -parseInt(e(152)) / 8 + parseInt(e(154)) / 9 * (-parseInt(e(158)) / 10) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(E0, 245267);
function E0() {
  const r = ["ondragstart", "style", "setAttribute", "add", "forEach", "innerHTML", "1379094dPNESa", "appendChild", "div", "2156035uPGxqY", "domElement", "block", "items", "dargItem", "stage", "getDragItem", "2129036wQxOCY", "item", "jtopo_iconsPanel", "3739eWiyBJ", "draggable", "142MiNLcU", "18GhLXwQ", "1566656epYHHC", "createElement", "2844aNacuP", "none", "show", "112688MWiFeZ", "5090ASYauQ"];
  return E0 = function() {
    return r;
  }, E0();
}
function x0(r, x) {
  const e = E0();
  return x0 = function(t, n) {
    return t = t - 146, e[t];
  }, x0(r, x);
}
class yx extends Ae {
  constructor(x) {
    const e = x0;
    super(), this[e(173)] = x, this[e(169)], this.initDom(), this.hide();
  }
  initDom() {
    const x = x0;
    let e = document.createElement("div");
    return e.classList[x(162)](x(147)), this[x(173)].layersContainer[x(166)](e), this[x(169)] = e, this;
  }
  hide() {
    const x = x0;
    return this[x(169)][x(160)].display = x(155), this;
  }
  [h0(156)]() {
    const x = h0;
    return this[x(169)][x(160)].display = x(170), this;
  }
  [h0(174)]() {
    return this[h0(172)];
  }
  setConfig(x) {
    const e = h0;
    let t = this;
    return x[e(171)][e(163)](function(n) {
      const s = e;
      let a = document[s(153)](s(167));
      a.classList[s(162)](s(146)), a[s(164)] = n.iconHtml, a[s(161)](s(149), !![]), a[s(159)] = function(i) {
        t.dargItem = n;
      }, t.domElement[s(166)](a);
    }), this;
  }
}
function A0(r, x) {
  const e = D0();
  return A0 = function(t, n) {
    return t = t - 132, e[t];
  }, A0(r, x);
}
(function(r, x) {
  const e = A0, t = r();
  for (; []; )
    try {
      if (parseInt(e(170)) / 1 + -parseInt(e(145)) / 2 * (parseInt(e(163)) / 3) + parseInt(e(152)) / 4 * (-parseInt(e(154)) / 5) + parseInt(e(141)) / 6 * (-parseInt(e(156)) / 7) + parseInt(e(172)) / 8 + parseInt(e(151)) / 9 * (parseInt(e(155)) / 10) + parseInt(e(165)) / 11 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(D0, 806276);
function D0() {
  const r = ["2083086TTFAkR", "beginArrow", "776556MMbkAl", "filter", "begin", "userData", "target", "597936gJaUmC", "style", "8463944IGDNbZ", "textOffsetX", "_#beginArrow", "replaceChild", "removeAllChild", "children", "frozen", "updateChildrenDeep", "setEnd", "name", "90sisKul", "origin", "setBegin", "_#label", "4YhYKoy", "inLinks", "getSegmentPoints", "updatePoints", "forEach", "addChilds", "9dvpABU", "536ncoQEv", "editable", "20570cVnYWH", "15790110BfXEMM", "260988wnlYNU", "outLinks", "className", "endArrow", "end", "length", "updatezIndex"];
  return D0 = function() {
    return r;
  }, D0();
}
function Qe(r, x) {
  const e = A0;
  ["id", e(171), e(140), "x", "y", e(137), e(153), "draggable", e(168), e(132), "textOffsetY"][e(166)]((a) => a != e(158)).forEach((a) => {
    r[a] = x[a];
  }), r[e(143)](x[e(167)][e(169)], x.begin), r[e(139)](x[e(160)][e(169)], x[e(160)]), r[e(135)](), r[e(150)](x.children);
  const n = x.parent;
  n && (n[e(134)](x, r), n[e(162)](), n[e(138)](!![])), r[e(148)]();
  let s = r[e(147)]()[e(161)];
  r[e(136)].forEach((a) => {
    const i = e;
    a[i(142)][0] + 1 >= s && (a.origin[0] = 0), a[i(140)] == i(144) ? r.label = a : a.name == i(133) ? (r[i(164)] = a, a.style = r[i(171)]) : a.name == "_#endArrow" && (r[i(159)] = a, a[i(171)] = r[i(171)]);
  }), x[e(146)] && x[e(146)][e(149)]((a) => {
    const i = e;
    let o = a[i(160)];
    o[i(169)] = a;
  }), x[e(157)] && x[e(157)][e(149)]((a) => {
    const i = e;
    let o = a[i(167)];
    o[i(169)] = a;
  });
}
function L0() {
  const r = ["#f4642b", "5agrXBv", "#7e2065", "#FF00FF", "#C06f98", "#d2865a", "#ffe99b", "#C0C0C0", "#f0ac68", "#203046", "#475164", "#cb8a2a", "#fb991c", "#FFA500", "length", "#FFD700", "#1ba784", "#FDF5E6", "2892VvcdiZ", "#f18851", "#248067", "#24653E", "#61649f", "setHex", "#681752", "addScalar", "rgb(", "string", "#F0E68C", "#B0E0E6", "#C02c38", "#0f1423", "#F08080", "5956794zxEMrz", "#ebe0c4", "#BA55D3", "getHex", "#778899", "#9932CC", "#800000", "#FF8C00", "#C71585", "#4169E1", "multiply", "getHexString", "#e85827", "#ADD8E6", "#F0FFF0", "#DC143C", "#7B68EE", "#6A5ACD", "#808080", "#FF0000", "setHSL", "#40E0D0", "#90EE90", "#000000", "#FFEFD5", "floor", "#8B4513", "copyLinearToGamma", "#228B22", "#FF1493", "#FFA07A", "#F5DEB3", "#FFF5EE", "copy", "21cEwGFx", "#DB7093", "11hMJHoM", "#35aeff", "#F0F8FF", "#15838a", "setRGB", "#A9A9A9", "#7FFFD4", "#12A182", "3942052aLdWXO", "#CD5C5C", "set", "#BDB76B", "copyGammaToLinear", "#FA7E23", "toArray", "#5F9EA0", "#00CED1", "#FFFFFF", "#708090", "#556B2F", "#ffdc99", "#9370DB", "#DAA520", "827338lxQbAD", "getHSL", "lerp", "#E6E6FA", "#7FFF00", "#4682B4", "#E9967A", "setStyle", "3aMPdYT", "fromArray", "#d2Dfb2", "#FFB6C1", "#f6d82c", "#3c968a", "#4E7ca1", "#FDD163", "#EEE8AA", "#7CFC00", "220324FSXVqa", "min", "#FF6347", "#F5F5DC", "#9400D3", "#FF69B4", "#2E8B57", "#000080", "#2775B6", "#FFFFE0", "#2F4F4F", "#87CEFA", "#5ae292", "#3fb9c1", "#FFFACD", "6087610GhuKOd", "#F5FFFA", "#f7e853", "#fdbc3a", "#00BFFF", "addColors", "#00FA9A", "000000", "#008B8B", "#F8F8FF", "#00FF7F", "#FFF8DC", "toString", "#FF9900", "#FFDAB9", "multiplyScalar", "sqrt", "1zndWVU", "#2d2e36", "#FFFAF0", "#b6ca98", "#8e8b86", "#D3D3D3", "#191970", "#FAEBD7", "7074027jvhjXD", "#00FFFF", "getStyle", "#BC8F8F", "#87CEEB", "#2474b5", "#696969", "#FFEBCD", "#808000", "#D2B48C", "#008000", "#EE3f4d", "#0000FF", "#B8860B", "#FFC0CB", "#D8BFD8", "toFixed", "rgba(", "#FF7F50", "#DA70D6", "#97893f", "#CD853F", "exec", "#567f4f", "#00008B", "#f4a146", "#20B2AA", "#ffde5f", "#F0FFFF", "#166E84", "#32510E", "#B22222", "#DEB887", "#00FF00", "#f3ca43", "#98FB98", "#707556", "#A52A2A", "#d7d351", "#6B8E23", "test", "#F4A460", "#8FBC8F", "#AFEEEE", "2238992YvSOcB"];
  return L0 = function() {
    return r;
  }, L0();
}
const c = B0;
function B0(r, x) {
  const e = L0();
  return B0 = function(t, n) {
    return t = t - 333, e[t];
  }, B0(r, x);
}
(function(r, x) {
  const e = B0, t = r();
  for (; []; )
    try {
      if (parseInt(e(491)) / 1 * (-parseInt(e(441)) / 2) + parseInt(e(449)) / 3 * (-parseInt(e(426)) / 4) + parseInt(e(350)) / 5 * (-parseInt(e(382)) / 6) + -parseInt(e(416)) / 7 * (parseInt(e(348)) / 8) + -parseInt(e(499)) / 9 + -parseInt(e(474)) / 10 * (-parseInt(e(418)) / 11) + parseInt(e(367)) / 12 * (parseInt(e(459)) / 13) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(L0, 675623);
const Be = { aliceblue: c(420), antiquewhite: c(498), aqua: c(500), aquamarine: c(424), azure: c(527), beige: c(462), bisque: "#FFE4C4", black: c(405), blanchedalmond: c(506), blue: c(511), blueviolet: "#8A2BE2", brown: c(341), burlywood: c(336), cadetblue: c(433), chartreuse: c(445), chocolate: "#D2691E", coral: c(517), cornflowerblue: "#6495ED", cornsilk: c(485), crimson: c(397), cyan: c(500), darkblue: c(523), darkcyan: c(482), darkgoldenrod: c(512), darkgray: c(423), darkgreen: "#006400", darkgrey: "#A9A9A9", darkkhaki: c(429), darkmagenta: "#8B008B", darkolivegreen: c(437), darkorange: c(389), darkorchid: c(387), darkred: "#8B0000", darksalmon: c(447), darkseagreen: c(346), darkslateblue: "#483D8B", darkslategray: "#2F4F4F", darkslategrey: c(469), darkturquoise: c(434), darkviolet: c(463), deeppink: c(411), deepskyblue: c(478), dimgray: c(505), dimgrey: c(505), dodgerblue: "#1E90FF", firebrick: c(335), floralwhite: c(493), forestgreen: c(410), fuchsia: "#FF00FF", gainsboro: "#DCDCDC", ghostwhite: c(483), gold: c(364), goldenrod: c(440), gray: c(400), green: c(509), greenyellow: "#ADFF2F", grey: c(400), honeydew: c(396), hotpink: c(464), indianred: c(427), indigo: "#4B0082", ivory: "#FFFFF0", khaki: c(377), lavender: c(444), lavenderblush: "#FFF0F5", lawngreen: c(458), lemonchiffon: c(473), lightblue: c(395), lightcoral: c(381), lightcyan: "#E0FFFF", lightgoldenrodyellow: "#FAFAD2", lightgray: "#D3D3D3", lightgreen: c(404), lightgrey: c(496), lightpink: c(452), lightsalmon: c(412), lightseagreen: c(525), lightskyblue: c(470), lightslategray: c(386), lightslategrey: c(386), lightsteelblue: "#B0C4DE", lightyellow: c(468), lime: c(337), limegreen: "#32CD32", linen: "#FAF0E6", magenta: c(352), maroon: c(388), mediumaquamarine: "#66CDAA", mediumblue: "#0000CD", mediumorchid: c(384), mediumpurple: c(439), mediumseagreen: "#3CB371", mediumslateblue: c(398), mediumspringgreen: c(480), mediumturquoise: "#48D1CC", mediumvioletred: c(390), midnightblue: c(497), mintcream: c(475), mistyrose: "#FFE4E1", moccasin: "#FFE4B5", navajowhite: "#FFDEAD", navy: c(466), oldlace: c(366), olive: c(507), olivedrab: c(343), orange: c(362), orangered: "#FF4500", orchid: c(518), palegoldenrod: c(457), palegreen: c(339), paleturquoise: c(347), palevioletred: c(417), papayawhip: c(406), peachpuff: c(488), peru: c(520), pink: c(513), plum: "#DDA0DD", powderblue: c(378), purple: "#800080", red: c(401), rosybrown: c(502), royalblue: c(391), saddlebrown: c(408), salmon: "#FA8072", sandybrown: c(345), seagreen: c(465), seashell: c(414), sienna: "#A0522D", silver: c(356), skyblue: c(503), slateblue: c(399), slategray: c(436), slategrey: c(436), snow: "#FFFAFA", springgreen: c(484), steelblue: c(446), tan: c(508), teal: "#008080", thistle: c(514), tomato: c(461), turquoise: c(403), violet: "#EE82EE", wheat: c(413), white: c(435), whitesmoke: "#F5F5F5", yellow: "#FFFF00", yellowgreen: "#9ACD32" };
c(495), c(456), c(419), c(471), c(524), c(476), c(333), c(519), c(368), c(338), c(334), c(370), c(454), c(342), c(357), c(358), c(340), c(522), c(349), c(453), c(394), c(361), c(477), c(526), c(438), c(421), c(472), c(451), c(355), c(360), c(354), c(494), c(383);
c(359), c(492), c(431), c(487), c(369), c(425), c(365), c(380), c(455), c(504), c(467), c(371), c(353), c(351), c(373), c(510), c(379);
class Ie {
  constructor(x) {
    const e = c;
    this.r = 1, this.g = 1, this.b = 1, this.o = 1, arguments[e(363)] === 3 ? this[e(422)](arguments[0], arguments[1], arguments[2]) : this[e(428)](x);
  }
  [c(428)](x) {
    const e = c;
    return x instanceof Ie ? this[e(415)](x) : typeof x == "number" ? this[e(372)](x) : typeof x === e(376) && this[e(448)](x), this;
  }
  setHex(x) {
    return x = Math[c(407)](x), this.r = (x >> 16 & 255) / 255, this.g = (x >> 8 & 255) / 255, this.b = (x & 255) / 255, this;
  }
  setRGB(x, e, t) {
    return this.r = x, this.g = e, this.b = t, this;
  }
  [c(402)](x, e, t) {
    if (e === 0)
      this.r = this.g = this.b = t;
    else {
      let n = function(i, o, d) {
        return d < 0 && (d += 1), d > 1 && (d -= 1), d < 0.16666666666666666 ? i + (o - i) * 6 * d : d < 0.5 ? o : d < 0.6666666666666666 ? i + (o - i) * 6 * (0.6666666666666666 - d) : i;
      }, s = t <= 0.5 ? t * (1 + e) : t + e - t * e, a = 2 * t - s;
      this.r = n(a, s, x + 1 / 3), this.g = n(a, s, x), this.b = n(a, s, x - 1 / 3);
    }
    return this;
  }
  setStyle(x) {
    const e = c;
    if (/^rgb\((\d+), ?(\d+), ?(\d+)\)$/i[e(344)](x)) {
      let t = /^rgb\((\d+), ?(\d+), ?(\d+)\)$/i[e(521)](x);
      return this.r = Math.min(255, parseInt(t[1], 10)) / 255, this.g = Math[e(460)](255, parseInt(t[2], 10)) / 255, this.b = Math[e(460)](255, parseInt(t[3], 10)) / 255, this;
    }
    if (/^rgba\((\d+),?(\d+),?(\d+),?(\S+)\)$/i[e(344)](x)) {
      let t = /^rgba\((\d+),?(\d+),?(\d+),?(\S+)\)$/i[e(521)](x);
      return this.r = Math[e(460)](255, parseInt(t[1], 10)) / 255, this.g = Math[e(460)](255, parseInt(t[2], 10)) / 255, this.b = Math[e(460)](255, parseInt(t[3], 10)) / 255, this.o = parseInt(t[4]), this;
    }
    if (/^rgb\((\d+)\%, ?(\d+)\%, ?(\d+)\%\)$/i.test(x)) {
      let t = /^rgb\((\d+)\%, ?(\d+)\%, ?(\d+)\%\)$/i[e(521)](x);
      return this.r = Math[e(460)](100, parseInt(t[1], 10)) / 100, this.g = Math[e(460)](100, parseInt(t[2], 10)) / 100, this.b = Math.min(100, parseInt(t[3], 10)) / 100, this;
    }
    if (/^\#([0-9a-f]{6})$/i[e(344)](x)) {
      let t = /^\#([0-9a-f]{6})$/i[e(521)](x);
      return this[e(372)](parseInt(t[1], 16)), this;
    }
    if (/^\#([0-9a-f])([0-9a-f])([0-9a-f])$/i[e(344)](x)) {
      let t = /^\#([0-9a-f])([0-9a-f])([0-9a-f])$/i.exec(x);
      return this[e(372)](parseInt(t[1] + t[1] + t[2] + t[2] + t[3] + t[3], 16)), this;
    }
    return /^(\w+)$/i[e(344)](x) ? (this[e(372)](Be[x]), this) : this;
  }
  [c(415)](x) {
    return this.r = x.r, this.g = x.g, this.b = x.b, this;
  }
  [c(430)](x) {
    return this.r = x.r * x.r, this.g = x.g * x.g, this.b = x.b * x.b, this;
  }
  [c(409)](x) {
    const e = c;
    return this.r = Math[e(490)](x.r), this.g = Math[e(490)](x.g), this.b = Math.sqrt(x.b), this;
  }
  convertGammaToLinear() {
    let x = this.r, e = this.g, t = this.b;
    return this.r = x * x, this.g = e * e, this.b = t * t, this;
  }
  convertLinearToGamma() {
    const x = c;
    return this.r = Math.sqrt(this.r), this.g = Math[x(490)](this.g), this.b = Math.sqrt(this.b), this;
  }
  getHex() {
    return this.r * 255 << 16 ^ this.g * 255 << 8 ^ this.b * 255 << 0;
  }
  [c(393)]() {
    const x = c;
    return (x(481) + this[x(385)]()[x(486)](16)).slice(-6);
  }
  [c(442)](x) {
    let e = x || { h: 0, s: 0, l: 0 }, t = this.r, n = this.g, s = this.b, a = Math.max(t, n, s), i = Math.min(t, n, s), o, d, l = (i + a) / 2;
    if (i === a)
      o = 0, d = 0;
    else {
      let f = a - i;
      switch (d = l <= 0.5 ? f / (a + i) : f / (2 - a - i), a) {
        case t:
          o = (n - s) / f + (n < s ? 6 : 0);
          break;
        case n:
          o = (s - t) / f + 2;
          break;
        case s:
          o = (t - n) / f + 4;
          break;
      }
      o /= 6;
    }
    return e.h = o, e.s = d, e.l = l, e;
  }
  [c(501)](x) {
    const e = c;
    return x != null ? (x = x[e(515)](1), e(516) + (this.r * 255 | 0) + "," + (this.g * 255 | 0) + "," + (this.b * 255 | 0) + "," + x + ")") : e(375) + (this.r * 255 | 0) + "," + (this.g * 255 | 0) + "," + (this.b * 255 | 0) + ")";
  }
  offsetHSL(x, e, t) {
    const n = c;
    let s = this[n(442)]();
    return s.h += x, s.s += e, s.l += t, this[n(402)](s.h, s.s, s.l), this;
  }
  add(x) {
    return this.r += x.r, this.g += x.g, this.b += x.b, this;
  }
  [c(479)](x, e) {
    return this.r = x.r + e.r, this.g = x.g + e.g, this.b = x.b + e.b, this;
  }
  [c(374)](x) {
    return this.r += x, this.g += x, this.b += x, this;
  }
  [c(392)](x) {
    return this.r *= x.r, this.g *= x.g, this.b *= x.b, this;
  }
  [c(489)](x) {
    return this.r *= x, this.g *= x, this.b *= x, this;
  }
  [c(443)](x, e) {
    return this.r += (x.r - this.r) * e, this.g += (x.g - this.g) * e, this.b += (x.b - this.b) * e, this;
  }
  equals(x) {
    return x.r === this.r && x.g === this.g && x.b === this.b;
  }
  [c(450)](x) {
    return this.r = x[0], this.g = x[1], this.b = x[2], this;
  }
  [c(432)]() {
    return [this.r, this.g, this.b];
  }
  clone() {
    return new Ie().setRGB(this.r, this.g, this.b);
  }
}
const y = u0;
(function(r, x) {
  const e = u0, t = r();
  for (; []; )
    try {
      if (-parseInt(e(258)) / 1 + -parseInt(e(217)) / 2 + -parseInt(e(324)) / 3 * (parseInt(e(242)) / 4) + parseInt(e(370)) / 5 * (parseInt(e(309)) / 6) + parseInt(e(352)) / 7 * (parseInt(e(372)) / 8) + -parseInt(e(346)) / 9 * (parseInt(e(308)) / 10) + -parseInt(e(224)) / 11 * (-parseInt(e(333)) / 12) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(P0, 602459);
function u0(r, x) {
  const e = P0();
  return u0 = function(t, n) {
    return t = t - 214, e[t];
  }, u0(r, x);
}
function P0() {
  const r = ["6YBiUKF", "direction", "textBaseline", "字体重量", "draggable", "2,2", "可连线", "themeName", "gray", "middle", "text", "AutoFoldLink", "visible", "fontFamily", "结束箭头大小", "95619sETaFe", "setFolderValues", "className", "close", "BezierLink", "圆角大小", "block", "show", "string", "32249604eVEqQq", "节点属性", "垂直偏移量", "lineCap", "-15px", "边框粗细", "文本对齐", "keys", "结束偏移", "lineWidth", "gui", "Arial", "1,1", "3960IDytko", "property", "folders", "split", "connectable", "layersContainer", "7eTJaEk", "setCurrentObject", "fontWeight", "getCtroller", "globalAlpha", "10,1", "getFolder", "setEndArrow", "update", "serif", "top", "add", "Link", "填充颜色", "none", "fontSize", "beginArrow", "水平偏移量", "407780nQVQzs", "open", "9267096WhAClq", "domElement", "backgroundColor", "linkCtrlBox", "2065810RAMMAt", "center", "round", "setValue", "butt", "endOffset", "createArrow", "11huWtEg", "endArrow", "borderRadius", "可被编辑", "appendChild", "font", "基线对齐", "整体透明度", "fillStyle", "object", "圆弧方向", "__folders", "文本位置", "toLowerCase", "sans-serif", "showProperty", "__controllers", "getValue", "4snWVGB", "isLink", "beginOffset", "末端样式", "strokeStyle", "height", "name", "label", "开始箭头大小", "textOffsetX", "锁定子元素", "replace", "style", "旋转度数", "left", "nodeCtrlBox", "1176453oOtJGp", "onChange", "normal", "attachTo", "indexOf", "remove", "可拖拽", "absolute", "0px", "basic", "getCtrollerValue", "setBeginArrow", "normal 10px arial", "arial", "selectedGroup", "endArrowSize", "color", "find", "updatezIndex", "图片路径", "开始偏移", "textAlign", "stage", "newFolder", "zIndex", "线条粗细", "lineDash", "textPosition", "right", "CurveLink", "onFinishChange", "display", "addFolder", "editable", "imageSrc", "editor", "styleSystem", "字体名称", "连线属性", "init", "resizeTo", "width", "hide", "bold", "Color", "rotation", "基础属性", "forEach", "frozen", "左上角", "24630gypYCD"];
  return P0 = function() {
    return r;
  }, P0();
}
class mx {
  constructor(x, e) {
    const t = u0;
    this[t(293)] = x, this.dat = e, this.gui = new e.GUI(), this.object, this[t(348)] = {};
  }
  [y(353)](x) {
    const e = y, t = this[e(293)], n = this.editor[e(280)];
    n.inputSystem.pickedObject = x, n[e(272)].removeAll()[e(363)](x), x[e(243)] ? t[e(216)][e(261)](x) : x.isNode && t[e(257)][e(261)](x), t[e(360)](), this.showProperty(x);
  }
  [y(239)](x) {
    const e = y;
    if (x == null)
      return;
    this[e(267)] = { id: x.id, name: "", parentId: x.parentId, x: 1, y: 1, imageSrc: "", width: 1, height: 1, text: "", zIndex: 1, beginArrowSize: 0, endArrowSize: 0, beginOffset: 0, endOffset: 0, edges: 3, rotation: 0, className: "AutoFoldLink", direction: 1, frozen: ![], draggable: !![], editable: !![], connectable: !![] }, x[e(243)] && (x[e(368)] && x[e(368)].visible && (this.basic.beginArrowSize = x[e(368)][e(299)]), x[e(225)] && x[e(225)][e(321)] && (this[e(267)][e(273)] = x[e(225)][e(299)])), this[e(293)];
    const t = this.editor[e(280)], n = He[t[e(294)][e(316)]], s = n[x[e(326)]];
    this[e(254)] = { lineDash: null, backgroundColor: "", textPosition: s[e(285)] || e(218), textAlign: s[e(279)] || e(218), textBaseline: s[e(279)] || e(318), borderRadius: 0, strokeStyle: s[e(246)] || e(317), fillStyle: "", color: s[e(274)] || "", borderWidth: 0, fontWeight: e(301), fontSize: "12", fontFamily: e(271), lineWidth: s[e(342)] || 1, lineCap: e(221), globalAlpha: 1, textOffsetX: 0, textOffsetY: 0 };
    const a = this[e(267)], i = this[e(254)];
    Object[e(340)](a)[e(305)](function(f) {
      const h = e;
      if (x[f] != null) {
        let _ = x[f];
        f == h(303) && (_ = _ * (180 / Math.PI)), a[f] = _;
      }
    }), Object[e(340)](i)[e(305)](function(f) {
      const h = e;
      let _ = x[h(254)][f];
      if (x[h(254)][f] != null && (i[f] = _), f[h(262)](h(302)) != -1 && _ && _[h(237)]) {
        let O = Be[_.toLowerCase()];
        O && (i[f] = O);
      }
    }), this.object == null && (this[e(233)] = x, this.init()), this[e(233)] = x;
    let o = x[e(254)].borderWidth;
    o == null && (o = 0), i.borderWidth = o;
    let d = x[e(254)][e(229)];
    d == null && (d = e(270));
    const l = d[e(349)](" ");
    l.length > 3 ? (i[e(354)] = l[0] + " " + l[1], i[e(367)] = l[2][e(253)]("px", ""), i[e(322)] = l[3]) : (i[e(354)] = l[0], i.fontSize = l[1][e(253)]("px", ""), i[e(322)] = l[2]), this[e(325)](a, i), x.isNode && this[e(358)](e(334)) != null ? (this.getFolder(e(334))[e(331)](), this[e(358)](e(296))[e(300)]()) : this[e(358)](e(296)) != null && (this[e(358)](e(296)).show(), this.getFolder(e(334)).hide());
  }
  newFolder(x) {
    const e = y, t = this[e(343)][e(290)](x);
    return this[e(348)][x] = t, t;
  }
  [y(358)](x) {
    return this[y(348)][x];
  }
  [y(268)](x, e) {
    return this[y(355)](x, e).getValue();
  }
  [y(355)](x, e) {
    const t = y;
    return this[t(358)](x)[t(240)][t(275)]((s) => s[t(347)] == e);
  }
  [y(325)](x, e) {
    const t = y;
    Object[t(340)](this[t(343)][t(235)])[t(305)]((s) => {
      const a = t;
      this.gui.__folders[s][a(240)][a(305)](function(d) {
        const l = a;
        let f = d.property;
        x[f] != null ? d[l(220)](x[f]) : e[f] != null && d.setValue(e[f]);
      });
    });
  }
  [y(297)]() {
    const x = y, e = this, t = this.editor, n = t[x(280)], s = t.currentLayer, a = this[x(267)], i = this.style, o = [x(307), "顶部", "右上角", "右边", "中心", "右边", "左下角", "底部", "右下角"], d = ["lt", "ct", "rt", "lm", x(218), "rm", "lb", "cb", "rb"], l = {};
    o.forEach(function(p, k) {
      l[p] = d[k];
    });
    let f = { 居中: x(218), 左: x(256), 右: x(286) }, h = { 顶部: x(362), 中心: x(318), 底部: "bottom" }, _ = { 正常: x(260), 加粗: "bold", 斜体: "italic" }, O = { 直线: x(364), 自动折线: x(320), 圆弧: "ArcLink", 曲线: x(287), 贝塞尔曲线: x(328) }, j = { 顺时针: -1, 逆时针: 1 }, E = { 实线: "1,0", "虚线1,1": x(345), "虚线2,2": x(314), "虚线3,3": "3,3", "虚线7,3": "7,3", "虚线3,7": "3,7", "虚线10,1": x(357), "虚线1,10": "1,10" }, q = [x(344), "宋体", x(361), x(238)], L = { 默认: x(221), 圆形: x(219), 矩形: "square" };
    function m() {
      const p = x;
      let k = this.property, w = this[p(241)]();
      k == p(282) ? s[p(276)]() : k == "rotation" && (w = w * (Math.PI / 180));
      let I = e.object;
      if (I[p(243)]) {
        if (k == "beginArrowSize")
          if (w != 0) {
            let A = I.beginArrow;
            A == null ? (A = S0[p(223)](), I[p(269)](A)) : A.resizeTo(w, w), A[p(331)]();
          } else
            I.beginArrow && I[p(368)][p(300)]();
        else if (k == p(273))
          if (w != 0) {
            let A = I[p(225)];
            A == null ? (A = S0[p(223)](), I[p(359)](A)) : A[p(298)](w, w), A[p(331)]();
          } else
            I.endArrow && I[p(225)][p(300)]();
        else if (k == p(326)) {
          let A = w;
          if (I[p(326)] !== A) {
            let ue = _e(A), Ce = new ue();
            Qe(Ce, I), I = Ce, e[p(353)](I);
          }
        }
      }
      k != p(326) && (I[k] = w), I.imageSrc != null && (I.style[p(215)] = null), t[p(360)]();
    }
    function C() {
      const p = x;
      let k = this[p(347)], w = this[p(241)](), I = e.object, A = I[p(254)];
      if (k == p(322) || k == p(354) || k == p(367)) {
        let ue = e.getCtrollerValue("文本", p(354)) + " " + e[p(268)]("文本", "fontSize") + "px " + e[p(268)]("文本", p(322));
        k = "font", w = ue;
      } else
        k == "lineDash" ? w == null || w == "" ? w = null : typeof w == p(332) && (w = w[p(349)](",")) : k == p(215) && e.object.isLink && (w = null);
      I instanceof U && k.indexOf(p(229)) != -1 && I[p(249)] != null && (I[p(249)].style[k] = w), A[k] = w, I[p(292)] != null && (I.style.backgroundColor = null), t[p(360)]();
    }
    const W = this[x(281)](x(304));
    W[x(363)](a, "id")[x(288)](m)[x(248)]("ID"), W[x(363)](a, x(248))[x(288)](m).name(x(248)), W[x(363)](a, x(319))[x(288)](m)[x(248)]("文字"), W[x(363)](a, x(306), ![])[x(259)](m).name(x(252)), W[x(363)](a, x(313), !![])[x(259)](m)[x(248)](x(264)), W[x(363)](a, x(291), !![]).onChange(m)[x(248)](x(227)), W.add(a, x(350), !![])[x(259)](m).name(x(315)), W[x(363)](i, x(356), 0, 1, 0.1).onChange(C)[x(248)](x(231)), W.add(i, x(246)).onFinishChange(C)[x(248)]("线条颜色"), W.open();
    const P = this[x(281)](x(334));
    P[x(363)](i, "borderWidth", 0, 10)[x(259)](C).name(x(338)), P[x(363)](i, x(342), 0, 10).onChange(C)[x(248)](x(283)), P[x(363)](i, x(284), E)[x(259)](C)[x(248)]("虚实"), P[x(363)](i, x(215))[x(288)](C)[x(248)]("背景颜色"), P.add(i, x(232))[x(288)](C)[x(248)](x(365)), P[x(363)](a, x(292))[x(288)](m)[x(248)](x(277)), P.add(a, "x")[x(288)](m), P[x(363)](a, "y").onFinishChange(m), P[x(363)](a, x(299), 1)[x(288)](m)[x(248)]("宽度"), P[x(363)](a, x(247), 1).onFinishChange(m).name("高度"), P[x(363)](a, x(303), -360, 360, 1)[x(259)](m)[x(248)](x(255)), P[x(363)](i, x(226))[x(259)](C)[x(248)](x(329)), P[x(363)](a, x(282), 0, 1e3, 1)[x(259)](m)[x(248)]("层级"), P.open();
    const Y = this[x(281)](x(296));
    Y[x(363)](i, x(342), 0, 100)[x(259)](C)[x(248)](x(283)), Y.add(i, x(284), E)[x(259)](C)[x(248)]("虚实"), Y[x(363)](a, "className", O)[x(259)](m)[x(248)]("线型"), Y[x(363)](a, x(310), j).onChange(m)[x(248)](x(234)), Y[x(363)](a, "beginArrowSize", 0, 50)[x(259)](m)[x(248)](x(250)), Y.add(a, x(273), 0, 50)[x(259)](m)[x(248)](x(323)), Y[x(363)](a, x(244), -30, 30)[x(259)](m).name(x(278)), Y[x(363)](a, x(222), -30, 30).onChange(m)[x(248)](x(341)), Y.add(i, x(336), L)[x(259)](C).name(x(245)), Y.open();
    const V = this[x(281)]("文本");
    V[x(363)](i, "fontFamily", q)[x(259)](C).name(x(295)), V[x(363)](i, x(367), 1, 1e3)[x(259)](C)[x(248)]("大小"), V[x(363)](i, x(354), _)[x(259)](C)[x(248)](x(312)), V.add(i, "color")[x(259)](C)[x(248)]("颜色"), V[x(363)](i, x(285), l)[x(259)](C).name(x(236)), V[x(363)](i, x(279), f)[x(259)](C).name(x(339)), V[x(363)](i, x(311), h)[x(259)](C).name(x(230)), V[x(363)](i, x(251))[x(259)](C)[x(248)](x(369)), V.add(i, "textOffsetY")[x(259)](C)[x(248)](x(335));
    let t0 = this[x(343)].domElement;
    t0[x(263)](), n[x(351)][x(228)](t0), t0[x(254)].position = x(265), t0[x(254)][x(286)] = x(337), t0[x(254)][x(362)] = x(266), t0[x(254)][x(282)] = 1e3;
  }
  [y(371)]() {
    const x = y;
    this.gui[x(371)]();
  }
  [y(327)]() {
    const x = y;
    this[x(343)][x(327)]();
  }
  [y(300)]() {
    const x = y;
    this[x(343)][x(214)].style[x(289)] = x(366);
  }
  [y(331)]() {
    const x = y;
    this.gui[x(214)][x(254)][x(289)] = x(330);
  }
}
const v = H0;
function H0(r, x) {
  const e = T0();
  return H0 = function(t, n) {
    return t = t - 193, e[t];
  }, H0(r, x);
}
(function(r, x) {
  const e = H0, t = r();
  for (; []; )
    try {
      if (parseInt(e(204)) / 1 + parseInt(e(197)) / 2 + -parseInt(e(207)) / 3 + -parseInt(e(203)) / 4 + parseInt(e(201)) / 5 + parseInt(e(196)) / 6 + parseInt(e(195)) / 7 * (parseInt(e(194)) / 8) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(T0, 567738);
const g = { anchorBox: { anchorDist: 20, nodeDist: 12 }, anchorPoint: { width: 14, height: 14, activeStyle: { fillStyle: v(199) }, unActiveStyle: { strokeStyle: v(205), fillStyle: v(193) } }, nodeResizePoint: { width: 12, height: 12, style: { border: v(198), backgroundColor: v(202) } }, nodeRotatePoint: { width: 14, height: 14, style: { lineWidth: 1, strokeStyle: v(210), fillStyle: v(202) }, rotateLineStyle: { strokeStyle: v(205) }, rotateLineLength: 30 }, guildLine: { styleW: { strokeStyle: v(200), lineDash: [1, 1] }, styleS: { strokeStyle: v(200), lineDash: [1, 1] } }, linkCtrlPoint: { style: { lineWidth: 1, strokeStyle: v(205), fillStyle: v(206) }, activeStyle: { strokeStyle: v(209), fillStyle: v(209) }, unactiveStyle: { strokeStyle: v(208), fillStyle: v(206) }, adjustStyle: { strokeStyle: v(205), fillStyle: v(202) }, ctrlLinkStyle: { lineDash: [2, 2] } }, dropBox: { style: { border: "3px solid orange", lineDash: [5, 3] } } };
function T0() {
  const r = ["2174312ZozSjZ", "1259382iKumve", "565630NojUSS", "1px solid black", "red", "#c8c8c8", "3504355UxrSAP", "orange", "1478688ltvgaZ", "169044ZsOoPj", "gray", "pink", "2207499iORCgm", "rgba(0,0,0,0.9)", "rgba(0,0,0,0.1)", "black", "rgba(255,255,255,0.6)", "8ZhwyiX"];
  return T0 = function() {
    return r;
  }, T0();
}
function O0() {
  const r = ["8FDDsVV", "editor", "nodeCtrlBox", "name", "mousedragHandler", "style", "adjustFixedDirection", "transformPoint", "1462816EgtGll", "s-resize", "preventDefault", "n-resize", "2RmOWls", "mouseoutHandler", "841807kHospc", "21PumgeL", "getNoChildrensObjects", "height", "1014135SaaCeA", "stage", "ne-resize", "translateWith", "e-resize", "setCursor", "1690550FkuWQV", "nodeResizePoint", "mousedownHandler", "8769438gTJeTf", "updateSize", "2007110OBwXpe", "positionToLocalPoint", "resizeWith", "mouseenterHandler", "sw-resize", "selectedGroup.length is 0!", "nw-resize", "pickedObject", "isNodeResizePoint", "selectedGroup", "2431596CHfwka", "css"];
  return O0 = function() {
    return r;
  }, O0();
}
const X = b0;
(function(r, x) {
  const e = b0, t = r();
  for (; []; )
    try {
      if (parseInt(e(367)) / 1 * (parseInt(e(365)) / 2) + parseInt(e(371)) / 3 * (parseInt(e(353)) / 4) + -parseInt(e(377)) / 5 + -parseInt(e(351)) / 6 + parseInt(e(368)) / 7 * (parseInt(e(361)) / 8) + -parseInt(e(339)) / 9 + parseInt(e(341)) / 10 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(O0, 549406);
class Ze extends r0 {
  constructor(x, e) {
    const t = b0;
    super(), this[t(349)] = !![], this.dragBegin = ![], this[t(355)] = x, this[t(354)] = x[t(354)], this.stage = this[t(354)][t(372)], this[t(350)] = this[t(372)][t(350)], this.resizeTo(g[t(378)].width, g.nodeResizePoint[t(370)]), this[t(352)](g[t(378)][t(358)]), this[t(356)] = e;
  }
  [X(344)]() {
  }
  mousemoveHandler() {
    const x = X;
    let e, t = this.name;
    t == u.lt ? e = x(347) : t == u.ct ? e = x(364) : t == u.rt ? e = x(373) : t == u.lm ? e = "w-resize" : t == u.rm ? e = x(375) : t == u.lb ? e = x(345) : t == u.cb ? e = x(362) : t == u.rb && (e = "se-resize"), this.editor.stage[x(376)](e);
  }
  [X(366)](x) {
  }
  [X(338)](x) {
    x.preventDefault();
  }
  mouseupHandler(x) {
    x.preventDefault();
  }
  [X(357)](x) {
    const e = X;
    x[e(363)]();
    let t = this[e(355)], n = t[e(354)], s = n[e(372)], a = this[e(356)];
    if (this[e(350)][e(369)]().length == 0)
      throw new Error(e(346));
    let d = s.inputSystem[e(348)], l = d.stageToLocalXY(x.x, x.y), f = d[e(342)](a), h = l.x - f.x, _ = l.y - f.y;
    a == u.lt ? (h = -h, _ = -_) : a == u.ct ? (h = 0, _ = -_) : a == u.rt ? _ = -_ : a == u.lm ? (h = -h, _ = 0) : a == u.rm ? _ = 0 : a == u.lb ? h = -h : a == u.cb ? h = 0 : a == u.rb, this[e(359)](d, { dx: h, dy: _ }, a);
  }
  adjustFixedDirection(x, e, t) {
    const n = X;
    let s = Te[t], a = x[n(342)](s);
    a = x[n(360)](a), x[n(343)](e.dx, e.dy);
    let i = x[n(342)](s);
    i = x.transformPoint(i);
    let o = a.x - i.x, d = a.y - i.y;
    x[n(374)](o, d), this[n(355)][n(340)]();
  }
}
function b0(r, x) {
  const e = O0();
  return b0 = function(t, n) {
    return t = t - 338, e[t];
  }, b0(r, x);
}
const n0 = o0;
function o0(r, x) {
  const e = M0();
  return o0 = function(t, n) {
    return t = t - 334, e[t];
  }, o0(r, x);
}
(function(r, x) {
  const e = o0, t = r();
  for (; []; )
    try {
      if (-parseInt(e(356)) / 1 * (-parseInt(e(344)) / 2) + -parseInt(e(358)) / 3 * (parseInt(e(345)) / 4) + parseInt(e(368)) / 5 * (parseInt(e(369)) / 6) + parseInt(e(372)) / 7 * (parseInt(e(349)) / 8) + -parseInt(e(370)) / 9 + parseInt(e(335)) / 10 * (-parseInt(e(340)) / 11) + parseInt(e(353)) / 12 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(M0, 591403);
function ve(r, x) {
  const e = o0;
  let t = x[e(336)], n = r[e(367)]("center");
  return n = r[e(339)]().point(n), Math[e(354)](t.y - n.y, t.x - n.x);
}
class Je extends we {
  constructor(x, e) {
    const t = o0;
    super(), this[t(350)] = !![], this[t(337)] = x, this[t(341)] = x.editor, this[t(371)] = this[t(341)].stage, this[t(363)] = this[t(371)][t(363)], this.css(g.nodeRotatePoint[t(360)]), this[t(342)](g[t(361)].width, g[t(361)][t(351)]), this[t(365)] = e;
  }
  [n0(366)]() {
    const x = n0;
    this.stage[x(355)](x(347));
  }
  mousedownHandler(x) {
    const e = n0;
    x[e(362)]();
    let t = this[e(371)];
    if (this[e(363)][e(359)]().length == 0)
      throw new Error(e(364));
    let s = t.inputSystem[e(348)];
    this[e(338)] = s.rotation, this.mouseInitAngle = ve(s, t);
  }
  mouseupHandler(x) {
    const e = n0;
    this[e(371)][e(355)](e(346)), x.preventDefault();
  }
  [n0(352)](x) {
    const e = n0;
    x.preventDefault();
    let t = this.parent, n = t[e(341)], s = n[e(371)];
    if (n[e(371)].selectedGroup.getNoChildrensObjects()[e(334)] == 0)
      throw new Error("selectedGroup.length is 0!");
    let o = s[e(336)][e(348)], d = ve(o, s) - this.mouseInitAngle;
    o[e(343)](this.elementInitAngle + d), t[e(357)]();
  }
}
function M0() {
  const r = ["222872KbhSiZ", "isNodeRotatePoint", "height", "mousedragHandler", "8542968IfHkdX", "atan2", "setCursor", "25EIDFgb", "updateSize", "9UHZYxV", "getNoChildrensObjects", "style", "nodeRotatePoint", "preventDefault", "selectedGroup", "selectedGroup.length is 0!", "name", "mousemoveHandler", "positionToLocalPoint", "49190dNOZyO", "6bXyerN", "1380996Wvcvdf", "stage", "7HqiqbV", "length", "2481790JlsGvr", "inputSystem", "nodeCtrlBox", "elementInitAngle", "getStageTransform", "22lEsiRW", "editor", "resizeTo", "rotate", "71494bhHWzD", "536108QdtnbY", "auto", "move", "pickedObject"];
  return M0 = function() {
    return r;
  }, M0();
}
const B = p0;
function p0(r, x) {
  const e = z0();
  return p0 = function(t, n) {
    return t = t - 100, e[t];
  }, p0(r, x);
}
(function(r, x) {
  const e = p0, t = r();
  for (; []; )
    try {
      if (-parseInt(e(109)) / 1 * (-parseInt(e(141)) / 2) + -parseInt(e(108)) / 3 + parseInt(e(115)) / 4 * (parseInt(e(119)) / 5) + -parseInt(e(139)) / 6 * (parseInt(e(125)) / 7) + -parseInt(e(104)) / 8 + parseInt(e(118)) / 9 * (parseInt(e(129)) / 10) + -parseInt(e(121)) / 11 * (-parseInt(e(100)) / 12) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(z0, 944123);
class Xe extends r0 {
  constructor(x, e = 0, t = 0, n = 1, s = 1) {
    const a = p0;
    super(null, e, t, n, s), this.zIndex = he.NodeCtrlBox, this[a(117)] = x, this[a(123)] = ![], this.hide();
  }
  [B(128)]() {
    const x = B;
    this.visible && this[x(113)]();
  }
  [B(106)]() {
  }
  mouseenterStageHandler() {
  }
  [B(134)](x) {
    const e = B;
    this[e(132)]();
    let t = x[e(111)](), n = this;
    t[e(130)]((s) => {
      const a = e;
      if (n[a(107)](s), s == a(110)) {
        let i = function() {
          return n[a(127)](u.ct);
        }, o = n[a(107)](a(110)), d = new U(null, o, i);
        d[a(136)](g[a(124)].rotateLineStyle), d[a(123)] = ![], n[a(135)](d);
      }
    });
  }
  [B(107)](x) {
    const e = B;
    let t;
    return x == e(110) ? t = new Je(this, x) : t = new Ze(this, x), this[e(135)](t), t;
  }
  [B(137)](x) {
    const e = B;
    if (x[e(112)] != !![])
      throw new Error(e(138));
    this.currNode !== null && this[e(134)](x), this[e(103)] = x, this[e(113)](), this.show();
  }
  [B(113)]() {
    const x = B;
    let e = this[x(103)];
    if (e == null || e.isSelected == ![] || e[x(131)] == null) {
      this[x(103)] = null, this[x(102)]();
      return;
    }
    this[x(114)](e), this[x(120)]();
  }
  [B(120)]() {
    const x = B;
    let e = this[x(105)]();
    for (var t = 0; t < e.length; t++) {
      let n = e[t];
      if (n instanceof U)
        continue;
      let s;
      n[x(116)] == x(110) ? (s = this[x(127)](u.ct), s.y -= g[x(124)][x(126)]) : s = this.positionToLocalPoint(n[x(116)]), n instanceof r0 && n[x(101)](s.x, s.y);
    }
  }
  [B(114)](x) {
    const e = B;
    let t = x[e(140)](), n = t[e(133)](x[e(127)](u[e(122)])), s = t[e(133)](x[e(127)](u.rm)), a = Math.atan2(s.y - n.y, s.x - n.x);
    t[e(110)](-a);
    let i = t[e(133)](x.positionToLocalPoint(u[e(122)])), o = t.point(x.positionToLocalPoint(u.rb)), d = (o.x - i.x) * 2, l = (o.y - i.y) * 2;
    this.resizeTo(d, l), this.rotate(a), this[e(101)](n.x, n.y);
  }
}
function z0() {
  const r = ["getStageTransform", "553276tBDgtu", "22056uJBMUa", "translateTo", "hide", "currNode", "7082376FqJgWq", "getChildren", "mouseoutStageHandler", "createCtrlPoint", "1892172DLLxpB", "5SwBEFQ", "rotate", "getCtrlPoints", "editable", "updateSize", "viewClone", "60KFCEjS", "name", "editor", "16209CqrfrR", "159840BNTwtm", "initPoints", "5544PxGewZ", "center", "mouseEnabled", "nodeRotatePoint", "7Pvkosb", "rotateLineLength", "positionToLocalPoint", "update", "910FLCbVF", "forEach", "parent", "removeAllChild", "point", "initCtrlPoint", "addChild", "css", "attachTo", "attach not Node or not editable", "2956854hGYugl"];
  return z0 = function() {
    return r;
  }, z0();
}
const z = _0;
(function(r, x) {
  const e = _0, t = r();
  for (; []; )
    try {
      if (-parseInt(e(223)) / 1 * (-parseInt(e(225)) / 2) + parseInt(e(199)) / 3 * (-parseInt(e(203)) / 4) + parseInt(e(240)) / 5 + parseInt(e(245)) / 6 * (parseInt(e(227)) / 7) + parseInt(e(204)) / 8 * (parseInt(e(198)) / 9) + -parseInt(e(242)) / 10 + -parseInt(e(208)) / 11 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(N0, 491826);
function N0() {
  const r = ["101007VqBHaj", "687993uRnCKi", "corosshair", "ctrlPoint1", "s_resize", "4XyhcUc", "504NYrkql", "mouseupHandler", "fold2", "move", "12468159keZoBU", "isDragStart", "setCenterOffset", "mousedownHandler", "inputSystem", "isActive", "style", "setCursor", "w_resize", "points", "fold1", "unActive", "setRadius", "positionToLocalPoint", "mousedragHandler", "1772GpkLGf", "ctrlPoint2", "142FIHoZg", "attachedLink", "14zomnlM", "getConnectInfo", "anchorBox", "preventDefault", "linkCtrlPoint", "name", "end", "setFold2Offset", "center", "setBegin", "upgradeParent", "active", "linkCtrlBox", "3448330hxtKgT", "mousemoveHandler", "5916570snqUOs", "setFold1Offset", "begin", "2771268mkaTxO", "hide", "parent", "editor", "resetOffset", "ctrlPoint", "activeStyle", "target", "n_resize", "stage", "setEnd", "getEndPoint", "e_resize", "getK", "stageToLocalXY", "css", "canConnectEndpoint"];
  return N0 = function() {
    return r;
  }, N0();
}
function _0(r, x) {
  const e = N0();
  return _0 = function(t, n) {
    return t = t - 194, e[t];
  }, _0(r, x);
}
class $e extends we {
  constructor(x) {
    const e = _0;
    super(), this.isConnectPoint = !![], this[e(213)] = ![], this[e(220)](7), this[e(239)] = x, this[e(248)] = this[e(239)][e(248)], this[e(196)](g[e(231)][e(214)]);
  }
  [z(238)]() {
    const x = z;
    this[x(196)](g[x(231)][x(251)]), this[x(213)] = !![];
  }
  [z(219)]() {
    const x = z;
    this[x(196)](g[x(231)].unactiveStyle), this[x(213)] = ![];
  }
  [z(241)]() {
    const x = z;
    this[x(248)][x(229)][x(246)](), this[x(248)][x(254)][x(215)](M[x(207)]);
    let e = this[x(247)], t = this.editor[x(254)], n = e[x(226)];
    if (n instanceof a0) {
      let s = null, a = n[x(217)][0], i = n.points[1], o = n[x(217)][4], d = n[x(217)][5];
      this.name == u[x(218)] ? be(n[x(194)](0, 0.5)) ? s = i.x > a.x ? M[x(216)] : M[x(257)] : s = i.y > a.y ? M[x(202)] : M[x(253)] : this[x(232)] == u[x(206)] ? be(n[x(194)](4, 0.5)) ? s = o.x > d.x ? M[x(216)] : M[x(257)] : s = o.y > d.y ? M[x(202)] : M[x(253)] : this.name == u[x(235)] && (be(n[x(194)](2, 0.5)) ? s = M.s_resize : s = M[x(257)]), s && t[x(215)](s);
    }
  }
  [z(211)](x) {
    const e = z;
    this[e(248)][e(254)][e(215)](M[e(200)]), this[e(197)] = null;
  }
  [z(222)](x) {
    const e = z;
    x.event[e(230)]();
    let t = this.parent, n = t[e(247)], s = n[e(254)];
    const a = s[e(248)];
    let i = t[e(226)];
    a[e(229)].hide();
    const o = this[e(232)];
    let d = i[e(195)](s[e(212)].x, s.inputSystem.y);
    if (x[e(209)] && (o === u.begin || o === u.end) && this[e(238)](), o == u[e(244)]) {
      let l = i.getBeginPoint();
      l.x += d.x - l.x, l.y += d.y - l.y, i instanceof a0 && i.resetOffset(), i.setBegin(l), this[e(197)] = a[e(229)][e(228)](i, null, null);
    } else if (o == u[e(233)]) {
      let l = i[e(256)]();
      l.x += d.x - l.x, l.y += d.y - l.y, i instanceof a0 && i[e(249)](), i[e(255)](l), this[e(197)] = a[e(229)][e(228)](i, null, null);
    }
    if (i instanceof Oe)
      this.name == u[e(250)] && (i[e(250)] == null ? i[e(250)] = i[e(221)](o) : (i.ctrlPoint.x += d.x - i[e(250)].x, i[e(250)].y += d.y - i[e(250)].y));
    else if (i instanceof Me)
      o == u.ctrlPoint1 ? i.ctrlPoint1 == null ? i[e(201)] = i[e(221)](o) : (i[e(201)].x += d.x - i.ctrlPoint1.x, i[e(201)].y += d.y - i[e(201)].y) : o == u.ctrlPoint2 && (i[e(224)] == null ? i.ctrlPoint2 = i[e(221)](o) : (i.ctrlPoint2.x += d.x - i.ctrlPoint2.x, i[e(224)].y += d.y - i[e(224)].y));
    else if (i instanceof a0) {
      if (o == u.fold1) {
        let l = i[e(221)](u[e(218)]);
        const f = d.x - l.x, h = d.y - l.y;
        i[e(243)](f, h);
      } else if (o == u.center) {
        let l = i[e(221)](u[e(235)]);
        const f = d.x - l.x, h = d.y - l.y;
        i[e(210)](f, h);
      } else if (o == u[e(206)]) {
        let l = i[e(221)](u[e(206)]);
        const f = d.x - l.x, h = d.y - l.y;
        i[e(234)](f, h);
      }
    }
  }
  [z(205)](x) {
    const e = z;
    x.event.preventDefault(), this.isActive && this[e(219)]();
    let t = this[e(247)], n = t.attachedLink;
    if (this[e(197)] != null) {
      let s = this[e(197)], a = s[e(252)];
      if (a.isLink) {
        let i = a;
        i[e(233)][e(252)] !== n && i.begin[e(252)] !== n && (this[e(232)] == u[e(244)] ? n[e(236)](i, s) : this[e(232)] == u[e(233)] && n[e(255)](i, s), n[e(237)]());
      } else
        this[e(232)] == u.begin ? n[e(236)](a, s) : this[e(232)] == u[e(233)] && n[e(255)](a, s), n.upgradeParent();
      this[e(197)] = null;
    }
  }
}
function g0(r, x) {
  const e = j0();
  return g0 = function(t, n) {
    return t = t - 192, e[t];
  }, g0(r, x);
}
const H = g0;
(function(r, x) {
  const e = g0, t = r();
  for (; []; )
    try {
      if (-parseInt(e(203)) / 1 + -parseInt(e(223)) / 2 * (-parseInt(e(246)) / 3) + parseInt(e(231)) / 4 + -parseInt(e(211)) / 5 + parseInt(e(229)) / 6 + -parseInt(e(195)) / 7 + -parseInt(e(220)) / 8 * (parseInt(e(233)) / 9) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(j0, 205093);
class ex extends r0 {
  constructor(x) {
    const e = g0;
    super(), this[e(218)] = {}, this[e(201)] = he[e(212)], this[e(196)] = x, this.ctrlPointStyle = new ze({}), this[e(200)]();
  }
  [H(204)]() {
  }
  [H(228)]() {
  }
  [H(225)](x) {
    const e = H;
    let t = new $e(this);
    return t[e(217)] = x, this.addChild(t), t;
  }
  init() {
    const x = H;
    this.ctrlPointInfo = {}, this[x(197)]();
  }
  [H(226)](x) {
    this[H(206)] != ![] && this.updateSize();
  }
  [H(240)]() {
    const x = H, e = this[x(196)][x(199)][x(193)][x(234)];
    this[x(241)] ? this.attachedLink[x(232)] == null || e == null || this[x(241)] != e ? (this[x(241)] = null, this[x(197)]()) : this[x(227)](this.attachedLink) : this[x(197)]();
  }
  updateCtrlPoints(x) {
    const e = H;
    this[e(241)] = x;
    let t = x[e(216)]();
    this.anchorNameStr = t[e(205)](",");
    for (let n = 0; n < t.length; n++) {
      let s = t[n], a = this[e(218)][s];
      if (a == null) {
        if (a = this[e(225)](s), s != u.begin && s != u.end && (a.fillColor = this.ctrlPointStyle[e(208)], a[e(213)](g[e(244)][e(194)]), a.isConnectPoint = ![]), s == e(221)) {
          let i = new U();
          i.css(g.linkCtrlPoint[e(209)]), i[e(198)](a, e(214));
          let o = this[e(218)][e(215)];
          i[e(239)](o, e(214)), this.addChild(i), this[e(218)][s + e(245)] = i;
        } else if (s == e(219)) {
          let i = new U();
          i[e(213)](g.linkCtrlPoint[e(209)]), i.setBegin(a, "center");
          let o = this[e(218)][e(238)];
          i.setEnd(o, e(214)), this[e(230)](i), this[e(218)][s + e(245)] = i;
        } else if (s == e(235)) {
          let i = new U();
          i[e(213)](g[e(244)][e(209)]), i[e(198)](a, "center");
          let o = this.ctrlPointInfo[e(215)];
          i[e(239)](o, "center"), this.addChild(i), this[e(218)][s + e(245)] = i;
        }
        this[e(218)][s] = a;
      }
    }
  }
  [H(224)]() {
    const x = H;
    let e = this.ctrlPointInfo;
    for (var t in e)
      e[t][x(197)]();
  }
  updateFllow() {
    const x = H, e = this[x(241)];
    let t = e[x(243)](), n = e[x(216)]();
    this[x(224)]();
    for (let s = 0; s < n.length; s++) {
      const a = n[s];
      let i = this[x(218)][a], o = e[x(192)](a);
      Fe(o, e, a);
      let d = t[x(236)](o);
      i[x(207)](d.x, d.y), i[x(242)]();
      let l = this[x(218)][a + x(245)];
      l && l.show();
    }
  }
  attachTo(x) {
    const e = H;
    if (x[e(232)] != null) {
      if (this.attachedLink === x) {
        x instanceof a0 && x[e(216)]()[e(205)](",") != this[e(210)] && this[e(202)](x), this[e(237)](), this.show();
        return;
      }
      this[e(218)] = {}, this[e(222)](), this[e(202)](x), this.updateFllow(), this[e(242)]();
    }
  }
}
function j0() {
  const r = ["createNodeResizePoint", "draw", "attachTo", "mouseenterStageHandler", "2041518Wzkkpr", "addChild", "1223076JZSbLV", "parent", "44127bBQlyu", "pickedObject", "ctrlPoint", "point", "updateFllow", "end", "setEnd", "updateSize", "attachedLink", "show", "getStageTransform", "linkCtrlPoint", "Link", "347907vFnbTD", "positionToLocalPoint", "inputSystem", "adjustStyle", "1770587nrusXY", "editor", "hide", "setBegin", "stage", "init", "zIndex", "updateCtrlPoints", "79970Myhlnh", "mouseoutStageHandler", "join", "visible", "translateTo", "background", "ctrlLinkStyle", "anchorNameStr", "1021875qApZnK", "LinkCtrlBox", "css", "center", "begin", "getAnchorPoints", "name", "ctrlPointInfo", "ctrlPoint2", "32bNQgVg", "ctrlPoint1", "removeAllChild", "2JHTYty", "hideAllPoint"];
  return j0 = function() {
    return r;
  }, j0();
}
const T = c0;
function c0(r, x) {
  const e = G0();
  return c0 = function(t, n) {
    return t = t - 231, e[t];
  }, c0(r, x);
}
(function(r, x) {
  const e = c0, t = r();
  for (; []; )
    try {
      if (parseInt(e(281)) / 1 * (-parseInt(e(239)) / 2) + parseInt(e(231)) / 3 * (parseInt(e(274)) / 4) + -parseInt(e(271)) / 5 * (parseInt(e(249)) / 6) + -parseInt(e(286)) / 7 + parseInt(e(254)) / 8 + parseInt(e(270)) / 9 + -parseInt(e(233)) / 10 * (-parseInt(e(265)) / 11) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(G0, 448837);
function G0() {
  const r = ["inputSystem", "resizeTo", "mouseenterHandler", "closePath", "8866cjwRNc", "hide", "showTip", "buttons", "radius", "5285567Isicho", "instanceManager", "画线开始", "mousedownHandler", "anchorPoint", "activeStyle", "assert", "end", "gray", "intersectNode", "300VSScHN", "unactive", "10YVLXdf", "record", "getConnectInfo", "parent", "isActive", "link", "58mwetke", "arc", "width", "unActiveStyle", "name", "upgradeParent", "event", "lineDrawingFinished", "css", "mouseoutHandler", "1550676uUpCdm", "auto", "setEnd", "active", "height", "4840208OtooeY", "editor", "endpoint", "show", "mousedragHandler", "stage", "anchorBox", "lineDrawn", "isDragEnd", "draw", "mouseupHandler", "6336957QhAuOq", "isDragStart", "mousePickupPath", "intersect", "setCursor", "1793385lJSdPz", "5HhiVQJ", "target", "segIndex", "13564dvBhRl", "update", "mouseEnabled"];
  return G0 = function() {
    return r;
  }, G0();
}
class ye extends we {
  constructor(x, e = 0, t = 0, n = 1, s = 1) {
    const a = c0;
    super(null, e, t, n, s), this[a(237)] = ![], this.anchorBox = x, this[a(255)] = x[a(255)], this[a(259)] = this[a(255)][a(259)], this[a(278)](g[a(290)][a(241)], g[a(290)][a(253)]), this.unactive(), this.css({ lineWidth: 1, strokeStyle: a(294) });
  }
  setIntersect(x) {
    const e = c0;
    this[e(268)] = x;
  }
  [T(279)](x) {
    this[T(252)]();
  }
  [T(248)](x) {
    this[T(232)]();
  }
  [T(289)](x) {
    const e = T;
    x.preventDefault(), this[e(255)][e(283)](e(288)), this[e(255)][e(259)].setCursor("crosshair"), this.link = null;
  }
  [T(258)](x) {
    const e = T;
    if (x[e(284)] == 2)
      return;
    x[e(245)].preventDefault(), this[e(255)][e(259)][e(269)](e(250));
    const t = this.editor, n = t[e(259)];
    this[e(282)]();
    const s = this[e(260)].target;
    if (x[e(266)]) {
      let a = function() {
        const d = e;
        return o[d(236)].stageToLocalXY(n[d(277)].x, n.inputSystem.y);
      };
      console[e(292)](this.link == null, this[e(238)]);
      let i;
      if (this[e(243)] == e(295)) {
        let d = this[e(260)].intersect;
        i = new De(s, d.rate, d[e(273)]);
      } else
        i = new Le(s, this[e(243)]);
      this[e(255)][e(234)]("划线");
      const o = t.instanceManager[e(261)](null, s, null, i);
      this[e(238)] = o, o[e(251)](a);
      return;
    }
    Fe(this[e(238)].end, this.link), this.endpoint = this[e(260)][e(235)](this.link, s, this.link[e(293)][e(272)]);
  }
  [T(264)](x) {
    const e = T;
    if (x[e(262)] != ![]) {
      if (this[e(257)](), this[e(255)][e(275)](), this.editor[e(259)][e(269)](e(250)), this[e(238)] != null) {
        let t, n;
        if (this.endpoint != null)
          this[e(238)].mouseEnabled = !![], t = this.endpoint, n = this[e(256)];
        else {
          let s = this[e(238)][e(293)];
          s instanceof Ne && (t = s.fn(), this[e(238)][e(276)] = !![]);
        }
        t && (this[e(238)][e(251)](t, n), this.link[e(244)](), this[e(255)].recordEnd("划线"), this[e(255)][e(287)][e(246)](this.link));
      }
      this.link = null;
    }
  }
  [T(263)](x) {
    const e = T;
    this[e(285)] = Math.min(this.width * 0.5, this[e(253)] * 0.5), x.beginPath();
    let t = this[e(241)] / 2, n = this[e(253)] / 2;
    x[e(240)](t, n, this[e(285)], 0, je), x[e(280)](), this.strokeAndFill(x), this[e(267)](x);
  }
  active() {
    const x = T;
    this[x(237)] = !![], this[x(247)](g.anchorPoint[x(291)]);
  }
  unactive() {
    const x = T;
    this[x(237)] = ![], this[x(247)](g[x(290)][x(242)]);
  }
}
function R0() {
  const r = ["intersectNode", "141770oQJRCk", "ctrlIntersectNode", "isKeydown", "update", "mouseoutStageHandler", "active", "hide", "anchorDist", "forEach", "inputSystem", "getCurrentLayer", "Control", "length", "381fPKuyA", "mouseEnabled", "_findChildren", "unactive", "currentLayer", "segIndex", "clearTarget", "createAnchorPoint", "1265908bPaIQU", "translateTo", "showIntersectAnchor", "9260gahasW", "1316088SFCXNw", "getStageTransform", "addChild", "show", "activeStyle", "anchorBox", "5550930iqgoVL", "1796064YtqikA", "90wbFmSh", "editor", "none", "mouseenterStageHandler", "stage", "rate", "parent", "fold2", "getObjectsIntersect", "375170WwCXIf", "object", "getAnchorPoints", "nodeDist", "setTarget", "1cUNJdw", "children", "target", "name", "point", "getLocalPoint", "activePoint", "anchorPoint", "removeAllChild", "getConnectInfo"];
  return R0 = function() {
    return r;
  }, R0();
}
const D = I0;
function I0(r, x) {
  const e = R0();
  return I0 = function(t, n) {
    return t = t - 139, e[t];
  }, I0(r, x);
}
(function(r, x) {
  const e = I0, t = r();
  for (; []; )
    try {
      if (-parseInt(e(181)) / 1 * (parseInt(e(176)) / 2) + parseInt(e(147)) / 3 * (-parseInt(e(158)) / 4) + parseInt(e(192)) / 5 * (parseInt(e(167)) / 6) + -parseInt(e(155)) / 7 + -parseInt(e(166)) / 8 + parseInt(e(159)) / 9 + parseInt(e(165)) / 10 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(R0, 239693);
class xx extends r0 {
  constructor(x, e = 0, t = 0, n = 1, s = 1) {
    const a = I0;
    super(null, e, t, n, s), this.anchorDist = g.anchorBox[a(141)], this[a(168)] = x;
  }
  [D(196)]() {
  }
  [D(170)]() {
  }
  clearTarget() {
    const x = D;
    this.target = null, this[x(189)](), this[x(140)]();
  }
  [D(180)](x, e) {
    const t = D;
    if (this[t(183)] !== x) {
      if (this[t(183)] = x, this[t(189)](), x != null) {
        let s = x[t(178)]();
        for (var n = 0; n < s[t(146)]; n++) {
          let a = s[n];
          x instanceof a0 && (a == "fold1" || a == t(174)) || this[t(154)](a);
        }
        this.ctrlIntersectNode = this.createAnchorPoint("intersectNode"), this[t(193)][t(140)]();
      }
      this.update();
    }
    this[t(187)](e);
  }
  [D(187)](x) {
    const e = D;
    this[e(182)][e(142)]((n) => {
      const s = e;
      n[s(184)] == x ? n[s(139)]() : n[s(150)]();
    }), this[e(193)][e(140)](), this[e(162)]();
  }
  [D(157)](x) {
    const e = D;
    if (this.intersect = x, x == null) {
      this[e(193)][e(140)]();
      return;
    }
    let t = x.rate, n = x.segIndex;
    const s = this.target;
    let a = s[e(186)](t, n), o = s[e(160)]()[e(185)](a);
    this.ctrlIntersectNode[e(156)](o.x, o.y), this[e(193)].css(g[e(188)][e(163)]), this[e(193)][e(162)]();
  }
  [D(195)]() {
    const x = D;
    if (this[x(183)] == null || this[x(183)][x(173)] == null) {
      this[x(153)]();
      return;
    }
    const e = this.target, t = e.getStageTransform(), n = this[x(182)];
    for (let s = 0; s < n[x(146)]; s++) {
      const a = n[s];
      if (a.name != x(191)) {
        let i = e.positionToLocalPoint(a[x(184)]), o = t[x(185)](i);
        a[x(156)](o.x, o.y);
      }
    }
  }
  [D(154)](x) {
    const e = D, t = new ye(this);
    return t[e(184)] = x, t[e(164)] = this, this[e(161)](t), t;
  }
  getObjectsIntersect(x) {
    const e = D;
    let t = this.editor.stage, n = this[e(168)][e(144)](), s = { x: t.inputSystem.x, y: t[e(143)].y };
    return Ge(n, s, x, g[e(164)][e(179)]);
  }
  [D(190)](x, e, t) {
    const n = D, s = this[n(168)], a = this, i = s[n(171)], o = { x: i.inputSystem.x, y: i[n(143)].y }, d = s[n(151)], l = s.keyboard[n(194)](n(145)), f = (L) => L !== x && L !== t && L[n(148)] && L.connectable, h = d[n(149)](n(169), f, !![]), _ = Re(o, h, this[n(141)]);
    let O = null, j, E, q;
    if (_ != null)
      E = _[n(177)], q = _.anchorName, j = new Le(E, q), a.setTarget(E, q);
    else if (l) {
      const L = this[n(175)](h);
      L != null ? (E = L.object, a[n(180)](E, q), j = new De(E, L[n(172)], L[n(152)]), this[n(157)](L)) : a[n(153)]();
    } else
      a[n(153)]();
    return E != null && E !== x && E !== t && (O = j), O;
  }
}
const S = d0;
function d0(r, x) {
  const e = W0();
  return d0 = function(t, n) {
    return t = t - 396, e[t];
  }, d0(r, x);
}
(function(r, x) {
  const e = d0, t = r();
  for (; []; )
    try {
      if (parseInt(e(423)) / 1 * (parseInt(e(400)) / 2) + parseInt(e(416)) / 3 + -parseInt(e(408)) / 4 * (parseInt(e(414)) / 5) + parseInt(e(415)) / 6 * (-parseInt(e(398)) / 7) + parseInt(e(410)) / 8 * (-parseInt(e(399)) / 9) + parseInt(e(419)) / 10 * (parseInt(e(406)) / 11) + parseInt(e(407)) / 12 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(W0, 396352);
const tx = { cut: S(413), copy: "copy", delete: "删除", modify: "修改", addChild: S(420), pasteCopy: "辅助粘贴", pasteCut: S(425), resize: S(417), rotate: "旋转", dragNodeOrLink: S(424), modifyLink: S(401) };
class nx {
  constructor(x, e, t) {
    const n = S;
    this[n(411)] = x, this[n(426)] = t, this[n(396)] = e;
  }
  [S(422)]() {
    this.redoFn();
  }
  [S(404)]() {
    this.undoFn();
  }
}
class sx extends EventTarget {
  constructor(x) {
    const e = S;
    super(), this[e(421)] = x, this[e(405)] = [], this[e(403)] = [];
  }
  [S(402)](x, e, t) {
    const n = S;
    let s = new nx(x, e, t);
    return s[n(421)] = this[n(421)], this[n(403)].length = 0, this[n(405)].push(s), s;
  }
  [S(404)]() {
    const x = S;
    if (this[x(405)].length == 0)
      return null;
    let e = this[x(405)][x(418)]();
    return e[x(404)](), this[x(403)].push(e), e;
  }
  [S(422)]() {
    const x = S;
    if (this[x(403)][x(412)] == 0)
      return null;
    let e = this.redoHistory[x(418)]();
    return e[x(422)](), this[x(405)][x(402)](e), e;
  }
  [S(397)](x = 500) {
    let e = this;
    function t() {
      const n = d0;
      let s = e[n(404)]();
      e[n(421)].update(), s != null && setTimeout(t, x);
    }
    t();
  }
  [S(427)](x = 500) {
    let e = this;
    function t() {
      const n = d0;
      e[n(421)][n(409)](), e[n(422)]() != null && setTimeout(t, x);
    }
    t();
  }
}
function W0() {
  const r = ["push", "redoHistory", "undo", "undoHistory", "198gIvrby", "8346624YrzkqB", "345784RzYDIh", "update", "8hRswio", "type", "length", "cut", "20HvFMCy", "7074ACeaio", "1611657AirYJD", "尺寸修改", "pop", "21340FQzYxP", "添加图元", "editor", "redo", "2ZSPBSX", "位置改变", "剪切粘贴", "undoFn", "redoAll", "redoFn", "undoAll", "1806URTgKO", "6896079qThAqz", "541366xulzsa", "连线调整"];
  return W0 = function() {
    return r;
  }, W0();
}
function Y0() {
  const r = ["keys", "startsWith", "reverse", "12481010ZAgufH", "133064zwWpoK", "2401974HfgSoT", "12gZFhzt", "2036580ejLlvz", "457518EueQSf", "getAllVersions", "982615giIkgD", "203lylpcK", "length", "sort", "getItem", "filter", "1VOYnWM", "1638165CikaUy", "setItem"];
  return Y0 = function() {
    return r;
  }, Y0();
}
(function(r, x) {
  const e = e0, t = r();
  for (; []; )
    try {
      if (parseInt(e(141)) / 1 * (-parseInt(e(152)) / 2) + -parseInt(e(142)) / 3 + -parseInt(e(151)) / 4 + -parseInt(e(154)) / 5 * (parseInt(e(150)) / 6) + parseInt(e(155)) / 7 * (parseInt(e(148)) / 8) + parseInt(e(149)) / 9 + parseInt(e(147)) / 10 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(Y0, 320339);
function e0(r, x) {
  const e = Y0();
  return e0 = function(t, n) {
    return t = t - 141, e[t];
  }, e0(r, x);
}
const Se = { getItem: function(r) {
  const x = e0;
  return localStorage[x(158)](r);
}, setItem: function(r, x) {
  localStorage.setItem(r, x);
}, saveWithVersion(r, x) {
  const e = e0;
  r += Date.now(), this[e(143)](r, x);
}, getAllVersions(r) {
  const x = e0;
  return Object[x(144)](localStorage)[x(159)]((t) => t[x(145)](r))[x(157)]();
}, getLastVersion(r, x) {
  const e = e0;
  let t = this[e(153)](r)[e(146)]();
  if (t[e(156)] == 0)
    return;
  x == null && (x = 0), x + 1 >= t.length && (x = t[e(156)] - 1);
  let n = t[x];
  return this[e(158)](n);
} };
function q0() {
  const r = ["filter", "16nmFVCC", "showOpTooltip", "pickedObject", "selectedGroup", "862113hiOggb", "65974DbNzzb", "4956921wxfKcN", "addAll", "725550BFHPoJ", "preventDefault", "slice", "length", "objects", "stage", "749064kiDsEK", "40758UnKGnP", "690656hSSemF", "选编组-", "bindKey", "9RzFyUQ", "removeAll"];
  return q0 = function() {
    return r;
  }, q0();
}
(function(r, x) {
  const e = i0, t = r();
  for (; []; )
    try {
      if (-parseInt(e(507)) / 1 + parseInt(e(517)) / 2 * (parseInt(e(499)) / 3) + -parseInt(e(496)) / 4 + parseInt(e(510)) / 5 + -parseInt(e(516)) / 6 + -parseInt(e(506)) / 7 * (parseInt(e(502)) / 8) + parseInt(e(508)) / 9 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(q0, 147216);
function i0(r, x) {
  const e = q0();
  return i0 = function(t, n) {
    return t = t - 496, e[t];
  }, i0(r, x);
}
function ax(r, x, e) {
  const t = i0, n = r.keyboard, s = r.KeysConfig.CreateGroup;
  let a = {};
  function i(l) {
    const f = i0;
    a[l] = r[f(515)][f(505)][f(514)][f(512)](), r[f(503)]("编组-" + l);
  }
  function o(l) {
    const f = i0;
    let h = a[l];
    if (h)
      return h = h[f(501)]((_) => _.parent !== null), h[f(513)] > 0 && (r[f(503)](f(497) + l), r[f(515)][f(505)][f(500)]()[f(509)](h), r[f(515)].inputSystem[f(504)] = h[0]), h;
  }
  function d(l) {
    o(l) && e.centerBy(x.selectedGroup.objects);
  }
  for (let l = 0; l <= 9; l++)
    n[t(498)](s + "+" + l, function(f) {
      f[t(511)](), i(l);
    }), n.bindKey("" + l, function(f) {
      f[t(511)](), o(l);
    }), n.bindKey("" + l + "+" + l, function(f) {
      f[t(511)](), d(l);
    });
}
const v0 = K0;
function V0() {
  const r = ["clipboardManager", "10RswajQ", "editorEventManager", "bindKey", "editor", "Shift", "Select_all", "Move_up", "32YDenyt", "update", "1556xifEPY", "notContains", "forEach", "keyup", "复制样式", "getNoChildrensObjects", "displayList", "Delete", "paste_Style", "redoUndoSys", "currentLayer", "Move_down", "keyboard", "Select_invert", "deleteHandler", "Cut", "Layout_grid", "粘贴样式", "KeysConfig", "styleCopyHandler", "2554425PANAml", "init", "726VGEAxu", "Save", "Undo", "filter", "stage", "imageToBase64", "openLasted", "layoutManager", "redo", "getAllVisiable", "Redo", "select", "Copy", "10600510CJNvMG", "30919lIexbJ", "selectedGroup", "60636RNBQdb", "21770pOhOsE", "showOpTooltip", "Move_left", "keydown", "977400NNPiGC", "Open", "isNode", "stylePasteHandler", "doGridLayout", "133066LkdmRv", "1925niEVHL", "cutHandler", "copyHandler"];
  return V0 = function() {
    return r;
  }, V0();
}
function K0(r, x) {
  const e = V0();
  return K0 = function(t, n) {
    return t = t - 123, e[t];
  }, K0(r, x);
}
(function(r, x) {
  const e = K0, t = r();
  for (; []; )
    try {
      if (parseInt(e(125)) / 1 * (-parseInt(e(182)) / 2) + -parseInt(e(177)) / 3 + -parseInt(e(134)) / 4 * (-parseInt(e(173)) / 5) + parseInt(e(156)) / 6 * (-parseInt(e(170)) / 7) + -parseInt(e(132)) / 8 * (parseInt(e(154)) / 9) + parseInt(e(169)) / 10 + -parseInt(e(183)) / 11 * (-parseInt(e(172)) / 12) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(V0, 977145);
v0(129);
class ix {
  constructor(x) {
    const e = v0;
    this[e(128)] = x, this.init();
  }
  [v0(155)]() {
    const x = v0, e = this[x(128)], t = e[x(160)], n = e[x(144)];
    let s = e.stage[x(146)];
    const a = e[x(152)];
    function i(o, d, l) {
      const f = x;
      o[f(136)]((h) => {
        s[f(127)](h, function(O) {
          d(O);
        }, l);
      });
    }
    i(a[x(141)], (o) => e[x(126)][x(148)](o)), i(a[x(149)], (o) => e[x(124)][x(184)](o)), i(a[x(168)], (o) => {
      const d = x;
      e.showOpTooltip("复制"), e[d(124)][d(123)](o);
    }), i(a.Paste, (o) => e[x(124)].pasteHandler(o)), i(a[x(158)], (o) => {
      const d = x;
      e.showOpTooltip("撤销"), e[d(143)].undo();
    }), i(a[x(166)], (o) => {
      const d = x;
      e.showOpTooltip("重做"), e[d(143)][d(164)](o);
    }), i(a[x(130)], (o) => {
      const d = x;
      e.showOpTooltip("全选"), t.select(n[d(165)]());
    }), i(a[x(147)], (o) => {
      const d = x;
      e.showOpTooltip("反选");
      let l = t.selectedGroup[d(139)]();
      t[d(167)](n[d(140)][d(159)]((f) => l[d(135)](f)));
    }), i(a[x(157)], (o) => {
      const d = x;
      e.showOpTooltip("保存"), e.saveHandler(o, e[d(161)]);
    }, ![]), i(a[x(178)], (o) => {
      const d = x;
      e[d(174)]("打开"), e[d(162)](o);
    }, ![]), i(a.Copy_style, (o) => {
      const d = x;
      e[d(174)](d(138)), e[d(124)][d(153)](o);
    }, ![]), i(a[x(142)], (o) => {
      const d = x;
      e[d(174)](d(151)), e[d(124)][d(180)](o);
    }, ![]), i(a[x(175)], (o) => {
      const d = x;
      t[d(171)][d(139)]()[d(159)]((f) => f[d(179)])[d(136)]((f) => {
        f.x -= 1;
      });
    }), i(a.Move_right, (o) => {
      const d = x;
      t[d(171)].getNoChildrensObjects().filter((f) => f[d(179)]).forEach((f) => {
        f.x += 1;
      });
    }), i(a[x(131)], (o) => {
      const d = x;
      t[d(171)][d(139)]()[d(159)]((f) => f[d(179)])[d(136)]((f) => {
        f.y -= 1;
      });
    }), i(a[x(145)], (o) => {
      const d = x;
      t[d(171)][d(139)]()[d(159)]((f) => f[d(179)])[d(136)]((f) => {
        f.y += 1;
      });
    }), i(a[x(150)], (o) => {
      const d = x;
      e[d(163)][d(181)]();
    }), ax(e, t, n), s.on(x(176), function() {
      e[x(133)]();
    }), s.on(x(137), function(o) {
      e[x(133)]();
    });
  }
}
(function(r, x) {
  const e = Q0, t = r();
  for (; []; )
    try {
      if (parseInt(e(134)) / 1 * (parseInt(e(138)) / 2) + -parseInt(e(139)) / 3 * (parseInt(e(147)) / 4) + parseInt(e(110)) / 5 + parseInt(e(124)) / 6 * (-parseInt(e(142)) / 7) + -parseInt(e(136)) / 8 * (parseInt(e(123)) / 9) + parseInt(e(127)) / 10 * (-parseInt(e(135)) / 11) + -parseInt(e(143)) / 12 * (-parseInt(e(114)) / 13) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(U0, 575303);
function U0() {
  const r = ["上移一层", "editorEventManager", "774WwHsKR", "42YgOZkL", "zIndex", "pickedObject", "15720wtUfXI", "evenSpacing", "addEventListener", "copyHandler", "inputSystem", "左对齐", "deleteHandler", "520862NWcwRh", "7106EOznhw", "98976IHjxwN", "上下等距", "2HgNqDV", "160473TRZEcf", "移至底部", "垂直中心对齐", "914921rudAhu", "444wlkacm", "select", "item", "水平中心对齐", "4fvLgUD", "底部对齐", "cutHandler", "pasteHandler", "左右等距", "右对齐", "559530UxCbKu", "clipboardManager", "parent", "layoutManager", "1050699ZbFVgE", "setZIndex", "stage", "顶部对齐", "update", "updateZIndex", "align"];
  return U0 = function() {
    return r;
  }, U0();
}
function Q0(r, x) {
  const e = U0();
  return Q0 = function(t, n) {
    return t = t - 109, e[t];
  }, Q0(r, x);
}
let rx = `
<div class="header">编辑</div>
<a>剪切</a>
<a>复制</a>
<a>粘贴</a>
<a>删除</a> 
<hr></hr>
<div class="header">前后</div>
<a>上移一层</a>
<a>下移一层</a>
<a>移至顶部</a>
<a>移至底部</a>
<div class="header">对齐</div>
<a>左对齐</a>
<a>右对齐</a>
<a>顶部对齐</a>
<a>底部对齐</a>
<a>水平中心对齐</a>
<a>垂直中心对齐</a>
`;
function ox(r) {
  const x = Q0, e = r[x(116)];
  let t = new We(e, rx);
  return t[x(129)](x(144), function(n) {
    const s = x, a = n[s(145)];
    let i = e[s(131)][s(126)];
    a == "剪切" ? r[s(111)][s(149)]() : a == "复制" ? r[s(111)][s(130)]() : a == "粘贴" ? r[s(111)][s(150)]() : a == "删除" && r[s(122)][s(133)](), i != null && (a == s(121) || a == "下移一层" || a == "移至顶部" ? r[s(113)][s(115)](i, a) : a == s(140) ? r.layoutManager.setZIndex(i, a) : a == s(132) ? r[s(113)][s(120)](s(132)) : a == s(109) ? r.layoutManager.align("右对齐") : a == "顶部对齐" ? r[s(113)][s(120)](s(117)) : a == s(148) ? r.layoutManager[s(120)]("底部对齐") : a == s(146) ? r[s(113)][s(120)]("水平中心对齐") : a == "垂直中心对齐" ? r[s(113)][s(120)](s(141)) : a == s(151) ? r[s(113)][s(128)](s(151)) : a == s(137) && r[s(113)][s(128)](s(137)), i[s(125)] < 0 ? i.zIndex = 0 : i[s(125)] > 1e3 && (i[s(125)] = 1e3), i[s(112)] != null && i.parent[s(119)](), r[s(118)]());
  }), t;
}
const Q = y0;
function Z0() {
  const r = ["147156FaExaB", "width", "1060621HWwnzQ", "show", "css", "disable", "hideGuidLine", "2JYpMFy", "6876884BclymE", "editor", "hide", "addChild", "guildlineS", "setEnd", "_disabled", "11612920LrBynj", "guildlineW", "3063738Oqrodb", "setBegin", "guildLine", "9755496zJOkLK", "mouseEnabled", "handlerLayer", "52XNnPqn", "height", "491065kvcVHu", "init"];
  return Z0 = function() {
    return r;
  }, Z0();
}
(function(r, x) {
  const e = y0, t = r();
  for (; []; )
    try {
      if (-parseInt(e(233)) / 1 * (-parseInt(e(238)) / 2) + parseInt(e(231)) / 3 * (parseInt(e(227)) / 4) + parseInt(e(229)) / 5 + parseInt(e(248)) / 6 + -parseInt(e(239)) / 7 + -parseInt(e(246)) / 8 + parseInt(e(224)) / 9 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(Z0, 957050);
function y0(r, x) {
  const e = Z0();
  return y0 = function(t, n) {
    return t = t - 223, e[t];
  }, y0(r, x);
}
class cx {
  constructor(x) {
    const e = y0;
    this._disabled = ![], this[e(240)] = x, this.init();
  }
  [Q(230)]() {
    const x = Q, e = this[x(240)], t = new U();
    t[x(225)] = ![], t.css(g.guildLine.styleW), t[x(241)](), e.guildlineW = t, e.handlerLayer[x(242)](e.guildlineW);
    const n = new U();
    t[x(225)] = ![], n[x(235)](g[x(223)].styleS), n[x(241)](), e[x(243)] = n, e[x(226)][x(242)](e.guildlineS);
  }
  [Q(236)]() {
    const x = Q;
    this[x(245)] = !![];
  }
  enable() {
    const x = Q;
    this[x(245)] = ![];
  }
  showGuildLine(x) {
    const e = Q;
    if (this._disabled)
      return;
    const t = this[e(240)], n = t.stage, s = t[e(247)], a = t[e(243)];
    s[e(249)]({ x: 0, y: x.y }), s[e(244)]({ x: n[e(232)], y: x.y }), s[e(234)](), a.setBegin({ x: x.x, y: 0 }), a[e(244)]({ x: x.x, y: n[e(228)] }), a[e(234)]();
  }
  [Q(237)]() {
    const x = Q, e = this.editor;
    e[x(247)][x(241)](), e[x(243)][x(241)]();
  }
}
var $ = m0;
(function(r, x) {
  for (var e = m0, t = r(); []; )
    try {
      var n = parseInt(e(338)) / 1 + parseInt(e(345)) / 2 + -parseInt(e(346)) / 3 * (-parseInt(e(333)) / 4) + parseInt(e(336)) / 5 * (-parseInt(e(349)) / 6) + -parseInt(e(347)) / 7 + -parseInt(e(339)) / 8 * (-parseInt(e(342)) / 9) + parseInt(e(344)) / 10 * (-parseInt(e(341)) / 11);
      if (n === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(J0, 820220);
class pe {
  constructor() {
    var x = m0;
    this[x(343)] = 0;
  }
  [$(335)](x) {
    var e = $;
    this.take = 0, this.type = e(350), this[e(348)] = x;
  }
  [$(334)](x) {
    var e = $;
    this[e(343)] = -1, this[e(337)] = "cut", this[e(348)] = x;
  }
  takeSource() {
    var x = $;
    return this[x(343)]++, this[x(348)];
  }
  [$(340)]() {
    var x = $;
    return this[x(337)] == tx.cut && this[x(343)] == 0;
  }
}
function m0(r, x) {
  var e = J0();
  return m0 = function(t, n) {
    t = t - 333;
    var s = e[t];
    return s;
  }, m0(r, x);
}
function J0() {
  var r = ["1248208lRCBcD", "96RQIqDF", "isFirstCutPaste", "11DyTJXi", "1077030qeCzUT", "take", "21242290aapLjj", "2171968PPTNES", "9tCHhri", "9598743ePHiYB", "source", "1524BYODKd", "copy", "816696hsajUL", "cutPut", "copyPut", "1320HGgjgu", "type"];
  return J0 = function() {
    return r;
  }, J0();
}
(function(r, x) {
  for (var e = X0, t = r(); []; )
    try {
      var n = -parseInt(e(362)) / 1 * (-parseInt(e(361)) / 2) + -parseInt(e(370)) / 3 * (-parseInt(e(368)) / 4) + -parseInt(e(365)) / 5 + parseInt(e(369)) / 6 + -parseInt(e(364)) / 7 + -parseInt(e(367)) / 8 * (-parseInt(e(360)) / 9) + parseInt(e(363)) / 10;
      if (n === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})($0, 998878);
function X0(r, x) {
  var e = $0();
  return X0 = function(t, n) {
    t = t - 360;
    var s = e[t];
    return s;
  }, X0(r, x);
}
class R {
  constructor(x) {
    var e = X0;
    this[e(366)] = x;
  }
}
function $0() {
  var r = ["1481055VDyJPf", "27ucCtYP", "2oJkIKI", "1123973Lhvcqy", "7368480fEpLWI", "13559301HvelIv", "3950345fYfFlp", "type", "865456MNGpMc", "8lzLRjo", "3319518wMzPVv"];
  return $0 = function() {
    return r;
  }, $0();
}
const K = l0;
(function(r, x) {
  const e = l0, t = r();
  for (; []; )
    try {
      if (-parseInt(e(494)) / 1 + parseInt(e(473)) / 2 + -parseInt(e(503)) / 3 * (parseInt(e(477)) / 4) + -parseInt(e(481)) / 5 + -parseInt(e(486)) / 6 * (parseInt(e(467)) / 7) + parseInt(e(493)) / 8 + parseInt(e(459)) / 9 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(ee, 626734);
function ee() {
  const r = ["1821474SrWWam", "parent", "forEach", "copySetStyle", "2372XQCFDG", "translateWith", "map", "recordEnd", "5555615TCCgLt", "pickedObject", "stage", "record", "paste", "3486342NYQraR", "object", "cssClipBoard", "editor", "cutHandler", "concat", "pasteHandler", "5141864KMPDQo", "320107yOkAHG", "takeSource", "addChild", "clipboard", "objects", "isEmpty", "stylePasteHandler", "style", "className", "5274GOcwRd", "粘贴样式", "length", "19152405jgfqxm", "inputSystem", "currentLayer", "cutPut", "css", "dispatchEvent", "removeChild", "getNoChildrensObjects", "7qNvjxU", "selectedGroup", "getAABB", "stageToLocalXY", "cut", "serializerSystem"];
  return ee = function() {
    return r;
  }, ee();
}
function l0(r, x) {
  const e = ee();
  return l0 = function(t, n) {
    return t = t - 458, e[t];
  }, l0(r, x);
}
class dx {
  constructor(x) {
    const e = l0;
    this[e(488)] = new pe(), this[e(497)] = new pe(), this[e(488)] = new pe(), this[e(489)] = x;
  }
  copyHandler() {
    const x = l0;
    let e = this[x(489)][x(483)], t = [][x(491)](e[x(468)][x(466)]());
    if (t.length == 0)
      return;
    let n = t[x(479)]((a) => a.parent);
    this[x(497)].copyPut([t, n]);
    let s = new R("copy");
    s[x(487)] = t, this[x(489)][x(464)](s);
  }
  [K(490)]() {
    const x = K;
    let e = this[x(489)], t = e[x(483)], n = [][x(491)](t[x(468)][x(466)]());
    if (n[x(458)] == 0)
      return;
    let s = n.map((i) => i[x(474)]);
    this.clipboard[x(462)]([n, s]), e.record("剪切"), n[x(475)]((i, o) => {
      const d = x;
      s[o][d(465)](i), S0.disconnect(i, n);
    }), e.recordEnd("剪切"), t[x(460)][x(482)] = null, e.anchorBox.clearTarget();
    let a = new R(x(471));
    a.object = n, this.editor[x(464)](a);
  }
  [K(492)]() {
    const x = K;
    let e = this[x(489)], t = this.clipboard[x(495)]();
    if (t == null)
      return;
    let n = e[x(461)], s = e.stage, a = t[0], i = t[1], o = ge[x(469)](a, ![], k0), d = o.getCenter(), l = n[x(470)](s[x(460)].x, s.inputSystem.y), f = l.x - d.x, h = l.y - d.y;
    e[x(484)]("粘贴");
    let _ = a, O = s[x(472)].copyToPojo(a);
    _ = s.serializerSystem.pojoToObjects(O), _[x(475)]((E, q) => {
      E[x(478)](f, h);
    }), _.forEach((E, q) => {
      const L = x;
      i[q][L(496)](E);
    }), e[x(480)]("粘贴");
    let j = new R(x(485));
    j[x(487)] = _, this[x(489)][x(464)](j);
  }
  styleCopyHandler() {
    const x = K;
    let e = this[x(489)], t = e.stage, n = t[x(460)].pickedObject;
    n == null && (!t.selectedGroup[x(499)]() && (n = t[x(468)].objects[0]), n == null) || this.cssClipBoard.copyPut(n);
  }
  [K(500)]() {
    const x = K;
    let e = this[x(489)], t = this[x(488)].takeSource();
    if (t == null)
      return;
    let n = e[x(483)].selectedGroup[x(498)], s = this;
    e[x(484)](x(504)), n[x(475)]((a) => {
      s[x(476)](a, t);
    }), e.recordEnd(x(504));
  }
  [K(476)](x, e) {
    const t = K;
    x !== e && x[t(502)] === e[t(502)] && x[t(463)](e[t(501)]);
  }
}
const s0 = w0;
(function(r, x) {
  const e = w0, t = r();
  for (; []; )
    try {
      if (parseInt(e(382)) / 1 * (-parseInt(e(374)) / 2) + parseInt(e(392)) / 3 * (-parseInt(e(404)) / 4) + -parseInt(e(400)) / 5 * (-parseInt(e(386)) / 6) + parseInt(e(389)) / 7 * (-parseInt(e(377)) / 8) + parseInt(e(384)) / 9 + parseInt(e(387)) / 10 + -parseInt(e(380)) / 11 * (-parseInt(e(405)) / 12) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(xe, 848751);
function w0(r, x) {
  const e = xe();
  return w0 = function(t, n) {
    return t = t - 372, e[t];
  }, w0(r, x);
}
class lx extends r0 {
  constructor(x, e = 0, t = 0, n = 1, s = 1) {
    const a = w0;
    super(null, e, t, n, s), this.zIndex = he[a(403)], this.editor = x, this[a(376)](g.dropBox[a(396)]), this[a(373)] = ![], this.currObject, this[a(394)]();
  }
  [s0(399)]() {
    const x = s0;
    this[x(379)] && this[x(401)]();
  }
  attachTo(x) {
    const e = s0;
    if (x == null || x[e(385)] != !![]) {
      this[e(402)] = null, this[e(394)]();
      return;
    }
    if (x[e(391)])
      throw new Error(e(381));
    this[e(402)] = x, this[e(401)](), this[e(375)]();
  }
  updateSize() {
    const x = s0;
    this[x(402)] != null && this[x(383)](this.currObject);
  }
  [s0(383)](x) {
    const e = s0;
    let t = x[e(397)](), n = t[e(388)](x[e(398)](u[e(395)])), s = t.point(x.positionToLocalPoint(u.rm)), a = Math[e(393)](s.y - n.y, s.x - n.x);
    t.rotate(-a);
    let i = t[e(388)](x[e(398)](u[e(395)])), o = t[e(388)](x.positionToLocalPoint(u.rb)), d = (o.x - i.x) * 2, l = (o.y - i.y) * 2, f = 4;
    this[e(372)](d + f * 2, l + f * 2), this[e(378)](a), this[e(390)](n.x, n.y);
  }
}
function xe() {
  const r = ["visible", "1073611MVQexo", "attach not Node", "323670utSrGF", "viewClone", "9309888uxfaZL", "editable", "7494rhtgGX", "8395810wuUegP", "point", "122955fHmWAy", "translateTo", "isLink", "45QQZnwW", "atan2", "hide", "center", "style", "getStageTransform", "positionToLocalPoint", "update", "2535QslZKf", "updateSize", "currObject", "NodeCtrlBox", "426164npmDsw", "360LADgYC", "resizeTo", "mouseEnabled", "10YKQgYe", "show", "css", "624iDuRck", "rotate"];
  return xe = function() {
    return r;
  }, xe();
}
const N = te;
function te(r, x) {
  const e = ne();
  return te = function(t, n) {
    return t = t - 302, e[t];
  }, te(r, x);
}
(function(r, x) {
  const e = te, t = r();
  for (; []; )
    try {
      if (parseInt(e(304)) / 1 + -parseInt(e(313)) / 2 * (parseInt(e(318)) / 3) + parseInt(e(310)) / 4 + parseInt(e(321)) / 5 + parseInt(e(309)) / 6 + parseInt(e(317)) / 7 + parseInt(e(312)) / 8 * (-parseInt(e(306)) / 9) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(ne, 844419);
const fx = navigator.userAgent[N(316)]()[N(308)](N(314)) != -1;
function ne() {
  const r = ["ArrowDown", "Shift+v", "4790185jPSoaH", "Meta+Backspace", "Delete", "Shift", "112541fVfROS", "Control", "7201998stiuvA", "Shift+c", "indexOf", "7948686VSWsSt", "339212RNwvIO", "+shift+z", "32qTLrnU", "2tyJedl", "MAC OS", "Meta", "toUpperCase", "11504710qEPCAR", "235155jCdXQv"];
  return ne = function() {
    return r;
  }, ne();
}
const G = N(fx ? 315 : 305), Pe = { CtrlOrCmd: G, CreateGroup: G, DropTo_leader: N(303), Delete: [N(302), N(322)], Select_all: [G + "+a"], Select_invert: [G + "+i"], Cut: [G + "+x"], Copy: [G + "+c"], Paste: [G + "+v"], Save: [G + "+s"], Open: [G + "+o"], Undo: [G + "+z"], Redo: [G + N(311)], Copy_style: [N(307)], paste_Style: [N(320)], Move_up: ["ArrowUp"], Move_down: [N(319)], Move_left: ["ArrowLeft"], Move_right: ["ArrowRight"], Layout_tree: ["t"], Layout_grid: ["g"] };
(function(r, x) {
  const e = f0, t = r();
  for (; []; )
    try {
      if (parseInt(e(240)) / 1 * (-parseInt(e(234)) / 2) + -parseInt(e(229)) / 3 + parseInt(e(227)) / 4 + -parseInt(e(241)) / 5 * (parseInt(e(238)) / 6) + parseInt(e(221)) / 7 * (parseInt(e(223)) / 8) + -parseInt(e(237)) / 9 + parseInt(e(243)) / 10 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(se, 697247);
function Ee(r, x) {
  const e = f0;
  let t = r[e(236)], n = r.currentLayer[e(239)]()[e(232)]((i) => {
    const o = e;
    return i.visible && i[o(222)] && i.isSelected != !![] && i[o(224)];
  }), s = x[e(232)]((i) => {
    const o = e;
    return i[o(230)]() || i[o(242)] === t;
  }), a;
  for (let i = 0; i < s[e(226)]; i++) {
    let o = s[i];
    if (a = hx(o, n), a != null)
      break;
  }
  return a == null && (a = t, s = s[e(232)]((i) => i[e(242)] !== t)), console[e(228)](a[e(231)] != !![], !![], a), { parent: a, objects: s };
}
function f0(r, x) {
  const e = se();
  return f0 = function(t, n) {
    return t = t - 221, e[t];
  }, f0(r, x);
}
function se() {
  const r = ["56781BCOzeu", "isOutOfParent", "isLink", "filter", "getPaintedAABBInLayer", "63854dllZrR", "isIntersectRect", "currentLayer", "8239689ziBJLs", "321654japARq", "getAllVisiable", "7UURUgn", "115fTzplI", "parent", "28308760hmmuIw", "9863kLrzFJ", "isNode", "672rZLebp", "mouseEnabled", "addChild", "length", "555836hljsEy", "assert"];
  return se = function() {
    return r;
  }, se();
}
function hx(r, x) {
  const e = f0, t = r.getPaintedAABBInLayer(), n = x.filter((s) => s === r[f0(242)] || s === r ? ![] : r.isAncestors(s) ? ![] : !![]);
  for (let s = n[e(226)] - 1; s >= 0; s--) {
    const a = n[s];
    if (a[e(233)]()[e(235)](t))
      return a;
  }
  return null;
}
const F = ie;
(function(r, x) {
  const e = ie, t = r();
  for (; []; )
    try {
      if (parseInt(e(327)) / 1 + -parseInt(e(303)) / 2 + -parseInt(e(299)) / 3 * (-parseInt(e(352)) / 4) + -parseInt(e(389)) / 5 * (parseInt(e(294)) / 6) + -parseInt(e(365)) / 7 * (-parseInt(e(380)) / 8) + parseInt(e(316)) / 9 * (-parseInt(e(296)) / 10) + parseInt(e(351)) / 11 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(ae, 218568);
function ae() {
  const r = ["Control", "lineDrawingFinished", "crosshair", "733584vYrkAU", "toStageRect", "changeParent", "popupMenu", "update", "isDragEnd", "connectable", "hideGuidLine", "currObject", "getObjectsIntersect", "setTarget", "anchorBox", "onLinkCreate", "27XkDENt", "KeysConfig", "mousedown", "removeChild", "drawLineEnd", "showAt", "inputSystem", "dropToBox", "drawLineStart", "mouseOverTarget", "length", "114395qTgboY", "pickedObject", "setCursor", "selectedGroupDragHandler", "attachTo", "preventDefault", "isKeydown", "控制点", "record", "showGuildLine", "showIntersectAnchor", "mouseupHandler", "round", "1717171200000", "lineDrawn", "mouseoutStageHandler", "mousedownHandler", "instanceManager", "recordEnd", "button", "selectedGroupDragEndHandler", "auto", "parent", "hide", "6813741DhnnTW", "309104vLOmfq", "isNode", "init", "event", "isDragStart", "modeChange", "move", "nodeCtrlBox", "zoomAfter", "pickUpChild", "controlTarget", "对象拖拽", "currentLayer", "686dybYNv", "mousedragHandler", "DropTo_leader", "dispatchEvent", "stage", "dragover", "mouseup", "groupdragend", "aabb", "mouseoutHandler", "mouseenterStageHandler", "editor", "getNoChildrensObjects", "delete", "mouseOvertarget's parent is null", "19600GYgzna", "buttons", "defaultPrevented", "handlerLayer", "objects", "recordInterrupt", "linkCtrlBox", "getCurrentLayer", "keyboard", "16190JdwiEB", "editable", "Shift", "getCenter", "onlineDrawingFinishedHandler", "drop", "object", "addChild", "744bFyTDh", "selectedGroup", "1244780QMFstH", "dblclickHandler", "deleteHandler", "15CxhuWE"];
  return ae = function() {
    return r;
  }, ae();
}
const ux = ke.w != null ? ke.w.charAt(3) : "1";
function ie(r, x) {
  const e = ae();
  return ie = function(t, n) {
    return t = t - 288, e[t];
  }, ie(r, x);
}
class bx {
  constructor(x) {
    this.editor = x, this.init();
  }
  [F(354)]() {
    const x = F;
    let e = this[x(376)], t = e[x(369)], n = t.inputSystem, s = e[x(383)], a = parseInt(x(340));
    Date.now() > a || (t.on(C0[x(360)], function() {
      e[x(307)]();
    }), t.on(C0[x(357)], function(i) {
      const o = x;
      let d = i.newMode, l = e.nodeCtrlBox, f = e[o(386)], h = e.dropToBox, _ = e.anchorBox;
      d == Ye.edit ? (s[o(293)](l), s[o(293)](f), s[o(293)](_), s[o(293)](h)) : (s[o(319)](l), s[o(319)](f), s[o(319)](_), s[o(319)](h)), e[o(307)]();
    }), n.on(x(370), function(i) {
      const o = x;
      i.preventDefault(), e[o(368)](n);
    }), n.on(x(291), function() {
      const i = x;
      n[i(355)].defaultPrevented || e[i(368)](n);
    }), n.on(x(318), function(i) {
      const o = x;
      n[o(355)][o(382)] || e[o(306)][o(350)]();
    }), n.on(x(371), function(i) {
      const o = x;
      n[o(346)] == 2 ? !n.isDragEnd && e[o(306)][o(321)](n.x, n.y) : e[o(306)][o(350)]();
    }), t.selectedGroup.on(C0.groupdrag, function(i) {
      const o = x;
      e[o(330)](i, t[o(295)].getNoChildrensObjects());
    }), t[x(295)].on(C0[x(372)], function(i) {
      const o = x;
      e.selectedGroupDragEndHandler(i, t[o(295)].getNoChildrensObjects());
    }));
  }
  [F(298)]() {
    const x = F;
    let e = this[x(376)], t = e[x(369)], n = t[x(295)];
    if (ux != "1")
      return null;
    let s = n.getNoChildrensObjects();
    n.removeAll(), e[x(344)][x(378)](s);
    let a = new R(x(378));
    a[x(292)] = s, e.dispatchEvent(a);
  }
  [F(343)](x) {
    const e = F, t = this[e(376)], n = t[e(369)][e(322)];
    let s = t[e(383)], a = t[e(359)], i = t[e(386)];
    if (t[e(362)] = s[e(361)](), t[e(314)][e(350)](), t[e(362)] != null) {
      t[e(362)][e(343)](n), n.event.preventDefault(), t.update();
      return;
    }
    i.hide(), a.hide(), t[e(307)]();
  }
  mousewheelHandler(x) {
  }
  [F(297)](x) {
  }
  [F(338)](x) {
    const e = F, t = this.editor, n = t[e(369)][e(322)];
    t.guidlineManager[e(310)]();
    let s = t[e(369)], a = t[e(359)], i = t[e(386)], o = t[e(362)];
    if (o != null) {
      n[e(308)] && !(o instanceof ye) && t[e(345)](e(334)), o[e(338)](n), n[e(355)][e(332)](), t[e(307)]();
      return;
    }
    if (n[e(346)] == 2)
      return;
    let d = s[e(322)].pickedObject;
    d != null ? d.editable && (d instanceof U ? i[e(331)](d) : (t[e(314)].setTarget(d), a.attachTo(d))) : (t.anchorBox.hide(), a[e(350)](), i[e(350)]());
    {
      if (t[e(323)][e(311)] != null) {
        let f = t[e(295)][e(377)](), h = Ee(t, f), _ = h[e(349)];
        h[e(384)].forEach((j) => {
          j[e(305)](_), j.upgradeLinks();
        });
      }
      t[e(323)][e(331)](null);
    }
    t[e(307)]();
  }
  [F(366)](x) {
    const e = F, t = this[e(376)], n = t[e(369)][e(322)];
    if (n[e(381)] == 2)
      return;
    t[e(388)].isKeydown(e(288)) && t.stage.setCursor(e(302)), t.guidlineManager[e(336)](n);
    let s = t.controlTarget;
    if (s != null) {
      if (n.isDragStart && !(s instanceof ye) && t[e(335)](e(334)), s[e(366)](n), t[e(307)](), n[e(355)].defaultPrevented == !![])
        return;
      n[e(355)].preventDefault();
    }
    t[e(323)].hide();
    const a = t[e(317)][e(367)];
    if (t.stage[e(322)][e(328)] && t.keyboard[e(333)](a)) {
      let i = t[e(295)][e(377)](), o = Ee(t, i), d = o[e(349)];
      d != null && d[e(390)] && t[e(323)][e(331)](d);
    }
  }
  mousemoveHandler(x) {
    const e = F, t = this[e(376)];
    let n = t[e(369)];
    const s = n.handlerLayer;
    let a = t[e(364)];
    n.setCursor(e(348));
    let i = s[e(361)]();
    if (i !== t[e(325)] && (t[e(325)] != null && t[e(325)].mouseoutHandler(x), i != null && i.mouseenterHandler(x)), t.mouseOverTarget = i, i != null) {
      const d = i[e(349)];
      Fe(d, e(379)), i.mousemoveHandler(x), x[e(332)]();
      return;
    }
    let o = a.pickUpChild();
    if (o != null && (t[e(369)][e(329)](e(358)), o[e(353)] && o[e(309)] && t[e(314)][e(313)](o), t.keyboard[e(333)](e(300)) && o.connectable)) {
      t[e(314)][e(313)](o);
      const l = t[e(314)][e(312)]([o]);
      l != null && t[e(314)][e(337)](l);
    }
    t.update();
  }
  mouseenterHandler(x) {
    const e = F, t = this[e(376)];
    t[e(386)][e(375)](), t.nodeCtrlBox[e(375)](), t.anchorBox[e(375)]();
  }
  [F(374)](x) {
    const e = F, t = this[e(376)];
    t[e(386)][e(342)](), t[e(359)][e(342)](), t[e(314)][e(342)]();
  }
  onLineDrawnHandler(x) {
    const e = F, t = this[e(376)];
    if (t[e(315)])
      t[e(315)](x);
    else {
      let n = new R(e(341));
      n[e(292)] = x, t[e(368)](n), n = new R(e(324)), n[e(292)] = x, t.dispatchEvent(n);
    }
  }
  [F(290)](x) {
    const e = F, t = this.editor;
    let n = new R(e(301));
    n[e(292)] = x, t[e(368)](n), n = new R(e(320)), n[e(292)] = x, t[e(368)](n);
  }
  selectedGroupDragHandler(x, e) {
    const t = F, n = this.editor;
    if (n.stage.inputSystem[t(356)] && n.record(t(363)), e[t(326)] == 1) {
      const a = e[0], i = n[t(387)]()[t(304)](a._obb[t(373)]), o = i[t(289)]();
      n.guidlineManager.showGuildLine(o);
    }
  }
  [F(347)](x, e) {
    const t = F, n = this[t(376)];
    if (!n[t(369)].inputSystem.isMouseOn) {
      n[t(385)]();
      return;
    }
    e.forEach((a) => {
      const i = t;
      a.isNode && (a.x = Math.round(a.x), a.y = Math[i(339)](a.y));
    }), n.recordEnd(t(363));
  }
}
const Z = oe;
(function(r, x) {
  const e = oe, t = r();
  for (; []; )
    try {
      if (parseInt(e(358)) / 1 + parseInt(e(344)) / 2 + -parseInt(e(317)) / 3 + -parseInt(e(337)) / 4 + parseInt(e(356)) / 5 + -parseInt(e(324)) / 6 * (-parseInt(e(348)) / 7) + parseInt(e(352)) / 8 * (parseInt(e(343)) / 9) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(re, 570693);
function re() {
  const r = ["getCenter", "移至顶部", "doGridLayout", "8eUzTGJ", "resizeTo", "stage", "isAlone", "619160xRAQbH", "translate", "597730VpdPaW", "translateWith", "zIndex", "底部对齐", "shapeLayout", "getBottom", "移至底部", "getUnionRect", "ceil", "length", "1814622sDTAvz", "update", "doLayout", "setZIndex", "顶部对齐", "网格布局", "水平中心对齐", "1316262zjbdeS", "下移一层", "editor", "filter", "parent", "evenSpacing", "getRight", "getAABB", "selectedGroup", "align", "outerGrid", "isNode", "垂直中心对齐", "2556548NWSAHH", "sqrt", "updatezIndex", "getNoChildrensObjects", "layoutSystem", "左对齐", "1026747zqYiWF", "1519364ZTkDWJ", "showOpTooltip", "easeInQuart", "上移一层", "7VQKpbd"];
  return re = function() {
    return r;
  }, re();
}
function oe(r, x) {
  const e = re();
  return oe = function(t, n) {
    return t = t - 312, e[t];
  }, oe(r, x);
}
class px {
  constructor(x) {
    this.editor = x;
  }
  [Z(320)](x, e) {
    const t = Z;
    e == t(347) ? x.zIndex++ : e == t(325) ? x[t(360)]-- : e == t(350) ? x.zIndex = 1e3 : e == t(313) && (x[t(360)] = 0), x[t(328)][t(339)]();
  }
  [Z(329)](x) {
    const e = Z;
    let n = this.editor[e(354)].selectedGroup[e(340)]();
    n = n[e(327)]((s) => s[e(335)] || s[e(355)]()), n.length != 0 && ge[e(331)](n, ![], k0);
  }
  [Z(333)](x) {
    const e = Z, t = this[e(326)];
    let n = t[e(354)][e(332)].getNoChildrensObjects();
    if (n = n[e(327)]((a) => a[e(335)] || a[e(355)]()), n[e(316)] == 0)
      return;
    let s = ge[e(331)](n, ![], k0);
    for (let a = 0; a < n[e(316)]; a++) {
      let i = n[a], o = i[e(331)](![], k0);
      x == e(342) ? i[e(359)](s.x - o.x, 0) : x == "右对齐" ? i[e(359)](s.getRight() - o[e(330)](), 0) : x == e(321) ? i[e(359)](0, s.y - o.y) : x == e(361) ? i[e(359)](0, s[e(312)]() - o[e(312)]()) : x == e(323) ? i[e(359)](0, s[e(349)]().y - o[e(349)]().y) : x == e(336) && i[e(359)](s[e(349)]().x - o[e(349)]().x, 0);
    }
    t[e(318)]();
  }
  [Z(351)]() {
    const x = Z;
    let e = this[x(326)], t = e[x(354)], n = t[x(332)][x(340)]().filter((f) => f[x(335)]);
    if (n.length < 2)
      return;
    let s = Math[x(315)](Math[x(338)](n[x(316)])), a = qe[x(314)](n), i = a[x(349)](), o = Ve[x(334)](s, s), d = t[x(341)][x(362)](n, o), l = n[0].width * s;
    d[x(353)](l, l), d[x(357)](i.x, i.y), d[x(319)]({ effect: x(346), duration: 300 }), e[x(345)](x(322));
  }
}
const J = de;
(function(r, x) {
  const e = de, t = r();
  for (; []; )
    try {
      if (parseInt(e(294)) / 1 + parseInt(e(299)) / 2 + parseInt(e(313)) / 3 * (-parseInt(e(301)) / 4) + parseInt(e(305)) / 5 + -parseInt(e(290)) / 6 * (-parseInt(e(308)) / 7) + parseInt(e(310)) / 8 * (parseInt(e(316)) / 9) + parseInt(e(328)) / 10 * (-parseInt(e(306)) / 11) === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(ce, 861534);
function ce() {
  const r = ["recordEnd", "Node", "26103830VWgWcl", "assign", "stage", "isLink", "setMode", "newLinkProperties", "indexOf", "18CKRZXC", "lineDrawingFinished", "showOpTooltip", "mousedragHandler", "465234wIEwpT", "editor", "object", "forEach", "parent", "1422528MjCnaw", "isNode", "4tWXYMr", "create", "addNewInstance", "unknow classname:", "1547430anyzvN", "11OGHWsS", "mode", "3902843QPBbFk", "view", "88VyMVyT", "addChild", "zIndex", "2433831wFnzbe", "mouseEnabled", "getCurrentLayer", "920097uSihwt", "disconnect", "mouseY", "Link", "dispatchEvent", "css", "onlineDrawingFinishedHandler", "onLineDrawnHandler", "LinkClassName", "delete"];
  return ce = function() {
    return r;
  }, ce();
}
function de(r, x) {
  const e = ce();
  return de = function(t, n) {
    return t = t - 287, e[t];
  }, de(r, x);
}
class _x {
  constructor(x) {
    this.editor = x;
  }
  [J(325)](x) {
    const e = J;
    let t = this[e(295)];
    t.record("删除"), x.forEach(function(n) {
      S0[e(317)](n), n.removeFromParent();
    }), t[e(292)]("删除"), t[e(326)]("删除");
  }
  addNewInstance(x) {
    const e = J, t = this.editor;
    t[e(315)]()[e(311)](x);
    let s = new R(e(302));
    s[e(296)] = x, t[e(320)](s);
  }
  [J(302)](x) {
    const e = J, t = this.editor, n = t[e(330)], s = t[e(315)]();
    let a = { x: s.mouseX, y: s[e(318)] }, i = a.x, o = a.y, d = _e(x);
    if (x[e(289)](e(327)) != -1) {
      let l = new d(null, i, o, 64, 64);
      return this.addNewInstance(l), l;
    }
    if (x[e(289)](e(319)) != -1) {
      n[e(293)][e(307)] && n[e(287)](e(309));
      let l = new d(null, { x: i - 40, y: o }, { x: i + 40, y: o + (x == e(319) ? 0 : 80) });
      return this[e(303)](l), l;
    }
    throw new Error(e(304) + x);
  }
  lineDrawn(x, e, t, n) {
    const s = J;
    let a = this[s(295)], i = _e(a[s(324)]);
    const o = new i(x, e, t, n), d = Object[s(329)]({}, a[s(288)]);
    d[s(321)] && (o[s(321)](d.css), delete d[s(321)]), Object.keys(d)[s(297)]((h) => {
      let _ = d[h];
      typeof _ == "function" ? o[h] = _() : o[h] = _;
    });
    let f = e[s(300)] || e[s(331)] ? e[s(298)] : a.currentLayer;
    return o[s(312)] = he.EditorNewLink, f[s(311)](o), a.editorEventManager[s(323)](o), o[s(314)] = ![], o;
  }
  [J(291)](x) {
    const e = J;
    this.editor.editorEventManager[e(322)](x);
  }
}
const b = F0;
(function(r, x) {
  const e = F0, t = r();
  for (; []; )
    try {
      if (-parseInt(e(501)) / 1 * (-parseInt(e(477)) / 2) + -parseInt(e(440)) / 3 + -parseInt(e(496)) / 4 + parseInt(e(473)) / 5 + -parseInt(e(443)) / 6 * (-parseInt(e(454)) / 7) + -parseInt(e(445)) / 8 * (parseInt(e(437)) / 9) + parseInt(e(497)) / 10 === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(le, 783554);
function F0(r, x) {
  const e = le();
  return F0 = function(t, n) {
    return t = t - 426, e[t];
  }, F0(r, x);
}
function le() {
  const r = ["sendKey", "keyManager", "toJson", "mousedownHandler", "KeysConfig", "warn", "fadeOut", "fillByJson", "6648740FGGgjl", "selectedGroup", "assign", "LinkClassName", "2088376MiIjyG", "mousemoveHandler", "removeAllChild", "editorEventManager", "mouseoutHandler", "dropToBox", "controlTarget", "lastLayerState", "inputSystem", "dblclickHandler", "mouseOverTarget", "anchorBox", "getCurrentLayer", "restore", "push", "showTip", "currentLayer", "redoUndoSys", "editor", "1591740fsRBqs", "3463160UrCsxw", "domElement", "handlerLayer", "paddingLeft", "1HGbdbM", "openLasted", "mouseenterHandler", "keyboard", "width", "dispatchEvent", "mousedragHandler", "selectedGroupDragHandler", "topo_last_doc", "create", "toFileJson", "update", "imageToBase64", "AutoFoldLink", "showOpTooltip", "nodeCtrlBox", "paddingRight", "pickedObject", "object", "725733AjKqGv", "openJson", "newLink", "4374309dpvjnB", "msg", "mouseupHandler", "90708ViHgnB", "setHtml", "32JUCpZQ", "recordName", "save", "clipboardManager", "instanceManager", "log", "record和recordEnd没有成对出现", "mousewheelHandler", "20px", "112WxAtcG", "showAt", "stage", "serializerSystem", "selectedGroupDragEndHandler", "setLinkClassName", "defineKeys", "opTooltip", "getState", "open", "layoutManager"];
  return le = function() {
    return r;
  }, le();
}
class gx extends Ae {
  constructor(x) {
    const e = F0;
    super(), this[e(469)] = Pe, this.EditorConfig = g, this[e(476)] = e(431), this[e(430)] = ![], this[e(456)] = x, x[e(495)] = this, this[e(493)] = this[e(489)](), this[e(499)] = x[e(499)], this[e(474)] = this[e(456)][e(474)], this[e(504)] = x[e(504)], this[e(448)] = new dx(this), this[e(449)] = new _x(this), this[e(480)] = new bx(this), this[e(466)] = new ix(this), this[e(433)] = new Xe(this), this.linkCtrlBox = new ex(this), this[e(488)] = new xx(this), this[e(482)] = new lx(this), this.popupMenu = ox(this), this.stage[e(485)][e(435)] = null, this[e(483)] = null, this[e(487)] = null, this.inputTextfield = new Ke(this), this[e(494)] = new sx(this), this[e(464)] = new px(this), this.guidlineManager = new cx(this), this.opTooltip = new Ue(x), this[e(461)][e(498)].style[e(500)] = e(453), this[e(461)][e(498)].style[e(434)] = e(453);
  }
  [b(459)](x) {
    this.LinkClassName = x;
  }
  [b(489)]() {
    const x = b;
    return this.stage[x(489)]();
  }
  [b(460)](x) {
    const e = b;
    Object[e(475)](this[e(469)], x);
  }
  [b(432)](x) {
    const e = b;
    this[e(461)][e(444)](x), this[e(461)][e(455)](this[e(456)][e(505)] * 0.5, this[e(456)].height * 0.5), this[e(461)][e(471)](80);
  }
  saveHandler(x, e = ![]) {
    const t = b;
    let n = this[t(456)][t(457)][t(467)]([this[t(493)]], e);
    Se.setItem("topo_last_doc", n);
    const s = new R(t(447));
    s.object = n, s.imageToBase64 = e, this.dispatchEvent(s);
  }
  [b(502)]() {
    const x = b, e = this[x(493)], t = Se.getItem(x(426));
    t != null && (e[x(479)](), this[x(456)][x(457)][x(472)](e, t));
  }
  [b(486)](x) {
    this[b(480)].dblclickHandler(x);
  }
  [b(452)](x) {
    const e = b;
    this[e(480)][e(452)](x);
  }
  [b(468)](x) {
    const e = b;
    this[e(480)][e(468)](x);
  }
  [b(442)](x) {
    this.editorEventManager.mouseupHandler(x);
  }
  [b(507)](x) {
    const e = b;
    this.editorEventManager[e(507)](x);
  }
  [b(478)](x) {
    const e = b;
    this[e(480)][e(478)](x);
  }
  [b(503)](x) {
    const e = b;
    this[e(480)][e(503)](x);
  }
  [b(481)](x) {
    const e = b;
    this[e(480)][e(481)](x);
  }
  [b(508)](x, e) {
    const t = b;
    this[t(480)][t(508)](x, e);
  }
  [b(458)](x, e) {
    this[b(480)].selectedGroupDragEndHandler(x, e);
  }
  recordInterrupt() {
    const x = b;
    this[x(446)] = null, this[x(484)] = null;
  }
  record(x) {
    const e = b;
    let t = this[e(493)], n = t[e(456)][e(457)];
    this[e(446)] != null && console.warn(e(451), this[e(446)] + ":" + x), this.recordName = x, this[e(484)] = n[e(462)](this[e(493)]);
  }
  recordEnd(x) {
    const e = b;
    x != this[e(446)] && console[e(470)](this[e(446)], x), this[e(446)] = null;
    let t = this.currentLayer, n = t.stage[e(457)], s = this[e(484)], a = n[e(462)](t);
    this[e(494)][e(491)](x, function() {
      n[e(490)](t, a);
    }, function() {
      n[e(490)](t, s);
    });
  }
  [b(439)](x, e, t, n) {
    return this[b(449)].lineDrawn(x, e, t, n);
  }
  [b(429)]() {
    const x = b;
    this[x(482)][x(429)](), this[x(433)][x(429)](), this.anchorBox[x(429)](), this[x(456)][x(429)]();
  }
  [b(467)](x = ![]) {
    const e = b;
    return this[e(489)]()[e(428)](x);
  }
  [b(438)](x) {
    const e = b;
    this[e(493)][e(438)](x);
    let t = new R(e(463));
    t[e(436)] = x, this[e(506)](t);
  }
  [b(492)](x, e = "") {
    const t = b;
    let n = new Event(t(450));
    n[t(441)] = x + e, this[t(506)](n);
  }
  [b(427)](x) {
    const e = b;
    return this.instanceManager[e(427)](x);
  }
  [b(465)](x, e) {
    const t = b;
    this[t(504)][t(465)](x, e);
  }
}
gx[b(469)] = Pe;
function fe() {
  var r = ["377023SHnDNA", "890118pvQwtU", "432KCVkuy", "10uWAwMu", "1775195MEAwlN", "6376238ZsRMaj", "910348HKfYLu", "6uAQRjx", "30GEkNIB", "38738rlaxSv", "22701YDiBZi"];
  return fe = function() {
    return r;
  }, fe();
}
(function(r, x) {
  for (var e = me, t = r(); []; )
    try {
      var n = -parseInt(e(146)) / 1 + parseInt(e(144)) / 2 * (parseInt(e(143)) / 3) + parseInt(e(152)) / 4 + -parseInt(e(150)) / 5 * (parseInt(e(153)) / 6) + parseInt(e(145)) / 7 * (-parseInt(e(148)) / 8) + parseInt(e(147)) / 9 * (parseInt(e(149)) / 10) + parseInt(e(151)) / 11;
      if (n === x)
        break;
      t.push(t.shift());
    } catch {
      t.push(t.shift());
    }
})(fe, 192653);
function me(r, x) {
  var e = fe();
  return me = function(t, n) {
    t = t - 143;
    var s = e[t];
    return s;
  }, me(r, x);
}
export {
  gx as Editor,
  yx as IconsPanel,
  mx as PropertiesPanel
};
