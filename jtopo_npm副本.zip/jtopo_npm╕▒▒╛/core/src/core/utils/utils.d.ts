export declare let util: any;
export declare function delayRun(key: any, f: any, delayTime: any): void;
export { util as default, };
