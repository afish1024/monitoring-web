/**
 * 随机生成颜色（不是完全随机，有jtopo的主题方案）
 * 返回示例： '#c5aa99'
 * @returns {String} 十六进制颜色字符串
 */
export declare function randomColor(): string;
