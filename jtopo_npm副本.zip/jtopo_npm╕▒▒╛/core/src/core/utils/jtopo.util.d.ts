export declare let util: any;
export declare function timeoutRun(key: any, f: any, delayTime: any): void;
declare function constraint(object: any, options: any): any;
export { util as default, constraint };
