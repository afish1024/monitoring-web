export declare function bindObjectToKey(editor: any, stage: any, layer: any): void;
