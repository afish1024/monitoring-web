import EventTarget from "./EventTarget";
declare class ResourceLoaderClass extends EventTarget {
    w: any;
    lastResource: any;
    hasLoaded: any;
    imageCache: Map<string, Object>;
    callbackCache: Map<string, Array<any>>;
    constructor();
    /**
     * 当所有图片加载完成
     * @param imgUrls
     * @param showLog
     * @returns
     */
    whenAllImagesLoaded(imgUrls: string[], showLog: boolean): Promise<unknown[]>;
    clearCache(): void;
    onload(imageOrUrl: string, imageOrCanvas: any): void;
    private addToCallbackList;
    loadImage(imageOrUrl: string, callback: Function | any): void;
}
export declare const ResourceLoader: ResourceLoaderClass;
export { ResourceLoader as default };
