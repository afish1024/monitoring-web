import { Layer, Stage, EventTarget, HandlerLayer, SelectedGroup, Keyboard, DisplayObject, InputTextfield, PopupMenu, Link, InputEvent, Tooltip, Node } from '@jtopo/core';
import NodeCtrlBox from './NodeCtrlBox';
import LinkCtrlBox from './LinkCtrlBox';
import AnchorBox from './AnchorBox';
import { RedoUndoSystem } from './RedoUndoSystem';
import { KeyManager } from './KeyManager';
import { GuidlineManager } from './GuildLine';
import { ClipboardManager } from './ClipboardManager';
import { DropToBox } from './DropToBox';
import { EditorEventManager } from './EditorEventManager';
import { LayoutManager } from './LayoutManager';
import { InstanceManager } from './InstanceManager';
/**
 * 编辑器
 */
export declare class Editor extends EventTarget {
    /**
     * Stage对象
     */
    stage: Stage;
    handlerLayer: HandlerLayer;
    /**
     * 当前Layer（目前只支持一个Layer）
     */
    currentLayer: Layer;
    /**
     * 快捷键配置
     */
    KeysConfig: {
        CtrlOrCmd: string;
        CreateGroup: string;
        DropTo_leader: string;
        Delete: string[];
        Select_all: string[];
        Select_invert: string[];
        Cut: string[];
        Copy: string[];
        Paste: string[];
        Save: string[];
        Open: string[];
        Undo: string[];
        Redo: string[];
        Copy_style: string[];
        paste_Style: string[];
        Move_up: string[];
        Move_down: string[];
        Move_left: string[];
        Move_right: string[];
        Layout_tree: string[];
        Layout_grid: string[];
    };
    EditorConfig: {
        anchorBox: {
            anchorDist: number;
            nodeDist: number;
        };
        anchorPoint: {
            width: number;
            height: number;
            activeStyle: {
                fillStyle: string;
            };
            unActiveStyle: {
                strokeStyle: string;
                fillStyle: string;
            };
        };
        nodeResizePoint: {
            width: number;
            height: number;
            style: {
                border: string;
                backgroundColor: string;
            };
        };
        nodeRotatePoint: {
            width: number;
            height: number;
            style: {
                lineWidth: number;
                strokeStyle: string;
                fillStyle: string;
            };
            rotateLineStyle: {
                strokeStyle: string;
            };
            rotateLineLength: number;
        };
        guildLine: {
            styleW: {
                strokeStyle: string;
                lineDash: number[];
            };
            styleS: {
                strokeStyle: string;
                lineDash: number[];
            };
        };
        linkCtrlPoint: {
            style: {
                lineWidth: number;
                strokeStyle: string;
                fillStyle: string;
            };
            activeStyle: {
                strokeStyle: string;
                fillStyle: string;
            };
            unactiveStyle: {
                strokeStyle: string;
                fillStyle: string;
            };
            adjustStyle: {
                strokeStyle: string;
                fillStyle: string;
            };
            ctrlLinkStyle: {
                lineDash: number[];
            };
        };
        dropBox: {
            style: {
                border: string;
                lineDash: number[];
            };
        };
    };
    /**
     * 当前选中的对象组
     */
    selectedGroup: SelectedGroup;
    keyboard: Keyboard;
    nodeCtrlBox: NodeCtrlBox;
    linkCtrlBox: LinkCtrlBox;
    anchorBox: AnchorBox;
    dropToBox: DropToBox;
    editorEventManager: EditorEventManager;
    keyManager: KeyManager;
    clipboardManager: ClipboardManager;
    layoutManager: LayoutManager;
    instanceManager: InstanceManager;
    /**
     * 弹出菜单对象
     */
    popupMenu: PopupMenu;
    /**
     * 当前鼠标操作的一个对象
     */
    pickedObject?: DisplayObject;
    mouseOverTarget?: DisplayObject;
    controlTarget?: any;
    inputTextfield: InputTextfield;
    redoUndoSys: RedoUndoSystem;
    guidlineManager: GuidlineManager;
    opTooltip: Tooltip;
    /**
     * 当前鼠标划线的类名称, 默认：AutoFoldLink ，可以修改成其它Link的类名称如: "Link"、"FoldLink"
     */
    LinkClassName: string;
    recordName?: string;
    lastLayerState?: any;
    /**
     * 每一次画出的线的默认属性配置
     */
    newLinkProperties?: any;
    static KeysConfig: {
        CtrlOrCmd: string;
        CreateGroup: string;
        DropTo_leader: string;
        Delete: string[];
        Select_all: string[];
        Select_invert: string[];
        Cut: string[];
        Copy: string[];
        Paste: string[];
        Save: string[];
        Open: string[];
        Undo: string[];
        Redo: string[];
        Copy_style: string[];
        paste_Style: string[];
        Move_up: string[];
        Move_down: string[];
        Move_left: string[];
        Move_right: string[];
        Layout_tree: string[];
        Layout_grid: string[];
    };
    rulerW?: Link;
    rulerS?: Link;
    guildlineW?: Link;
    guildlineS?: Link;
    guildAxis?: Node;
    imageToBase64: boolean;
    /**
     * 当鼠标画出线时的回调处理函数
     *
     *
     * 已过时， 请使用事件监听的方式来替代该回调, 例如：
    ```js
    // 开始划线
    editor.on('drawLineStart', (event)=> {
        let link = event.object;
        console.log(link);
    });

    // 结束划线
    editor.on('drawLineEnd', (event)=> {
        let link = event.object;
        console.log(link);
    });
    ```
    *
    * @deprecated
    * @param link
    */
    onLinkCreate: null;
    /**
     *
     * @param {Stage} stage
     */
    constructor(stage: Stage);
    /**
     * 设置鼠标划线的类名称, 默认：AutoFoldLink ，可以修改成其它Link的类名称如: "Link"、"FoldLink"
     */
    setLinkClassName(className: string): void;
    /**
     * 获取当前Layer
     * @returns {Layer}
     */
    getCurrentLayer(): Layer;
    defineKeys(config: any): void;
    /**
     * 画布中间显示提示信息-很短暂停留后消失
     * @param {String} msg
     */
    showOpTooltip(msg: any): void;
    /**
     * 保存到浏览器缓存
     */
    saveHandler(event: any, imageToBase64?: boolean): void;
    /**
     * 从浏览器缓存中打开最后一次的保存
     */
    openLasted(): void;
    dblclickHandler(event: any): void;
    mousewheelHandler(event: any): void;
    mousedownHandler(event: any): void;
    mouseupHandler(event: any): void;
    mousedragHandler(event: any): void;
    mousemoveHandler(event: any): void;
    mouseenterHandler(event: any): void;
    mouseoutHandler(event: any): void;
    selectedGroupDragHandler(event: InputEvent, objects: any): void;
    selectedGroupDragEndHandler(event: InputEvent, objects: any): void;
    recordInterrupt(): void;
    record(recordName: string): void;
    recordEnd(recordName: string): void;
    /**
     * @deprecated
     */
    newLink(text: any, beginObject: any, mousePoint: any, beginEndpoint: any): any;
    /**
     * 请求刷新
     */
    update(): void;
    /**
     * 生成json字符串
     *
     * @param imageToBase64 图片是否转成Base64嵌入到到json里
     */
    toJson(imageToBase64?: boolean): string;
    /**
     * 打开一个json文档
     */
    openJson(json: string): void;
    showTip(msg1: any, msg2?: string): void;
    /**
     * 根据data生成一个图元实例
     * @param data
     */
    create(className: string): any;
    /**
     * 模拟一次按键,
     例如:
```
    editor.sendKey('Control+a'); // windows
    editor.sendKey('Meta+a'); // macos
    
    editor.sendKey('delete');

    editor.sendKey('Control+z'); // windows
    editor.sendKey('Meta+z'); // macos 撤销
```
     */
    sendKey(keyStr: string, event?: any): void;
}
export { Editor as default };
