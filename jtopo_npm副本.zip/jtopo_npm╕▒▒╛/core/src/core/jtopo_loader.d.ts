export declare function defProperties(obj: any, descs: any): void;
