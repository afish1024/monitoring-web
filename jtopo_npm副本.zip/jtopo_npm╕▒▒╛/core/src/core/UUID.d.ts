declare let UUID: any;
export { UUID as default };
