import { DisplayObject, Node, Link, Endpoint, Intersect } from '@jtopo/core';
import AnchorPoint from './AnchorPoint';
import Editor from './Editor';
declare class AnchorBox extends Node {
    editor: Editor;
    anchorDist: number;
    ctrlIntersectNode: Node;
    target?: DisplayObject;
    intersect?: Intersect;
    constructor(editor: Editor, x?: number, y?: number, w?: number, h?: number);
    mouseoutStageHandler(): void;
    mouseenterStageHandler(): void;
    clearTarget(): void;
    setTarget(obj: any, activeName?: string): void;
    activePoint(name: string): void;
    showIntersectAnchor(intersect?: Intersect): void;
    update(): void;
    createAnchorPoint(name: string): AnchorPoint;
    getObjectsIntersect(nodeOrLinks: Array<DisplayObject>): any;
    getConnectInfo(link: Link, obj: DisplayObject, end: DisplayObject): Endpoint;
}
export { AnchorBox as default };
