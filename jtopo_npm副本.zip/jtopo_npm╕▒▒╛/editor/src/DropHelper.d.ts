declare function receiveFile(domObj: any): void;
